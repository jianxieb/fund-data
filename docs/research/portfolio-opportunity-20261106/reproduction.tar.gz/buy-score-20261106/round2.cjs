'use strict';
const fs=require('node:fs'),E=require('./engine.cjs'),R=require('./research.cjs');
const clip=x=>Math.max(0,Math.min(1,x)),root=__dirname;
const candidates=[];
for(const family of ['discount','mixed','fear'])for(const reserve of [0,.1,.2])for(const threshold of [35,50])candidates.push({id:`${family}_score_reentry_r${Math.round(100*reserve)}_t${threshold}`,family,reserve,threshold,gate:'vix'});
const frozen={frozenAt:new Date().toISOString(),reasonForSecondRound:'First grid cash cap tied to initial wealth obstructed reinvestment of later sales; all candidates retained as failures against full-invested reference.',candidates,
 policy:'Original equity budget W is preserved; buy (1-reserve)*each original ETF weight initially, park reserve*weight in its sleeve. Original other40cash untouched. On VIX risk gate1->0 sell all TQQQ. Every subsequent signal day with sleeve gate on and score>=threshold spend sleeve cash*clamp((score-threshold+10)/(110-threshold)), fixed now fills next common close. If remaining cash would be less than0.01%initial spend entire sleeve. No sell due to low score. USD sleeve alwaysgateon. All score weights fixed in round1; no probability claims.'};
if(!fs.existsSync(root+'/round2-frozen.json'))fs.writeFileSync(root+'/round2-frozen.json',JSON.stringify(frozen,null,2));
function factory(c,originalWeights,features=R.FEATURES){return ()=>{let priorGate=1;return{step(ctx){
 const f=features[ctx.index],scores=f.scores.map(x=>x[c.family]),sellFractions=[0,0],buyAmounts=[0,0];
 const gate=c.gate==='none'?1:f.gate;
 if(priorGate===1&&gate===0)sellFractions[1]=1;priorGate=gate;
 for(let k=0;k<2;k++){
  if((c.scoreMode!=='immediate'&&(scores[k]===null||scores[k]<c.threshold))||(k===1&&gate!==1)||sellFractions[k])continue;
  const originalReserve=ctx.initial*originalWeights[k]*c.reserve/(1+ctx.fee*E.sum(originalWeights)*(1-c.reserve));
  const pool=Math.max(0,originalReserve+ctx.cashByLeg[k]);
  const intensity=c.scoreMode==='immediate'?1:clip((scores[k]-c.threshold+10)/(110-c.threshold));
  let budget=pool*intensity;if(pool-budget<ctx.initial*.0001)budget=pool;
  buyAmounts[k]=budget/(1+ctx.fee);
 }
 const spend=E.sum(buyAmounts)*(1+ctx.fee);if(spend>ctx.cash)buyAmounts.forEach((v,k)=>buyAmounts[k]=v*ctx.cash/spend);
 return{sellFractions,buyAmounts,reason:c.id};
}}};}
function run(){const results=[];
 for(const w of [[.3,.3],[.5,.5]]){
  const base=E.input.origins.map(o=>E.account(o,w));
  for(const c of candidates){const rows=E.input.origins.map(o=>E.account(o,w.map(v=>v*(1-c.reserve)),factory(c,w))),summary={};
   for(const y of [10,15]){const idx=E.input.origins.map((o,i)=>o.years===y?i:-1).filter(i=>i>=0);summary[y]=E.compare(idx.map(i=>rows[i]),idx.map(i=>base[i]));}
   results.push({...c,originalWeights:w,summary,rows});console.log(c.id,w.join('/'),...[10,15].map(y=>`${y}y ${summary[y].yearEqualCAGRpp.toFixed(3)}pp ${summary[y].wins}/${summary[y].n}`));
  }
 }
 fs.writeFileSync(root+'/round2-results.json',JSON.stringify({frozen,results}));
}
if(require.main===module)run();module.exports={candidates,factory};
