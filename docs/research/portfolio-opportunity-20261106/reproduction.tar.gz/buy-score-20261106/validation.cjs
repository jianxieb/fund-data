'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const E=require('./engine.cjs'),R=require('./research.cjs'),R2=require('./round2.cjs'),V=require('./policies.cjs');
const frozen=JSON.parse(fs.readFileSync(__dirname+'/round2-results.json')),oldFeatures=JSON.parse(fs.readFileSync(__dirname+'/daily-features.json'));
const selected=frozen.results.filter(c=>c.originalWeights[0]===.3&&((c.family==='discount'&&((c.reserve===.1&&c.threshold===35)||(c.reserve===.2&&c.threshold===50)))||(c.family==='mixed'&&c.reserve===.1&&c.threshold===35)));
let featureMaxDiff=0;for(let i=0;i<oldFeatures.length;i++)for(let k=0;k<2;k++)for(const key of ['discount','mixed','fear','volatility']){const a=oldFeatures[i].scores[k][key],b=R.FEATURES[i].scores[k][key];assert.equal(a===null,b===null);if(a!==null)featureMaxDiff=Math.max(featureMaxDiff,Math.abs(a-b));}
assert.equal(featureMaxDiff,0);
const origins=E.input.origins,w=[.3,.3],base=origins.map(o=>E.account(o,w));
function summarize(rows,ref){return Object.fromEntries([10,15].map(y=>{const idx=origins.map((o,i)=>o.years===y?i:-1).filter(i=>i>=0);return[y,E.compare(idx.map(i=>rows[i]),idx.map(i=>ref[i]))];}));}
const oldVix={id:'frozen_vix_only',family:'fear_reversal',ratio:1.1,confirm:10,normalRatio:1,normalConfirm:5,minHold:5,peakDrop:.3,off:0,mask:'tqqq'};
const vix=origins.map(o=>E.account(o,w,V.makeFactory(oldVix,E.sleeveTargetOrders)));
const results=[];
for(const c of selected){
 const original=origins.map(o=>E.account(o,w.map(x=>x*(1-c.reserve)),R2.factory(c,w)));
 original.forEach((row,i)=>assert(Math.abs(row.value-c.rows[i].value)<1e-9));
 const scoreOnly=origins.map(o=>E.account(o,w.map(x=>x*(1-c.reserve)),R2.factory({...c,gate:'none'},w)));
 const immediate=origins.map(o=>E.account(o,w.map(x=>x*(1-c.reserve)),R2.factory({...c,scoreMode:'immediate'},w)));
 const weights={};for(const weight of [[.4,.2],[.2,.4]]){const alt=origins.map(o=>E.account(o,weight.map(x=>x*(1-c.reserve)),R2.factory(c,weight))),ref=origins.map(o=>E.account(o,weight));weights[weight.join('/')]=summarize(alt,ref);}
 const stress={};for(const [key,options]of Object.entries({doubleFee:{fee:.002},extraDay:{delay:1},tax0:{tax:0,dividendTax:0}})){
  const rr=origins.map(o=>E.account(o,w.map(x=>x*(1-c.reserve)),R2.factory(c,w),options)),bb=origins.map(o=>E.account(o,w,null,options));stress[key]=summarize(rr,bb);
 }
 const traceOrigin=origins.find(o=>o.start==='2014-01-02'&&o.years===10),trace=E.account(traceOrigin,w.map(x=>x*(1-c.reserve)),R2.factory(c,w),{trace:true,initial:100000});
 results.push({id:c.id,parameters:{family:c.family,reserve:c.reserve,threshold:c.threshold},vsLump:summarize(original,base),vsOriginalVix:summarize(original,vix),scoreOnlyVsLump:summarize(scoreOnly,base),vsSameReserveImmediate:summarize(original,immediate),weights,stress,trace});
 console.log(c.id,JSON.stringify({vsVix:Object.fromEntries([10,15].map(y=>[y,results.at(-1).vsOriginalVix[y].yearEqualCAGRpp])),scoreOnly:Object.fromEntries([10,15].map(y=>[y,results.at(-1).scoreOnlyVsLump[y].yearEqualCAGRpp])),immediate:Object.fromEntries([10,15].map(y=>[y,results.at(-1).vsSameReserveImmediate[y].yearEqualCAGRpp]))}));
}
const distribution=['discount','mixed'].map(family=>({family,legs:[0,1].map(k=>{const values=R.FEATURES.map(f=>f.scores[k][family]).filter(x=>x!==null);return {n:values.length,missing:R.FEATURES.length-values.length,min:Math.min(...values),median:E.median(values),max:Math.max(...values),mean:E.mean(values),threshold35Days:values.filter(x=>x>=35).length,threshold50Days:values.filter(x=>x>=50).length,hundredDays:values.filter(x=>x>=100).length};})}));
fs.writeFileSync(__dirname+'/validation.json',JSON.stringify({featureMaxDiff,originalVix:summarize(vix,base),results,distribution,latest:R.FEATURES.at(-1)}));
