'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),assert=require('node:assert/strict'),cp=require('node:child_process');
const root=__dirname,manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'))),hash=x=>crypto.createHash('sha256').update(x).digest('hex');
for(const[file,expected]of Object.entries(manifest.files))assert.equal(hash(fs.readFileSync(path.join(root,file))),expected,`Frozen input changed:${file}`);
const destination=process.argv[2]||fs.mkdtempSync(path.join(os.tmpdir(),'buy-score-replay-'));
if(fs.existsSync(destination))assert.equal(fs.readdirSync(destination).length,0,'Outputdirectorymustbeempty');else fs.mkdirSync(destination,{recursive:true});
for(const file of [...Object.keys(manifest.files),'manifest.json'])fs.copyFileSync(path.join(root,file),path.join(destination,file));
const scripts=['research.cjs','round2.cjs','validation.cjs','build-report-data.cjs'];
for(const script of scripts){const output=cp.execFileSync(process.execPath,[path.join(destination,script)],{maxBuffer:32*1024*1024});fs.writeFileSync(path.join(destination,script+'.log'),output);console.log(`Replayed ${script}`);}
const proof={passed:true,frozenFiles:Object.keys(manifest.files).length,checks:{},note:'54distinctexploratoryrules;36firstgridplus18secondgridwith2capitalallocations. Monthlystartwindowsarenotindependenttrials.'};
for(const file of ['results.json','round2-results.json','validation.json','report-data.json','daily-features.json']){
 const expected=JSON.parse(fs.readFileSync(path.join(root,file))),actual=JSON.parse(fs.readFileSync(path.join(destination,file)));
 if(file==='results.json'||file==='round2-results.json'){delete expected.frozen;delete actual.frozen;}
 assert.deepEqual(actual,expected,`${file} differs`);proof.checks[file]='allfieldsidentical(excludinggeneratedfreezeclockmetadata)';
}
assert.equal(fs.readFileSync(path.join(root,'all-candidates.csv'),'utf8'),fs.readFileSync(path.join(destination,'all-candidates.csv'),'utf8'));
proof.checks['all-candidates.csv']='byteidentical';fs.writeFileSync(path.join(destination,'replay-proof.json'),JSON.stringify(proof,null,2));console.log(JSON.stringify({destination,...proof},null,2));
