'use strict';
const fs=require('node:fs'),crypto=require('node:crypto');
const E=require('./engine.cjs');
const V=require('./policies.cjs');
const root=__dirname,clip=x=>Math.max(0,Math.min(1,x)),mean=E.mean;
function priceFeatures(series){
 const out=[],rr=[],stretch=[];
 for(let i=0;i<series.length;i++){
  const [day,p]=series[i];if(i)rr.push(Math.log(p/series[i-1][1]));
  const prior=series.slice(Math.max(0,i-251),i+1).map(x=>x[1]);
  const high=Math.max(...prior),ma=mean(prior),dd=1-p/high,st=p/ma;
  const priorSt=stretch.slice(-1260);if(i>=251)stretch.push(st);
  const rv=rr.length>=21?V.volatility(rr.slice(-21)):null;
  const longrv=rr.length>=126?V.volatility(rr.slice(-126)):null;
  const rank=i>=251&&priorSt.length>=252?(priorSt.filter(x=>x>st).length+.5*priorSt.filter(x=>x===st).length)/priorSt.length:null;
  out.push({day,price:p,high252:high,ma252:ma,drawdown:dd,stretch:st,rv21:rv,rv126:longrv,stretchRank:rank,
   D:i>=251?clip(dd/.25):null,Z:rv&&i>=251?clip(dd/rv):null,S:rank});
 }
 return out;
}
function makeFeatures(data){
 const q=priceFeatures(data.proxies['us:QQQ'].series),s=priceFeatures(data.proxies['us:SOXX'].series);
 const fears=data.vix.map(([day,vix,vix3m],i,all)=>{
  const prior=all.slice(Math.max(0,i-1260),i).map(r=>r[1]),peak=Math.max(...all.slice(Math.max(0,i-62),i+1).map(r=>r[1]));
  return {day,vix,vix3m,ratio:vix/vix3m,peak63:peak,F:prior.length>=252?prior.filter(x=>x<vix).length/prior.length:null,
   R:clip((peak-vix)/(peak*.4))*clip((peak-20)/30)};
 });
 const fearConfig={family:'fear_reversal',ratio:1.1,confirm:10,normalRatio:1,normalConfirm:5,minHold:5,peakDrop:.3,off:0};
 const gate=V.fearStates(fears,fearConfig);
 return data.daily.map(([day])=>{
  const legs=[V.latest(s,day),V.latest(q,day)],f=V.latest(fears,day,true),g=V.latest(gate,day,true);
  const fresh=legs.every(a=>a&&(Date.parse(day)-Date.parse(a.day))/864e5<=7),freshFear=f&&(Date.parse(day)-Date.parse(f.day))/864e5<=7;
  return {day,legs,f,gate:g?.target??null,scores:legs.map(a=>({
   discount:!fresh||a.S===null||a.D===null?null:100*(.6*a.D+.4*a.S),
   volatility:!fresh||a.Z===null||a.rv126===null?null:100*(.5*a.D+.35*a.Z+.15*clip(1-a.rv21/(2*a.rv126))),
   fear:!fresh||!freshFear||a.D===null||f.F===null?null:100*(.5*a.D+.25*f.F+.25*f.R),
   mixed:!fresh||!freshFear||a.D===null||a.S===null||f.F===null?null:100*(.4*a.D+.3*a.S+.15*f.F+.15*f.R)
  }))};
 });
}
const FEATURES=makeFeatures(E.input);
const candidates=[];
for(const family of ['discount','volatility','fear','mixed'])for(const policy of ['deploy','target','risk_deploy'])for(const threshold of [35,50,65]){
 candidates.push({id:`${family}_${policy}_${threshold}`,family,policy,threshold});
}
const frozen={frozenAt:new Date().toISOString(),dataSha:crypto.createHash('sha256').update(fs.readFileSync(root+'/inputs.json')).digest('hex'),candidates,
 features:{D:'clamp((1-P/H252)/0.25)',S:'fraction of prior 1260 P/MA252 ratios above current; at least 252 prior',Z:'clamp(drawdown252/annualized realized volatility21)',F:'fraction of prior 1260 VIX levels below previous known VIX; at least 252 prior',R:'clamp((peakVIX63-VIX)/(0.4*peakVIX63))*clamp((peakVIX63-20)/30)'},
 scores:{discount:'100*(.6D+.4S)',volatility:'100*(.5D+.35Z+.15clamp(1-rv21/(2*rv126)))',fear:'100*(.5D+.25F+.25R)',mixed:'100*(.4D+.3S+.15F+.15R)'},
 policy:{deploy:'Buy at score crossing threshold, minimum every21 common trading days. Spend one third of then available cash per leg weighted by positive score-threshold+10, max original cash /3; no selling.',target:'First common close of month: stock target=40%+60%*clamp((score-threshold+25)/50); pair split follows original weights. Sell and buy to target with preknown cash.',risk_deploy:'Same deploy rule, plus VIX panic exit of TQQQ using existing frozen gate; TQQQ reentry only if gate on and score above threshold. Original cash permitted.',initial:'All strategies initially buy original30/30 and retain40cash; compare30/30/40 and50/50 fullcapital.'},
 accounting:'Original audited engine .1% per side fees,20% capital/dividend tax,unrealized tax reserve,next common close fixed budget, no contributions or borrowing',selection:'All36 candidates reported; exploratory in-sample; no independent OOS claim.'};
if(!fs.existsSync(root+'/frozen-grid.json'))fs.writeFileSync(root+'/frozen-grid.json',JSON.stringify(frozen,null,2));
function factory(c,features=FEATURES){return ()=>{let lastBuy=-9999,lastMonth='',priorGate=1;return{step(ctx){
 const f=features[ctx.index],scores=f.scores.map(x=>x[c.family]);if(scores.some(x=>x===null))return null;
 const sw=E.sum(ctx.weights),shares=ctx.weights.map(w=>w/sw),weighted=E.sum(scores.map((x,k)=>x*shares[k]));
 const sellFractions=[0,0],buyAmounts=[0,0];
 if(c.policy==='target'){
  const month=ctx.day.slice(0,7);if(month===lastMonth)return null;lastMonth=month;
  const a=.4+.6*clip((weighted-c.threshold+25)/50),target=shares.map(w=>w*a*ctx.wealth);
  target.forEach((v,k)=>{if(ctx.marks[k]>v)sellFractions[k]=(ctx.marks[k]-v)/ctx.marks[k];});
  const gaps=target.map((v,k)=>Math.max(0,v-ctx.marks[k])),sum=E.sum(gaps),budget=Math.min(ctx.cash/(1+ctx.fee),sum/(1+ctx.fee));
  gaps.forEach((x,k)=>{buyAmounts[k]=sum?budget*x/sum:0;});
 }else{
  if(c.policy==='risk_deploy'&&priorGate===1&&f.gate===0)sellFractions[1]=1;
  priorGate=f.gate;
  const signals=scores.map((score,k)=>score>=c.threshold&&(c.policy!=='risk_deploy'||k===0||f.gate>0)?(score-c.threshold+10)*shares[k]:0),sum=E.sum(signals);
  if(sum>0&&ctx.index-lastBuy>=21&&ctx.cash>1e-8){
   const budget=Math.min(ctx.cash/3,ctx.initialCash/3)/(1+ctx.fee);signals.forEach((x,k)=>buyAmounts[k]=budget*x/sum);lastBuy=ctx.index;
  }
 }
 return {sellFractions,buyAmounts,reason:c.id};
}}};}
function run(){
 const origins=E.input.origins,weights=[.3,.3],base=origins.map(o=>E.account(o,weights)),full=origins.map(o=>E.account(o,[.5,.5]));
 const results=[];
 for(const c of candidates){const rows=origins.map(o=>E.account(o,weights,factory(c)));const result={...c,summary:{},rows};
  for(const y of [10,15]){const idx=origins.map((o,i)=>o.years===y?i:-1).filter(i=>i>=0),sub=idx.map(i=>rows[i]);result.summary[y]={base:E.compare(sub,idx.map(i=>base[i])),full:E.compare(sub,idx.map(i=>full[i]))};}
  results.push(result);console.log(c.id,...[10,15].map(y=>`${y}y base ${result.summary[y].base.yearEqualCAGRpp.toFixed(2)} full ${result.summary[y].full.yearEqualCAGRpp.toFixed(2)} wins ${result.summary[y].full.wins}/${result.summary[y].full.n}`));
 }
 fs.writeFileSync(root+'/results.json',JSON.stringify({frozen,results,base,full}));
 const daily=FEATURES.map(f=>({day:f.day,scores:f.scores,legs:f.legs,f:f.f,gate:f.gate}));fs.writeFileSync(root+'/daily-features.json',JSON.stringify(daily));
 console.log('BEST',JSON.stringify(results.slice().sort((a,b)=>b.summary[15].full.yearEqualCAGRpp-a.summary[15].full.yearEqualCAGRpp).slice(0,8).map(r=>({id:r.id,ten:r.summary[10],fifteen:r.summary[15]})),null,2));
}
if(require.main===module)run();module.exports={FEATURES,candidates,factory,makeFeatures,priceFeatures};
