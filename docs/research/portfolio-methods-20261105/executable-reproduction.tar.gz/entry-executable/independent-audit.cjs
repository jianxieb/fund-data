const fs=require('fs'),assert=require('assert/strict'),crypto=require('crypto'),root=__dirname;
const read=f=>JSON.parse(fs.readFileSync(root+'/'+f)),results=read('results.json'),input=read('inputs.json'),external=read('external-inputs.json'),tax=read('tax-inputs.json');
const sum=x=>x.reduce((a,b)=>a+b,0),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const markets={USD_TQQQ_actual_ETFs:{d:input,frac:['us:USD','us:TQQQ'].map(id=>tax[id].dividendEvidence.fractions)},SMPIX_UOPIX_actual_funds:{d:external,frac:[{},{}]}};
for(const m of Object.values(markets))m.index=new Map(m.d.daily.map(([d],i)=>[d,i]));
function calculate(m,o,w,taxRate,fee,delay,hold){
 const first=m.index.get(o.start),last=m.index.get(o.end),W=sum(w),alloc=100/(1+W*fee);
 let cash=100-alloc*W*(1+fee),cost=alloc*W*fee,paid=0,extra=0,buys=0,count=w.filter(x=>x>0).length,maxAfter=null,overshoots=0,maxOvershoot=0;
 if(Math.abs(cash)<1e-10)cash=0;
 const initialCash=cash,qty=w.map((v,k)=>alloc*v/m.d.daily[first][1][k]),basis=w.map(v=>alloc*v*(1+fee));
 let order=null,peak=100,mdd=0,value=100,reserve=0,maxExposure=0,exposureSum=0;
 for(let i=first;i<=last;i++){
  const [day,px]=m.d.daily[i];
  if(i>first)for(let k=0;k<2;k++){const distribution=qty[k]*px[k]*(m.frac[k][day]||0),charge=distribution*taxRate;paid+=charge;qty[k]-=charge/px[k];basis[k]+=distribution-charge;}
  if(order&&--order.wait===0){
   const notionals=order.amount.slice(),notional=sum(notionals),cashNeeded=notional*(1+fee);assert(cashNeeded<=cash+1e-8);
   const factor=Math.min(1,cash/cashNeeded);
   let amount=0;
   notionals.forEach((n,k)=>{n*=factor;amount+=n;qty[k]+=n/px[k];basis[k]+=n*(1+fee);if(n>1e-12)count++;});
   cash-=amount*(1+fee);if(Math.abs(cash)<1e-10)cash=0;cost+=amount*fee;extra+=amount;buys++;
   const stock=sum(qty.map((q,k)=>q*px[k])),actual=stock/(stock+cash);maxAfter=Math.max(maxAfter??actual,actual);maxOvershoot=Math.max(maxOvershoot,actual-W);if(actual>W+1e-10)overshoots++;
   order=null;
  }
  const marks=qty.map((q,k)=>q*px[k]),stock=sum(marks),wealth=cash+stock;
  reserve=sum(marks.map((v,k)=>Math.max(0,v*(1-fee)-basis[k])*taxRate));value=wealth-reserve;peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));assert(cash>=-1e-8);
  const exposure=stock/wealth;maxExposure=Math.max(maxExposure,exposure);exposureSum+=exposure;
  if(!hold&&!order&&W*wealth-stock>Math.max(1e-10,wealth*2e-14)){
   const gaps=marks.map((v,k)=>Math.max(0,w[k]*wealth-v)),gap=sum(gaps),amount=Math.max(0,Math.min(cash/(1+fee),(W*wealth-stock)/(1+W*fee)));
   if(amount>1e-10&&gap>1e-10)order={wait:1+delay,amount:gaps.map(g=>amount*g/gap)};
  }
 }
 return{value,annualReturn:100*((value/100)**(365.2425/((Date.parse(o.end)-Date.parse(o.start))/864e5))-1),mdd,finalCash:cash,cashConsumed:initialCash-cash,fees:cost,paidDividendTax:paid,capitalGainsTaxReserve:reserve,transactions:count,additionalBuyDates:buys,additionalPurchaseNotional:extra,maxStockFraction:maxExposure,meanStockFraction:exposureSum/(last-first+1),maxStockFractionAfterAdditionalBuy:maxAfter,maxTargetOvershootAfterBuyPP:Math.max(0,maxOvershoot)*100,overshootingBuyDates:overshoots,costBasis:basis};
}
let accounts=0,points=0;const maxErrors={},cache=new Map();
for(const g of results.groups){
 const m=markets[g.universe];
 for(const [key,hold]of [['rows',false],['baseline',true]])for(const expected of g[key]){
  const cacheKey=JSON.stringify([g.universe,g.tax,g.weights,g.fee,hold?0:g.extraDelay,hold,expected.start,expected.end]);
  let r=cache.get(cacheKey);if(!r){r=calculate(m,expected,g.weights,g.tax,g.fee,hold?0:g.extraDelay,hold);cache.set(cacheKey,r);}
  for(const[k,value]of Object.entries(r)){
   if(Array.isArray(value)){value.forEach((x,i)=>assert(Math.abs(x-expected[k][i])<1e-7));continue;}
   if(value===null||expected[k]===null){assert.equal(value,expected[k]);continue;}
   const error=Math.abs(value-expected[k]);maxErrors[k]=Math.max(maxErrors[k]||0,error);assert(error<1e-7,[g.universe,expected.start,k,error]);
  }
  accounts++;points+=m.index.get(expected.end)-m.index.get(expected.start)+1;
 }
}
const result={passed:true,engine:'Independent JavaScript cash/units/basis ledger with one countdown order; no import from primary Python engine',accounts,uniqueAccounts:cache.size,valuationPoints:points,maxErrors,sourceHashes:Object.fromEntries(['inputs.json','tax-inputs.json','external-inputs.json','protocol.json','results.json','independent-audit.cjs'].map(f=>[f,hash(fs.readFileSync(root+'/'+f))]))};
fs.writeFileSync(root+'/independent-audit.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
