"""Fixed ex-ante cash top-up orders. All performance inputs are committed archive members."""
from pathlib import Path
from datetime import date,datetime,timezone
from collections import defaultdict
import json,hashlib,math,statistics,sys
P=Path(__file__).resolve().parent
SHA=lambda b:hashlib.sha256(b).hexdigest()
I=json.loads((P/'inputs.json').read_text());T=json.loads((P/'tax-inputs.json').read_text());E=json.loads((P/'external-inputs.json').read_text())
WEIGHTS=[[.3,.3],[.2,.4],[.4,.2],[.35,.25],[.15,.65],[.5,.5]]
CONFIG={'capital':100,'weights':WEIGHTS,'taxes':[0,.2],'fees':[.001,.005],'extraDelay':[0,1],'periods':[10,15],'cashInterest':0,'contributions':0,'rebalance':'none','sales':False,'terminalLiquidation':False,'external':{'assets':['SMPIX','UOPIX'],'weights':[.3,.3],'tax':0,'years':20,'fees':[.001,.005],'extraDelay':[0,1]}}
MEAN=statistics.mean;MED=statistics.median

def save(name,x):
 with (P/name).open('x') as f:json.dump(x,f,ensure_ascii=False,separators=(',',':'))

def freeze():
 source=json.loads((P/'source-provenance.json').read_text())
 for f,meta in source['files'].items():assert SHA((P/f).read_bytes())==meta['sha256']
 save('protocol.json',{'frozenUTC':datetime.now(timezone.utc).isoformat(),'config':CONFIG,'codeSHA256':SHA(Path(__file__).read_bytes()),'source':source,
 'rule':'After each common close, once any due order has settled and no pending order remains, snapshot the full account. If gross stock fraction is below initial total target W, compute B=max(0,min(C/(1+f),(W*V-K)/(1+W*f))) using that closing cash C, wealth V, gross stock K and fee f. Allocate this immutable notional by positive asset target amount gaps max(0,w_k*V-mark_k). No parameters selected.',
 'execution':'ExtraDelay0 executes each plan at the next common close. ExtraDelay1 executes two common closes later. Exactly one pending order is allowed: execute the due order first, then a new plan may be placed after that same close. Therefore delay1 is a serialized two-common-day pipeline, not a backlog of overlapping commitments. Initial buys occur immediately in all arms; delay applies only to additional orders.',
 'immutableOrders':'At execution, buy the predeclared per-asset amounts at actual closing prices, without checking current target weight or canceling on a rebound. Available cash can cap an order only to avoid overspending, never because of price/target changes. With one pending order and no cash withdrawals, such caps should only be floating-point noise; material caps fail validation. Orders whose due date exceeds the backtest end remain unfilled and are reported.',
 'cashAndFees':'Initial usable=100/(1+f*sum(weights)); purchases=usable*weights; original cash=100-purchases-fees. All purchase fees are funded inside the account. No sale, added capital, loan, or interest. Full100%stock must equal lump sum.',
 'taxes':'Adjusted prices already reinvest gross dividends. Deduct dividend tax by reducing units; add net reinvestment to basis. Purchases add notional+fee to basis. No realized gain tax; subtract positive unrealized gains net of hypothetical sale fee times cap tax from daily/final wealth as reserve only. Baseline identical.',
 'comparison':'All81 full10-year and21 full15-year starts, six unretuned initial weights, both taxes, both fees, both fixed delays. Compare to same-cost lump sum and archived old current-close-sized top-up. Old delay1 means t-2 eligibility/current-close sizing; it is explicitly not the same execution mechanism as serialized pending orders.',
 'externalBoundary':'77 true20-year SMPIX1.5x/UOPIX2x mutual-fund windows, actual different US instruments, zero tax only because original distribution evidence is absent. All four fee/delay cells. Never call these synthetic USD/TQQQ ETF prehistory.',
 'risk':'Post-fill stock exposure may exceed W after intervening price moves. Report actual maximum and excess; never assert a hard target cap. All gains deploy originally idle cash, changing exposure; not risk-matched alpha.',
 'selection':'Single fixed rule, no grid search or winner selection. All negative and tied cases preserved. Core cells reported first without changing full protocol after outcomes.'})
 print('Frozen executable-order protocol; no performance calculated.',flush=True)

def verify_protocol():
 p=json.loads((P/'protocol.json').read_text());assert p['config']==CONFIG and p['codeSHA256']==SHA(Path(__file__).read_bytes())
 for f,m in p['source']['files'].items():assert SHA((P/f).read_bytes())==m['sha256']
 return p

class Market:
 def __init__(self,data,taxes=None):
  self.data=data;self.days=[r[0] for r in data['daily']];self.prices=[r[1] for r in data['daily']];self.idx={d:i for i,d in enumerate(self.days)}
  self.fractions=[[taxes[k]['dividendEvidence']['fractions'].get(d,0) for k in ['us:USD','us:TQQQ']] if taxes else [0.,0.] for d in self.days]
ETF=Market(I,T);EXTERNAL=Market(E)

def run(m,o,w,tax=.2,fee=.001,delay=0,hold=False,trace=False):
 a,b=m.idx[o['start']],m.idx[o['end']];W=sum(w);usable=100/(1+fee*W);initialBuy=usable*W;cash=100-initialBuy*(1+fee)
 if abs(cash)<1e-10:cash=0.
 units=[usable*w[k]/m.prices[a][k] for k in range(2)];basis=[usable*w[k]*(1+fee) for k in range(2)];originalCash=cash;fees=initialBuy*fee;paid=0.;purchased=initialBuy;trades=sum(x>0 for x in w);buyDates=0;turnover=initialBuy/100
 pending=None;placed=0;peak=grossPeak=100.;mdd=grossMDD=0.;minCash=cash;maxExposure=0.;sumExposure=0.;maxAfterBuy=None;overshoots=0;maxOvershoot=0.;maxCommitmentGap=0.;cashCaps=0;values=[];plans=[];fills=[];curve=[]
 for i in range(a,b+1):
  px=m.prices[i];day=m.days[i]
  if i>a:
   for k in range(2):
    gross=units[k]*px[k]*m.fractions[i][k];charge=gross*tax;units[k]-=charge/px[k];basis[k]+=gross-charge;paid+=charge
  if pending and pending['dueIndex']==i:
   immutable=pending['notionals'];need=sum(immutable)*(1+fee);gap=need-cash;maxCommitmentGap=max(maxCommitmentGap,gap)
   assert gap<=max(1e-8,abs(cash)*1e-12),('Cash overcommitted',day,gap)
   scale=min(1.,cash/need) if need else 1.
   if scale<1-1e-12:cashCaps+=1
   notionals=[x*scale for x in immutable];amount=sum(notionals);charge=amount*fee
   for k in range(2):units[k]+=notionals[k]/px[k];basis[k]+=notionals[k]*(1+fee)
   cash-=amount+charge
   if abs(cash)<1e-10:cash=0.
   fees+=charge;purchased+=amount;trades+=sum(x>1e-12 for x in notionals);buyDates+=1
   stock=sum(units[k]*px[k] for k in range(2));wealth=stock+cash;exposure=stock/wealth;turnover+=amount/(wealth+charge)
   maxAfterBuy=exposure if maxAfterBuy is None else max(maxAfterBuy,exposure);maxOvershoot=max(maxOvershoot,exposure-W);overshoots+=exposure>W+1e-10
   if trace:fills.append({'date':day,'signalDate':pending['signalDate'],'dueDate':pending['dueDate'],'notionals':notionals,'plannedNotionals':immutable,'fee':charge,'availableCashBefore':cash+amount+charge,'cashCapScale':scale,'stockFractionAfter':exposure,'plan':pending})
   pending=None
  marked=[units[k]*px[k] for k in range(2)];stock=sum(marked);grossValue=stock+cash;reserve=sum(max(0,marked[k]*(1-fee)-basis[k])*tax for k in range(2));value=grossValue-reserve
  assert cash>=-1e-8 and value>0
  peak=max(peak,value);mdd=min(mdd,100*(value/peak-1));grossPeak=max(grossPeak,grossValue);grossMDD=min(grossMDD,100*(grossValue/grossPeak-1))
  exposure=stock/grossValue;sumExposure+=exposure;maxExposure=max(maxExposure,exposure);minCash=min(minCash,cash);values.append(value)
  if not hold and pending is None and stock<W*grossValue-max(1e-10,grossValue*2e-14):
   gaps=[max(0,w[k]*grossValue-marked[k]) for k in range(2)];totalGap=sum(gaps);budget=max(0,min(cash/(1+fee),(W*grossValue-stock)/(1+W*fee)))
   if budget>1e-10 and totalGap>1e-10:
    due=i+1+delay;notionals=[budget*g/totalGap for g in gaps]
    pending={'signalDate':day,'dueIndex':due,'dueDate':m.days[due] if due<len(m.days) else None,'notionals':notionals,'snapshot':{'cash':cash,'units':units[:],'basis':basis[:],'prices':px[:],'stock':stock,'grossValue':grossValue,'taxReserve':reserve,'paidDividendTax':paid,'stockFraction':exposure,'positiveGaps':gaps}}
    placed+=1
    if trace:plans.append(pending)
  if trace:curve.append({'date':day,'value':value,'grossValue':grossValue,'cash':cash,'stock':stock,'taxReserve':reserve,'paidDividendTax':paid,'basis':basis[:],'units':units[:],'stockFraction':exposure,'pendingDueDate':pending['dueDate'] if pending else None})
 elapsed=(date.fromisoformat(o['end'])-date.fromisoformat(o['start'])).days/365.2425;rr=sorted(100*(values[j]/values[j-1]-1) for j in range(1,len(values)))
 result={'start':o['start'],'end':o['end'],'years':o['years'],'value':value,'grossValue':grossValue,'annualReturn':100*((value/100)**(1/elapsed)-1),'mdd':mdd,'grossMDD':grossMDD,'dailyCVaR95Pct':MEAN(rr[:math.ceil(.05*len(rr))]),'initialCash':originalCash,'finalCash':cash,'minimumCash':minCash,'cashConsumed':originalCash-cash,'initialPurchaseNotional':initialBuy,'actualPurchaseNotional':purchased,'additionalPurchaseNotional':purchased-initialBuy,'maxStockFraction':maxExposure,'meanStockFraction':sumExposure/len(values),'maxStockFractionAfterAdditionalBuy':maxAfterBuy,'maxTargetOvershootAfterBuyPP':max(0,maxOvershoot)*100,'overshootingBuyDates':overshoots,'fees':fees,'paidDividendTax':paid,'paidCapitalGainsTax':0,'capitalGainsTaxReserve':reserve,'taxCost':paid+reserve,'costBasis':basis,'transactions':trades,'additionalBuyDates':buyDates,'placedPlans':placed,'unfilledPendingAtEnd':pending,'materialCashCapCount':cashCaps,'maxCashCommitmentGap':maxCommitmentGap,'annualTurnoverPct':turnover*100/elapsed}
 if trace:result.update(plans=plans,fills=fills,curve=curve)
 return result

def compare(rows,base):
 yy=defaultdict(list);pairs=[]
 for r,b in zip(rows,base):
  assert (r['start'],r['end'])==(b['start'],b['end']);delta=r['annualReturn']-b['annualReturn'];yy[r['start'][:4]].append(delta);pairs.append({'start':r['start'],'end':r['end'],'CAGRpp':delta,'wealthRelativePct':100*(r['value']/b['value']-1),'value':r['value'],'comparisonValue':b['value'],'mdd':r['mdd'],'comparisonMDD':b['mdd']})
 ds=[r['CAGRpp'] for r in pairs]
 return {'n':len(rows),'yearEqualCAGRpp':MEAN(MEAN(v) for v in yy.values()),'meanCAGRpp':MEAN(ds),'wins':sum(x>1e-9 for x in ds),'ties':sum(abs(x)<=1e-9 for x in ds),'losses':sum(x< -1e-9 for x in ds),'medianWealthRelativePct':MED(r['wealthRelativePct'] for r in pairs),'worstOrigin':min(pairs,key=lambda r:r['CAGRpp']),'byEntryYear':{y:{'n':len(v),'meanCAGRpp':MEAN(v)} for y,v in yy.items()}}

def metrics(rows):
 return {'medianMDD':MED(r['mdd'] for r in rows),'worstMDD':min(r['mdd'] for r in rows),'medianCVaR95Pct':MED(r['dailyCVaR95Pct'] for r in rows),'meanStockFraction':MEAN(r['meanStockFraction'] for r in rows),'maxStockFraction':max(r['maxStockFraction'] for r in rows),'maxStockFractionAfterAdditionalBuy':max((r['maxStockFractionAfterAdditionalBuy'] for r in rows if r['maxStockFractionAfterAdditionalBuy'] is not None),default=None),'maxTargetOvershootAfterBuyPP':max(r.get('maxTargetOvershootAfterBuyPP',0) for r in rows),'overshootingAccounts':sum(r.get('overshootingBuyDates',0)>0 for r in rows),'medianCashConsumed':MED(r['cashConsumed'] for r in rows),'medianAdditionalBuyDates':MED(r['additionalBuyDates'] for r in rows),'medianFees':MED(r['fees'] for r in rows),'medianPaidDividendTax':MED(r['paidDividendTax'] for r in rows),'medianGainTaxReserve':MED(r['capitalGainsTaxReserve'] for r in rows),'minimumCash':min(r['minimumCash'] for r in rows),'materialCashCaps':sum(r.get('materialCashCapCount',0) for r in rows)}

def old_groups(external=False,tax=.2):
 f='old-external-results.json' if external else 'old-taxed-results.json' if tax else 'old-pretax-results.json'
 return json.loads((P/f).read_text())['results']

def evaluate(core=False):
 verify_protocol();groups=[];basecache={};baselineMaxError=0.
 configs=[(False,t,w,f,l,y) for t in [0,.2] for w in WEIGHTS for f in [.001,.005] for l in [0,1] for y in [10,15]]
 if core:configs=[(False,.2,w,.001,0,y) for w in [[.3,.3],[.5,.5]] for y in [10,15]]
 else:configs.extend((True,0,[.3,.3],f,l,20) for f in [.001,.005] for l in [0,1])
 for external,t,w,f,l,y in configs:
  m=EXTERNAL if external else ETF;oo=[o for o in m.data['origins'] if o['years']==y];assert len(oo)=={10:81,15:21,20:77}[y]
  old=next(g for g in old_groups(external,t) if g['weights']==w and g['fee']==f and g['extraDelay']==l and g['years']==y)
  key=(external,t,tuple(w),f,y)
  if key not in basecache:basecache[key]=[run(m,o,w,t,f,0,hold=True) for o in oo]
  base=basecache[key];rows=[run(m,o,w,t,f,l) for o in oo]
  for a,b in zip(base,old['baseline']):
   err=abs(a['value']-b['value']);baselineMaxError=max(baselineMaxError,err);assert err<1e-7
  if sum(w)==1:
   for a,b in zip(rows,base):assert a['value']==b['value'] and a['additionalBuyDates']==0
  g={'universe':'SMPIX_UOPIX_actual_funds' if external else 'USD_TQQQ_actual_ETFs','tax':t,'weights':w,'fee':f,'extraDelay':l,'years':y,'vsLump':compare(rows,base),'vsOldCurrentClose':compare(rows,old['rows']),'risk':metrics(rows),'lumpRisk':metrics(base),'rows':rows,'baseline':base,'oldCurrentCloseRows':old['rows']};groups.append(g)
  print(json.dumps({'core':core,'universe':g['universe'],'tax':t,'w':w,'fee':f,'delay':l,'years':y,'CAGRpp':g['vsLump']['yearEqualCAGRpp'],'winTieLoss':[g['vsLump'][k] for k in ['wins','ties','losses']],'vsOldPP':g['vsOldCurrentClose']['yearEqualCAGRpp'],'maxAfterBuyOvershootPP':g['risk']['maxTargetOvershootAfterBuyPP']}),flush=True)
 save('core-results.json' if core else 'results.json',{'protocolSHA256':SHA((P/'protocol.json').read_bytes()),'baselineMaxErrorVsOld':baselineMaxError,'groups':groups})
 if not core:
  save('summary.json',{'protocolSHA256':SHA((P/'protocol.json').read_bytes()),'groups':[{k:v for k,v in g.items() if k not in ['rows','baseline','oldCurrentCloseRows']} for g in groups]})
  traces=[]
  for external,y,start,w,f,l,t in [(False,10,'2014-01-02',[.3,.3],.001,0,.2),(False,15,next(o['start'] for o in I['origins'] if o['years']==15),[.3,.3],.001,0,.2),(False,10,'2014-01-02',[.35,.25],.005,1,.2),(True,20,next(o['start'] for o in E['origins'] if o['years']==20),[.3,.3],.001,0,0)]:
   m=EXTERNAL if external else ETF;o=next(o for o in m.data['origins'] if o['years']==y and o['start']==start);traces.append({'universe':'external' if external else 'ETF','weights':w,'fee':f,'extraDelay':l,'tax':t,'account':run(m,o,w,t,f,l,trace=True)})
  save('traces.json',{'traces':traces})

if __name__=='__main__':
 if sys.argv[1]=='freeze':freeze()
 elif sys.argv[1]=='core':evaluate(True)
 elif sys.argv[1]=='evaluate':evaluate()
 else:raise SystemExit('freeze | core | evaluate')
