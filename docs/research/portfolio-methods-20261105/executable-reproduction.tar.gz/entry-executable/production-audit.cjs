const fs=require('fs'),assert=require('assert/strict'),crypto=require('crypto');
const P=require('./production/assets/portfolio-model.js'),read=f=>JSON.parse(fs.readFileSync(__dirname+'/'+f)),d=read('inputs.json'),tax=read('tax-inputs.json'),results=read('results.json'),ids=['us:USD','us:TQQQ'],dates=new Set(d.daily.map(r=>r[0]));
const catalog={assets:ids.map(id=>({id,code:id.slice(3),name:id+' frozen actual CNY-converted ETF',currency:'CNY',market:'us',kind:'etf',status:'available'}))};
const histories=Object.fromEntries(ids.map((id,k)=>[id,{schemaVersion:1,id,currency:'CNY',basis:'provider_adjusted_close',dividends:'reinvested',first:d.daily[0][0],asOf:d.daily.at(-1)[0],series:d.daily.map(r=>[r[0],r[1][k]]),dividendEvidence:{...tax[id].dividendEvidence,fractions:Object.fromEntries(Object.entries(tax[id].dividendEvidence.fractions).filter(([day])=>dates.has(day)))}}]));
const maxErrors={},rows=[];let cases=0,accounts=0,checkedSignals=0;
for(const g of results.groups){
 if(g.universe!=='USD_TQQQ_actual_ETFs'||g.extraDelay!==0)continue;
 for(let i=0;i<g.rows.length;i++){
  const pair={tax:g.tax,weights:g.weights,fee:g.fee,years:g.years,start:g.rows[i].start,end:g.rows[i].end};
  for(const[method,expected]of [['cash_topup',g.rows[i]],['lump_sum',g.baseline[i]]]){
   const cfg={positions:ids.map((id,k)=>({id,weight:g.weights[k]*100})),currency:'CNY',initial:100,monthly:0,years:'custom',start:expected.start,end:expected.end,rebalance:'none',transactionFee:g.fee*100,feeBasis:'net',tax:{usCapitalGains:g.tax*100,usDividend:g.tax*100,liquidate:false},initialMethod:method};
   const a=P.simulate({catalog,histories,config:cfg});assert(!a.error,a.error);
   for(const[k,j]of [['value','value'],['annualReturn','annualReturn'],['mdd','mdd'],['cash','finalCash'],['tradeCost','fees'],['dividendTax','paidDividendTax'],['taxReserve','capitalGainsTaxReserve'],['topupAmount','additionalPurchaseNotional'],['topupTimes','additionalBuyDates'],['maxActualExposure','maxStockFraction']]){
    const diff=Math.abs(a[k]-expected[j]);assert(Number.isFinite(diff),k);maxErrors[k]=Math.max(maxErrors[k]||0,diff);assert(diff<1e-7,[cfg,method,k,diff]);
   }
   assert(a.capitalTax===0&&a.contributed===100);assert(a.transactions.every(t=>t.side==='buy'));
   const index=new Map(d.daily.map((r,j)=>[r[0],j]));
   for(const t of a.transactions.filter(t=>t.reason==='cash_topup')){assert.equal(index.get(t.day)-index.get(t.signalDay),1);checkedSignals++;}
   pair[method]={value:a.value,annualReturn:a.annualReturn,mdd:a.mdd,cash:a.cash,tradeCost:a.tradeCost,dividendTax:a.dividendTax,taxReserve:a.taxReserve,topupAmount:a.topupAmount,topupTimes:a.topupTimes,maxActualExposure:a.maxActualExposure};accounts++;
  }
  rows.push(pair);cases++;if(cases%408===0)console.log('production paired accounts '+cases);
 }
}
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(__dirname+'/'+f)).digest('hex');
const out={passed:true,scope:'All frozen ETF no-extra-delay cells; not the extra-delay serialized pipeline and not external funds. Same100,weights,taxes,fees and common-date prices. Production snapshot executes precommitted currency amounts.',cases,accounts,checkedNextCommonDaySignalTrades:checkedSignals,maxErrors,sourceHashes:Object.fromEntries(['production/assets/portfolio-model.js','production/assets/model.js','production-audit.cjs','protocol.json','results.json'].map(f=>[f,hash(f)])),rows};fs.writeFileSync(__dirname+'/production-audit.json',JSON.stringify(out,null,2));console.log(JSON.stringify({...out,rows:undefined},null,2));
