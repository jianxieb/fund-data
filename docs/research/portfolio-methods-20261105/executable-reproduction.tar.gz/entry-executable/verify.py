"""Checks order causality and ledger invariants without editing frozen outputs."""
import json,copy,math,hashlib
from pathlib import Path
import study as S
P=Path(__file__).parent
checks=[]
def check(label,**data):checks.append({'check':label,**data})
def market(paths):
 days=['2025-01-02','2025-01-03','2025-01-06','2025-01-07','2025-01-08','2025-01-09'][:len(paths)]
 d={'daily':list(zip(days,paths)),'origins':[]};return S.Market(d),{'start':days[0],'end':days[-1],'years':10}
m,o=market([[100,100],[50,100],[200,200]])
r=S.run(m,o,[.3,.3],tax=0,fee=0,trace=True)
assert len(r['fills'])==1 and r['fills'][0]['notionals']==[6.,0.] and r['fills'][0]['signalDate']=='2025-01-03' and r['fills'][0]['date']=='2025-01-06'
assert abs(r['finalCash']-34)<1e-12 and abs(r['value']-160)<1e-12 and abs(r['maxStockFractionAfterAdditionalBuy']-.7875)<1e-12
check('Hand-computed rebound executes already-known6, never cancels or recalculates from fill price',cash=34,value=160,stockFraction=.7875,target=.6)
m,o=market([[100,100],[50,100],[25,100],[50,100],[50,100]])
r=S.run(m,o,[.3,.3],tax=0,fee=0,delay=1,trace=True)
assert len(r['fills'])==1 and r['fills'][0]['notionals']==[6.,0.] and r['fills'][0]['date']=='2025-01-07'
assert r['plans'][0]['signalDate']=='2025-01-03' and not any(p['signalDate']=='2025-01-06' for p in r['plans'])
check('Extra delay uses one committed order; intervening deeper drop cannot duplicate the same cash',signal='2025-01-03',filled='2025-01-07',notional=6.)
for fee in [.001,.005]:
 r=S.run(m,o,[.5,.5],tax=.2,fee=fee,delay=1,trace=True);b=S.run(m,o,[.5,.5],tax=.2,fee=fee,hold=True,trace=True)
 assert r['value']==b['value'] and not r['fills'] and r['cashConsumed']==0
check('Fully invested has no invented reserve and exactly equals lump sum')
# Future mutation checks both target histories and distribution fractions; pre-cutoff plans must remain identical.
for delay in [0,1]:
 for start,years,cutoff in [('2014-01-02',10,'2015-01-02'),('2010-03-01',15,'2020-03-31')]:
  o=next(o for o in S.I['origins'] if o['start']==start and o['years']==years)
  original=S.run(S.ETF,o,[.3,.3],tax=.2,fee=.001,delay=delay,trace=True)
  data=copy.deepcopy(S.I);tax=copy.deepcopy(S.T)
  for day,prices in data['daily']:
   if day>cutoff:
    for k in range(2):prices[k]*=4+k
  for asset in tax.values():
   for day in asset['dividendEvidence']['fractions']:
    if day>cutoff:asset['dividendEvidence']['fractions'][day]=.02
  altered=S.run(S.Market(data,tax),o,[.3,.3],tax=.2,fee=.001,delay=delay,trace=True)
  for key,datefield in [('curve','date'),('plans','signalDate'),('fills','date')]:
   a=[r for r in original[key] if r[datefield]<=cutoff];b=[r for r in altered[key] if r[datefield]<=cutoff];assert a==b,(delay,start,key)
  check('Future prices and dividend fractions cannot change past plans, fills, tax or wealth',delay=delay,start=start,cutoff=cutoff)
# Verify every retained full trace: plan math only reads its recorded prior snapshot; fill amounts equal immutable plans.
T=json.loads((P/'traces.json').read_text());planCount=fillCount=points=0
for case in T['traces']:
 w=case['weights'];W=sum(w);fee=case['fee'];a=case['account'];index=(S.EXTERNAL if case['universe']=='external' else S.ETF).idx
 for p in a['plans']:
  v=p['snapshot'];B=max(0,min(v['cash']/(1+fee),(W*v['grossValue']-v['stock'])/(1+W*fee)));g=[max(0,w[k]*v['grossValue']-v['units'][k]*v['prices'][k]) for k in range(2)];gs=sum(g)
  assert v['stockFraction']<W;assert max(abs(p['notionals'][k]-B*g[k]/gs) for k in range(2))<1e-8;assert sum(p['notionals'])*(1+fee)<=v['cash']+1e-8;planCount+=1
 for f in a['fills']:
  assert index[f['date']]-index[f['signalDate']]==1+case['extraDelay'];assert max(abs(a-b) for a,b in zip(f['notionals'],f['plannedNotionals']))<1e-8;assert abs(f['cashCapScale']-1)<1e-12;fillCount+=1
 for p in a['curve']:
  assert abs(p['grossValue']-p['cash']-p['stock'])<1e-8;assert abs(p['value']-p['grossValue']+p['taxReserve'])<1e-8;assert p['cash']>=-1e-8;points+=1
check('All retained full traces satisfy prior-snapshot order sizing, immutable fill amounts and cash/tax identities',plans=planCount,fills=fillCount,valuationPoints=points)
R=json.loads((P/'results.json').read_text());count=sum(len(g['rows']) for g in R['groups'])
assert len(R['groups'])==100 and count==5204
assert all(g['risk']['materialCashCaps']==0 for g in R['groups'])
check('Complete fixed grid retained with no material cash overcommitment',groups=100,pairedAccounts=count)
out={'passed':True,'checks':checks,'sourceHashes':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in ['protocol.json','study.py','results.json','traces.json','verify.py']}}
S.save('verification.json',out);print(json.dumps(out,ensure_ascii=False,indent=2))
