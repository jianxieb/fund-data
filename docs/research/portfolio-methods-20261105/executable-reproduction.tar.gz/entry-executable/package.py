from pathlib import Path
import tarfile,json,hashlib,gzip
P=Path(__file__).resolve().parent
skip={'reproduction.tar.gz','manifest.json'}
files=sorted(p for p in P.rglob('*') if p.is_file() and p.name not in skip and '__pycache__' not in p.parts and 'report' not in p.relative_to(P).parts)
metadata=[{'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
with (P/'reproduction.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(mode='w',fileobj=gz) as archive:
   for p in files:
    info=archive.gettarinfo(str(p),arcname='entry-executable/'+str(p.relative_to(P)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as src:archive.addfile(info,src)
with tarfile.open(P/'reproduction.tar.gz') as archive:
 for meta in metadata:
  data=archive.extractfile('entry-executable/'+meta['path']).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
manifest={'archive':{'file':'reproduction.tar.gz','bytes':(P/'reproduction.tar.gz').stat().st_size,'sha256':hashlib.sha256((P/'reproduction.tar.gz').read_bytes()).hexdigest()},'members':metadata,'replayEvidence':json.loads((P/'replay-check.json').read_text()),'counts':json.loads((P/'compact-summary.json').read_text())['counts']}
(P/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'archive':manifest['archive'],'members':len(metadata),'allMemberHashesVerified':True},indent=2))
