"""Reproduce only in a new directory, leaving frozen evidence untouched."""
from pathlib import Path
import argparse,shutil,subprocess,sys,json,hashlib
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--destination',type=Path,default=P/'rerun');args=parser.parse_args();dest=args.destination.resolve()
if dest.exists():raise SystemExit('Refuse existing destination: '+str(dest))
dest.mkdir(parents=True)
files=['study.py','protocol.json','source-provenance.json','inputs.json','tax-inputs.json','external-inputs.json','old-taxed-results.json','old-pretax-results.json','old-external-results.json','verify.py','independent-audit.cjs','production-audit.cjs']
for f in files:shutil.copyfile(P/f,dest/f)
shutil.copytree(P/'production',dest/'production')
for command in [[sys.executable,'study.py','core'],[sys.executable,'study.py','evaluate'],[sys.executable,'verify.py'],['node','independent-audit.cjs'],['node','production-audit.cjs']]:
 completed=subprocess.run(command,cwd=dest,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 with (dest/'replay.log').open('a') as out:out.write('COMMAND '+repr(command)+'\n'+completed.stdout+'\n')
 if completed.returncode:raise SystemExit(completed.stdout)
 print('Completed '+' '.join(command),flush=True)
outputs=['core-results.json','results.json','summary.json','traces.json','verification.json','independent-audit.json','production-audit.json']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparison={f:{'original':sha(P/f),'reproduced':sha(dest/f),'equal':sha(P/f)==sha(dest/f)} for f in outputs}
(dest/'replay-check.json').write_text(json.dumps(comparison,indent=2)+'\n')
if not all(r['equal'] for r in comparison.values()):raise SystemExit('Some outputs differ; inspect replay-check.json')
print('All7 outputs match byte for byte.')
