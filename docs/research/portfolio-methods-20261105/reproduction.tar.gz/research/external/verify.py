"""Arithmetic, self-financing, timing and causal-prefix checks of frozen external study."""
from pathlib import Path
import json,math,hashlib
import study as S
HERE=Path(__file__).resolve().parent
results=json.loads((HERE/'results.json').read_text());traces=json.loads((HERE/'traces.json').read_text())
error={'analyticalLumpEndpoint':0.,'traceDailyValue':0.,'traceCash':0.,'defaultResults':0.}
for case in results['results']:
    for r in case['baseline']:
        p0,p1=S.PRICES[S.INDEX[r['start']]],S.PRICES[S.INDEX[r['end']]]
        analytic=40+30/(1+case['fee'])*(p1[0]/p0[0]+p1[1]/p0[1])
        e=abs(analytic-r['value']);error['analyticalLumpEndpoint']=max(error['analyticalLumpEndpoint'],e);assert e<1e-8
    assert case['summary']['missingDecisions']==0
for account in traces['accounts']:
    bydate={}
    for t in account['trades']:bydate.setdefault(t['date'],[]).append(t)
    units=[0.,0.];cash=100.
    for r in account['curve']:
        i=S.INDEX[r['date']];prices=S.PRICES[i]
        for t in bydate.get(r['date'],[]):
            sign=1 if t['side']=='buy' else -1
            cash-=sign*t['amount']+t['fee'];units[t['leg']]+=sign*t['amount']/prices[t['leg']]
            assert cash>=40-1e-8 and min(units)>=-1e-8
            if t['leg']==1:assert t['proxyDate']<=t['signalDate']<t['date']
        reconstructed=cash+sum(q*p for q,p in zip(units,prices))
        for name,e in [('traceDailyValue',abs(reconstructed-r['value'])),('traceCash',abs(cash-r['cash']))]:
            error[name]=max(error[name],e);assert e<1e-8,(name,e)
    frozen=next(r for c in results['results'] if c['phase']==0 and c['fee']==.001 and c['years']==20 for r in c['rows'] if r['start']==account['start'])
    e=abs(account['value']-frozen['value']);error['defaultResults']=max(error['defaultResults'],e);assert e<1e-9
# Causal prefix invariance: mutate all fund/QQQ prices strictly after cutoff and
# re-evaluate the same full-horizon account. Earlier orders/value remain exact.
S.FEATURES=S.features();origin=S.PERIODS[20][0];cutoff='2007-01-03'
before=S.account(origin,trace=True)
oldprices=[p[:] for p in S.PRICES];oldqq=[r[:] for r in S.DATA['proxies']['us:QQQ']['series']]
for i,d in enumerate(S.DAYS):
    if d>cutoff:S.PRICES[i]=[oldprices[i][0]*(2+(i%7)/10),oldprices[i][1]*(.25+(i%11)/20)]
for i,r in enumerate(S.DATA['proxies']['us:QQQ']['series']):
    if r[0]>cutoff:r[1]*=2+(i%13)/7
S.FEATURES=S.features();after=S.account(origin,trace=True)
assert [r for r in before['trades'] if r['date']<=cutoff]==[r for r in after['trades'] if r['date']<=cutoff]
assert [r for r in before['curve'] if r['date']<=cutoff]==[r for r in after['curve'] if r['date']<=cutoff]
assert before['value']!=after['value']
S.PRICES[:]=oldprices;S.DATA['proxies']['us:QQQ']['series'][:]=oldqq
out={'status':'PASS','checks':['all 6165 reported paired baselines equal analytical buy-and-hold endpoint','three 20-year daily paths replay from exported transactions and self-finance','all 45 cases have no missing signal','order proxy dates <= signal date < execution date','mutating future fund and QQQ prices leaves all prior trades and daily values exactly unchanged','permanent cash never below40 in all traced orders'],'maximumAbsoluteErrors':error,'causalPrefixCutoff':cutoff,'resultsSHA256':hashlib.sha256((HERE/'results.json').read_bytes()).hexdigest(),'verifyCodeSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (HERE/'verification.json').open('x') as f:json.dump(out,f,separators=(',',':'))
print(json.dumps(out,indent=2))
