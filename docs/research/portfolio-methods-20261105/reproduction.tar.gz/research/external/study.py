"""Independent fixed-rule validation on actual historical SMPIX/UOPIX fund returns.
No import of risk/study.cjs or its ledger; only its documented locked rule is copied.
"""
from pathlib import Path
from datetime import date,datetime,timezone
from collections import defaultdict,Counter
import json,math,statistics,bisect,hashlib,sys

HERE=Path(__file__).resolve().parent
INPUT=HERE.parent/'external-inputs.json'
SHA=lambda b:hashlib.sha256(b).hexdigest()
BYTES=INPUT.read_bytes(); DATA=json.loads(BYTES)
DAYS=[r[0] for r in DATA['daily']]; PRICES=[r[1] for r in DATA['daily']]; INDEX={d:i for i,d in enumerate(DAYS)}
ORIGINS=DATA['origins']; PERIODS={y:[o for o in ORIGINS if o['years']==y] for y in [10,15,20]}
assert [len(PERIODS[y]) for y in [10,15,20]]==[197,137,77]
assert len(DAYS)==len(set(DAYS)) and DAYS==sorted(DAYS)
assert all(all(p>0 and math.isfinite(p) for p in r) for r in PRICES)
RULE={'proxy':'us:QQQ','priceBelowSMA':200,'sampleLogReturnVolatilityDays':21,'annualizeTradingDays':252,'volatilityGreaterThan':.30,'reviewEveryCommonDates':5,'defaultPhase':0,'riskOffTarget':0,'riskOnTarget':1,'managedLeg':1}
CONFIG={'weights':[.3,.3],'initialCapital':100,'permanentCash':40,'feeEachBuyOrSell':[.001,.002,.005],'phases':[0,1,2,3,4],'interest':0,'externalDeposits':0,'tax':0,'terminalLiquidation':False}

def save(name,x):
    with (HERE/name).open('x') as f:json.dump(x,f,separators=(',',':'))

def freeze():
    save('protocol.json',{'createdUTC':datetime.now(timezone.utc).isoformat(),'inputSHA256':SHA(BYTES),'codeSHA256':SHA(Path(__file__).read_bytes()),'rule':RULE,'config':CONFIG,
      'assets':['Actual SMPIX daily 1.5x semiconductor mutual fund USD total return','Actual UOPIX daily 2x Nasdaq100 mutual fund USD total return'],
      'scope':'External historical support or refutation of the already fixed 200/30/5 Nasdaq sleeve switch. Never describe these as TQQQ, USD ETF, or their pre-listing history. No external-result parameter selection.',
      'ledger':'Each initial 30 USD sleeve budget funds its own initial buy fee. SMPIX stays fully invested; only UOPIX pool alternates fully invested/cash. Permanent 40 cash never deployed. Trade costs deducted from the relevant sleeve; no transfers between sleeves or extra money.',
      'signals':'QQQ adjusted close below its inclusive 200-observation simple average AND sample SD of the latest 21 daily log returns times sqrt(252)>0.30 makes UOPIX target zero, otherwise one. Use latest QQQ observation <= previous common fund date, never same-day. Ignore stale proxy older than 7 calendar days and retain preceding target (initial target one), with every missing decision counted.',
      'schedule':'Initial account day always applies existing previous-date signal. Later checks when global common-date zero-based index modulo5 equals phase. Default phase0, independent of each entry date. All phases0..4 and all fees0.1/0.2/0.5% form a complete 15-case sensitivity grid; no winner selected.',
      'evaluation':'All provided full10y197,full15y137,full20y77 monthly origins; same exact start/end and fee vs own-sleeve lump sum. No split/tuning within this external data. These overlapping historical windows are not independent samples or prospective forecasts.',
      'comparisonMetric':'For each paired account compute CAGR difference pp; average within entry calendar year and then equally across entry years. Also all win/tie/loss counts, terminal wealth relative difference, MDD, daily CVaR, cash/exposure, actual gross purchases, fees, turnover.',
      'source':DATA['source'],'originCounts':{str(y):len(oo) for y,oo in PERIODS.items()}})
    print('External protocol frozen; no external performance evaluated.')

def features():
    rr=DATA['proxies']['us:QQQ']['series']; qqdates=[r[0] for r in rr]; qq=[r[1] for r in rr]
    assert qqdates==sorted(qqdates) and len(qqdates)==len(set(qqdates))
    result=[]
    for i,d in enumerate(DAYS):
        if i==0:result.append(None);continue
        prior=DAYS[i-1];j=bisect.bisect_right(qqdates,prior)-1
        if j<199 or (date.fromisoformat(prior)-date.fromisoformat(qqdates[j])).days>7:result.append(None);continue
        logs=[math.log(qq[k]/qq[k-1]) for k in range(j-20,j+1)]
        ma=statistics.mean(qq[j-199:j+1]);vol=statistics.stdev(logs)*math.sqrt(252)
        result.append({'signalDate':prior,'proxyDate':qqdates[j],'proxyPrice':qq[j],'sma200':ma,'vol21Annualized':vol,'off':qq[j]<ma and vol>.30})
    return result

FEATURES=None

def account(o,fee=.001,phase=0,hold=False,trace=False):
    first,last=INDEX[o['start']],INDEX[o['end']]
    units0=30/(1+fee)/PRICES[first][0]
    units1=0.;cash=30.;fees=30*fee/(1+fee);purchased=30/(1+fee);sold=0.;turnover=(30/(1+fee))/100
    target=1;peak=100.;mdd=0.;max_exp=0.;min_cash=70.;exposure_sum=0.;missing=0;decisions=0;count=1;values=[];trades=[];curve=[]
    if trace:trades.append({'date':DAYS[first],'signalDate':None,'leg':0,'side':'buy','amount':purchased,'fee':fees,'quantity':units0,'reason':'initial_unmanaged_hold'})
    for i in range(first,last+1):
        p0,p1=PRICES[i]
        if i==first or (not hold and i%5==phase):
            if not hold:
                signal=FEATURES[i];decisions+=1
                if signal is None:missing+=1
                else:target=0 if signal['off'] else 1
            else:signal=None
            before=40+units0*p0+cash+units1*p1
            if target==1 and cash>0:
                amount=cash/(1+fee);charge=amount*fee
                units1+=amount/p1;cash=0.;fees+=charge;purchased+=amount;turnover+=amount/before;count+=1
                if trace:trades.append({'date':DAYS[i],'signalDate':signal['signalDate'] if signal else None,'proxyDate':signal['proxyDate'] if signal else None,'leg':1,'side':'buy','amount':amount,'fee':charge,'quantity':amount/p1,'target':target})
            elif target==0 and units1>0:
                amount=units1*p1;charge=amount*fee
                cash=amount-charge;units1=0.;fees+=charge;sold+=amount;turnover+=amount/before;count+=1
                if trace:trades.append({'date':DAYS[i],'signalDate':signal['signalDate'],'proxyDate':signal['proxyDate'],'leg':1,'side':'sell','amount':amount,'fee':charge,'target':target})
        stock=units0*p0+units1*p1;value=40+cash+stock
        assert cash>=0 and value>0 and stock/value<=1+1e-12
        peak=max(peak,value);mdd=min(mdd,100*(value/peak-1));max_exp=max(max_exp,stock/value);min_cash=min(min_cash,40+cash);exposure_sum+=stock/value;values.append(value)
        if trace:curve.append({'date':DAYS[i],'value':value,'cash':40+cash,'permanentCash':40,'stock':stock,'managedSleeveCash':cash,'units':[units0,units1],'target':target})
    elapsed=(date.fromisoformat(o['end'])-date.fromisoformat(o['start'])).days/365.2425
    rr=sorted(100*(values[k]/values[k-1]-1) for k in range(1,len(values)))
    r={'start':o['start'],'end':o['end'],'years':o['years'],'value':value,'annualReturn':100*((value/100)**(1/elapsed)-1),'mdd':mdd,'dailyCVaR95Pct':statistics.mean(rr[:math.ceil(.05*len(rr))]),'maxStockExposure':max_exp,'meanStockExposure':exposure_sum/len(values),'minimumCash':min_cash,'finalCash':40+cash,'permanentCash':40,'totalFees':fees,'actualPurchaseNotional':purchased,'actualSaleNotional':sold,'turnoverPct':100*turnover,'annualTurnoverPct':100*turnover/elapsed,'transactions':count,'missingDecisions':missing,'decisions':decisions}
    if trace:r.update(trades=trades,curve=curve)
    return r

MED=statistics.median
MEAN=statistics.mean

def compare(rows,base):
    years=defaultdict(list);d=[];wealth=[]
    for r,b in zip(rows,base):
        assert (r['start'],r['end'])==(b['start'],b['end'])
        x=r['annualReturn']-b['annualReturn'];d.append(x);wealth.append(100*(r['value']/b['value']-1));years[r['start'][:4]].append(x)
    return {'n':len(rows),'yearEqualCAGRpp':MEAN(MEAN(v) for v in years.values()),'meanCAGRpp':MEAN(d),'wins':sum(x>1e-9 for x in d),'ties':sum(abs(x)<=1e-9 for x in d),'losses':sum(x< -1e-9 for x in d),'medianWealthRelativePct':MED(wealth),'minimumWealthRelativePct':min(wealth),'maximumWealthRelativePct':max(wealth),'medianCAGR':MED(r['annualReturn'] for r in rows),'medianMDD':MED(r['mdd'] for r in rows),'worstMDD':min(r['mdd'] for r in rows),'medianPairedMDDChangePP':MED(r['mdd']-b['mdd'] for r,b in zip(rows,base)),'medianDailyCVaR95Pct':MED(r['dailyCVaR95Pct'] for r in rows),'medianTransactionFees':MED(r['totalFees'] for r in rows),'medianActualPurchaseNotional':MED(r['actualPurchaseNotional'] for r in rows),'medianActualSaleNotional':MED(r['actualSaleNotional'] for r in rows),'medianAnnualTurnoverPct':MED(r['annualTurnoverPct'] for r in rows),'medianTransactions':MED(r['transactions'] for r in rows),'minCashAcrossAccounts':min(r['minimumCash'] for r in rows),'maxStockExposure':max(r['maxStockExposure'] for r in rows),'meanOfMeanStockExposure':MEAN(r['meanStockExposure'] for r in rows),'missingDecisions':sum(r['missingDecisions'] for r in rows),'accountsWithAnyMissingSignal':sum(r['missingDecisions']>0 for r in rows),'baseline':{'medianCAGR':MED(r['annualReturn'] for r in base),'medianMDD':MED(r['mdd'] for r in base),'worstMDD':min(r['mdd'] for r in base),'medianDailyCVaR95Pct':MED(r['dailyCVaR95Pct'] for r in base),'medianTransactionFees':MED(r['totalFees'] for r in base),'meanOfMeanStockExposure':MEAN(r['meanStockExposure'] for r in base)},'byEntryYear':{y:{'n':len(v),'meanCAGRpp':MEAN(v)} for y,v in years.items()}}

def evaluate():
    global FEATURES
    protocol=json.loads((HERE/'protocol.json').read_text())
    assert protocol['inputSHA256']==SHA(BYTES) and protocol['codeSHA256']==SHA(Path(__file__).read_bytes())
    assert protocol['rule']==RULE and protocol['config']==CONFIG
    FEATURES=features()
    coverage={str(y):{'n':len(oo),'originsWithPriorQQQ200And21':sum(FEATURES[INDEX[o['start']]] is not None for o in oo),'firstOrigin':oo[0]['start'],'lastOrigin':oo[-1]['start']} for y,oo in PERIODS.items()}
    out=[]
    for fee in CONFIG['feeEachBuyOrSell']:
        baselines={y:[account(o,fee=fee,hold=True) for o in oo] for y,oo in PERIODS.items()}
        for phase in CONFIG['phases']:
            for y,oo in PERIODS.items():
                rows=[account(o,fee=fee,phase=phase) for o in oo];summary=compare(rows,baselines[y])
                out.append({'fee':fee,'phase':phase,'years':y,'summary':summary,'rows':rows,'baseline':baselines[y]})
                print(json.dumps({'fee':fee,'phase':phase,'years':y,'yearEqualCAGRpp':summary['yearEqualCAGRpp'],'wins':summary['wins'],'ties':summary['ties'],'losses':summary['losses'],'MDD':summary['medianMDD'],'baselineMDD':summary['baseline']['medianMDD'],'missing':summary['missingDecisions']}),flush=True)
    traces=[]
    for o in [PERIODS[20][0],PERIODS[20][38],PERIODS[20][-1]]:traces.append(account(o,trace=True))
    for r in traces:
        for t in r['trades']:
            if t['leg']==1:assert t['proxyDate']<=t['signalDate']<t['date']
        assert all(r['permanentCash']==40 and r['cash']>=40 for r in r['curve'])
    save('results.json',{'protocolSHA256':SHA((HERE/'protocol.json').read_bytes()),'inputSHA256':SHA(BYTES),'codeSHA256':SHA(Path(__file__).read_bytes()),'implementation':'Independent Python ledger and rolling signal calculation; no imports of existing JS study/ledger. Baseline independently includes same per-sleeve fees.','coverage':coverage,'results':out})
    save('traces.json',{'rule':RULE,'fee':.001,'phase':0,'accounts':traces})
    save('summary.json',{'coverage':coverage,'cases':[{k:r[k] for k in ['fee','phase','years','summary']} for r in out]})

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Use freeze or evaluate')
    if sys.argv[1]=='freeze':freeze()
    elif sys.argv[1]=='evaluate':evaluate()
    else:raise SystemExit('Use freeze or evaluate')
