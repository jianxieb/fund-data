const fs=require('fs'),assert=require('assert/strict');
const P=require('/Users/ajin/Projects/fund-data/assets/portfolio-model.js');
const I=JSON.parse(fs.readFileSync(__dirname+'/inputs.json')),T=JSON.parse(fs.readFileSync(__dirname+'/tax-inputs.json'));
const ids=['us:USD','us:TQQQ'],days=new Set(I.daily.map(r=>r[0]));
const catalog={assets:ids.map(id=>({id,code:id.slice(3),name:id,currency:'CNY',market:'us',kind:'etf',status:'available'}))};
const histories=Object.fromEntries(ids.map((id,j)=>[id,{schemaVersion:1,id,currency:'CNY',basis:'provider_adjusted_close',dividends:'reinvested',first:I.daily[0][0],asOf:I.daily.at(-1)[0],series:I.daily.map(r=>[r[0],r[1][j]]),dividendEvidence:{...T[id].dividendEvidence,fractions:Object.fromEntries(Object.entries(T[id].dividendEvidence.fractions).filter(([d])=>days.has(d)))}}]));
let count=0,maxValueError=0,maxMDDError=0,maxTaxError=0;const cases=[];
for(const file of ['taxed-results.json','pretax-results.json'])for(const c of JSON.parse(fs.readFileSync(__dirname+'/rebalance-daily/'+file)).results.filter(c=>c.extraDelay===0))for(const [j,o] of c.rows.entries())for(const method of ['lump_sum','cash_topup']){
 const config={positions:ids.map((id,k)=>({id,weight:c.weights[k]*100})),currency:'CNY',initial:100,monthly:0,years:'custom',start:o.start,end:o.end,initialMethod:method,contributionMethod:'dca_month',rebalance:'none',transactionFee:c.fee*100,feeBasis:'net',tax:{usCapitalGains:c.tax.capitalGains*100,usDividend:c.tax.dividends*100,liquidate:false}};
 const r=P.simulate({catalog,histories,config});assert(!r.error,r.error);const e=method==='cash_topup'?o:c.baseline[j];
 const ve=Math.abs(r.value-e.value),me=Math.abs(r.mdd-e.mdd),te=Math.abs(r.taxCost-e.taxCost);
 maxValueError=Math.max(maxValueError,ve);maxMDDError=Math.max(maxMDDError,me);maxTaxError=Math.max(maxTaxError,te);assert(ve<1e-6,JSON.stringify({method,c,ve}));assert(me<1e-6);assert(te<1e-6);assert(Math.abs(r.cash-e.finalCash)<1e-7);assert.equal(r.contributed,100);
 if(method==='cash_topup'){assert.equal(r.topupTimes,e.additionalBuyDates);assert(Math.abs(r.topupAmount-e.additionalPurchaseNotional)<1e-7);}
 count++;cases.push({method,weights:c.weights,tax:c.tax,fee:c.fee,start:o.start,end:o.end,value:r.value,mdd:r.mdd});
}
const out={cases:count,maxValueError,maxMDDError,maxTaxError,basis:'Frozen common-date CNY prices; production model and independent Python tax-aware cash top-up ledger',results:cases};fs.writeFileSync(__dirname+'/production-cash-audit.json',JSON.stringify(out));console.log(JSON.stringify({...out,results:undefined}));
