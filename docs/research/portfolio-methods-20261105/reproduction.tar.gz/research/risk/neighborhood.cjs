'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const S=require('./study.cjs'),T=require('./stage2.cjs');
const protocol=JSON.parse(fs.readFileSync(path.join(__dirname,'neighborhood-protocol.json')));
assert.equal(protocol.inputSHA256,S.provenance.input);
// Add exactly the two predeclared MA neighbors using the same own-calendar
// inclusive observations as the original200 window; do not change frozen fields.
for(const [j,id] of ['us:SOXX','us:QQQ'].entries()){
 const rows=S.data.proxies[id].series,byDate=new Map();
 for(let i=0;i<rows.length;i++)byDate.set(rows[i][0],Object.fromEntries([150,200,250].map(n=>[n,i>=n-1?rows.slice(i-n+1,i+1).reduce((s,r)=>s+r[1],0)/n:null])));
 for(const f of S.featureRows){const p=f.proxies[j];if(!p)continue;const m=byDate.get(p.date);assert(m);assert(p.ma[200]===m[200]);p.ma[150]=m[150];p.ma[250]=m[250];}
}
const results=[];
for(const c of protocol.candidates)for(const weights of protocol.weights)for(const[label,origins]of Object.entries(T.periods)){
 const rows=origins.map(o=>T.account(o,weights,c,protocol.mask));
 const baseline=origins.map(o=>T.account(o,weights,c,[false,false]));
 results.push({c,weights,label,summary:T.compare(rows,baseline),rows});
}
const original=JSON.parse(fs.readFileSync(path.join(__dirname,'stage2-results.json')));
for(const r of results.filter(r=>r.c.ma===200&&r.c.vol===.3&&r.c.every===5)){
 const match=original.results.find(x=>x.maskName==='tqqq_only'&&x.weights.join()===r.weights.join()&&x.label===r.label);
 assert.deepEqual(r.summary,match.summary);assert.deepEqual(r.rows,match.rows);
}
T.write('neighborhood-results.json',{input:S.provenance.input,protocolSHA256:T.hash(fs.readFileSync(path.join(__dirname,'neighborhood-protocol.json'))),codeSHA256:T.hash(fs.readFileSync(__filename)),centerExactlyReproduced:true,results});
const summary=protocol.weights.flatMap(weights=>Object.keys(T.periods).map(label=>{
 const r=results.filter(r=>r.weights.join()===weights.join()&&r.label===label),v=r.map(r=>r.summary.yearEqualCAGRpp);
 return{weights,label,n:r.length,positive:r.filter(r=>r.summary.yearEqualCAGRpp>0).length,min:Math.min(...v),max:Math.max(...v),worstWinCount:Math.min(...r.map(r=>r.summary.wins)),bestWinCount:Math.max(...r.map(r=>r.summary.wins))};
}));
T.write('neighborhood-summary.json',summary);console.log(JSON.stringify(summary,null,2));
