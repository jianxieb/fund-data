'use strict';
const assert=require('assert/strict'),S=require('./study.cjs');
const {data,featureRows,fractions}=S,daily=data.daily,index=new Map(daily.map((r,i)=>[r[0],i])),year=365.2425;
const sum=v=>v.reduce((a,b)=>a+b,0);
function account(o,weights,c,mask,trace=false,{fee=.001,phase=0,delay=0}={}){
 assert(fee>=0&&fee<=.005&&phase>=0&&phase<c.every&&[0,1].includes(delay));
 const first=index.get(o.start),last=index.get(o.end);assert(first!=null&&last!=null);
 const permanent=100*(1-sum(weights)),cash=weights.map(w=>100*w),units=[0,0];
 let target=[1,1],peak=100,mdd=0,maxExposure=0,totalFees=0,transactions=0,value=100;
 const trades=[],curve=[];
 for(let i=first;i<=last;i++){
  const [date,prices]=daily[i];
  const mark=units.map((u,j)=>u*prices[j]);
  const before=permanent+sum(cash)+sum(mark);maxExposure=Math.max(maxExposure,sum(mark)/before);
  if(i===first+delay||i>first+delay&&mask.some(Boolean)&&(i-delay)%c.every===phase){
   target=fractions(c,i-1-delay,target).map((f,j)=>mask[j]?f:1);
   for(let j=0;j<2;j++){
    const v=units[j]*prices[j],equity=cash[j]+v,f=target[j];let desired=f*equity;
    if(desired>v)desired=f*(equity+fee*v)/(1+f*fee);
    else if(desired<v)desired=f*(equity-fee*v)/(1-f*fee);
    const delta=desired-v;if(Math.abs(delta)<=Math.max(1,equity)*1e-12)continue;
    const cost=Math.abs(delta)*fee;units[j]=desired/prices[j];cash[j]-=delta+cost;
    assert(cash[j]>=-1e-8&&units[j]>=-1e-9);if(Math.abs(cash[j])<1e-10)cash[j]=0;
    totalFees+=cost;transactions++;
    if(trace)trades.push({day:date,signalDay:daily[i-1-delay]?.[0]??null,proxyDay:featureRows[i-1-delay]?.proxies[j]?.date??null,leg:j,side:delta>0?'buy':'sell',amount:Math.abs(delta),fee:cost,target:f,cash:cash[j],units:units[j]});
   }
  }
  const market=sum(units.map((u,j)=>u*prices[j]));value=permanent+sum(cash)+market;
  peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));maxExposure=Math.max(maxExposure,market/value);
  if(trace)curve.push({day:date,value,market,cash:permanent+sum(cash),permanentCash:permanent,units:units.slice(),sleeveCash:cash.slice()});
 }
 assert(maxExposure<=1+1e-8);
 return{start:o.start,end:o.end,years:o.years,weights,value,annualReturn:100*((value/100)**(year/((Date.parse(o.end)-Date.parse(o.start))/864e5))-1),mdd,maxExposure,totalFees,transactions,permanentCash:permanent,finalCash:permanent+sum(cash),...(trace?{trades,curve}:{})};
}
module.exports={account};
