'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const S=require('./study.cjs'),{data,featureRows,fractions,compare}=S,DIR=__dirname;
const protocol=JSON.parse(fs.readFileSync(path.join(DIR,'stage2-protocol.json'))),daily=data.daily;
const index=new Map(daily.map((r,i)=>[r[0],i])),fee=.001,year=365.2425;
const sum=v=>v.reduce((a,b)=>a+b,0),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function account(o,weights,c,mask,trace=false){
 const first=index.get(o.start),last=index.get(o.end);assert(first!=null&&last!=null);
 const permanent=100*(1-sum(weights)),cash=weights.map(w=>100*w),units=[0,0];
 let target=[1,1],peak=100,mdd=0,maxExposure=0,totalFees=0,transactions=0,value=100;
 const trades=[],curve=[];
 for(let i=first;i<=last;i++){
  const [date,prices]=daily[i];
  const mark=units.map((u,j)=>u*prices[j]);
  const before=permanent+sum(cash)+sum(mark);maxExposure=Math.max(maxExposure,sum(mark)/before);
  if(i===first||mask.some(Boolean)&&i%c.every===0){
   target=fractions(c,i-1,target).map((f,j)=>mask[j]?f:1);
   for(let j=0;j<2;j++){
    const v=units[j]*prices[j],equity=cash[j]+v,f=target[j];let desired=f*equity;
    if(desired>v)desired=f*(equity+fee*v)/(1+f*fee);
    else if(desired<v)desired=f*(equity-fee*v)/(1-f*fee);
    const delta=desired-v;if(Math.abs(delta)<=Math.max(1,equity)*1e-12)continue;
    const cost=Math.abs(delta)*fee;units[j]=desired/prices[j];cash[j]-=delta+cost;
    assert(cash[j]>=-1e-8&&units[j]>=-1e-9);if(Math.abs(cash[j])<1e-10)cash[j]=0;
    totalFees+=cost;transactions++;
    if(trace)trades.push({day:date,signalDay:daily[i-1]?.[0]??null,proxyDay:featureRows[i-1]?.proxies[j]?.date??null,leg:j,side:delta>0?'buy':'sell',amount:Math.abs(delta),fee:cost,target:f,cash:cash[j],units:units[j]});
   }
  }
  const market=sum(units.map((u,j)=>u*prices[j]));value=permanent+sum(cash)+market;
  peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));maxExposure=Math.max(maxExposure,market/value);
  if(trace)curve.push({day:date,value,market,cash:permanent+sum(cash),permanentCash:permanent,units:units.slice(),sleeveCash:cash.slice()});
 }
 assert(maxExposure<=1+1e-8);
 return{start:o.start,end:o.end,years:o.years,weights,value,annualReturn:100*((value/100)**(year/((Date.parse(o.end)-Date.parse(o.start))/864e5))-1),mdd,maxExposure,totalFees,transactions,permanentCash:permanent,finalCash:permanent+sum(cash),...(trace?{trades,curve}:{})};
}
const periods={development28:data.origins.filter(o=>o.years===10&&o.start>='2011-09'&&o.start<'2014'),later35:data.origins.filter(o=>o.years===10&&o.start>='2014'&&o.start<'2017'),all10_81:data.origins.filter(o=>o.years===10),all15_21:data.origins.filter(o=>o.years===15)};
assert.deepEqual(Object.values(periods).map(v=>v.length),[28,35,81,21]);
function write(name,d){const p=path.join(DIR,name);assert(!fs.existsSync(p),'Refuse overwrite '+p);fs.writeFileSync(p,JSON.stringify(d,null,2)+'\n');}
if(require.main===module){
 const results=[];
 for(const[maskName,mask]of Object.entries(protocol.masks))for(const weights of protocol.weights)for(const[label,origins]of Object.entries(periods)){
  const rows=origins.map(o=>account(o,weights,protocol.lockedRule,mask)),baseline=origins.map(o=>account(o,weights,protocol.lockedRule,[false,false]));
  results.push({maskName,mask,weights,label,summary:compare(rows,baseline),rows,baseline});
 }
 write('stage2-results.json',{provenance:S.provenance,protocolSHA256:hash(fs.readFileSync(path.join(DIR,'stage2-protocol.json'))),codeSHA256:hash(fs.readFileSync(__filename)),results});
 const o=periods.later35[0];
 const old=S.runAccount(o,[.3,.3],protocol.lockedRule,true),same=account(o,[.3,.3],protocol.lockedRule,[true,true],true);
 assert(Math.abs(old.value-same.value)<1e-10&&Math.abs(old.mdd-same.mdd)<1e-10);
 for(const k of ['cash','value'])old.curve.forEach((r,i)=>assert(Math.abs(r[k]-same.curve[i][k])<1e-9));
 write('stage2-trace-example.json',{check:'same both-leg engine matches frozen original daily cash/value on first later start',trace:account(o,[.3,.3],protocol.lockedRule,[false,true],true)});
 console.log(JSON.stringify(results.map(r=>({mask:r.maskName,w:r.weights,p:r.label,...r.summary})),null,2));
}
module.exports={account,periods,protocol,compare,write,hash};
