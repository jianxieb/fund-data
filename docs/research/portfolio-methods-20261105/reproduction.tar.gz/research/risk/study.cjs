'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const DIR=__dirname, INPUT=path.join(DIR,'../inputs.json');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const inputBytes=fs.readFileSync(INPUT), data=JSON.parse(inputBytes), protocol=JSON.parse(fs.readFileSync(path.join(DIR,'protocol.json')));
assert.equal(hash(inputBytes),protocol.inputsSHA256);
const fee=protocol.feePctEachSide/100, dayms=86400000,YEAR=365.2425;
const daily=data.daily, dates=daily.map(r=>r[0]), index=new Map(dates.map((d,i)=>[d,i]));
const sum=v=>v.reduce((a,b)=>a+b,0), mean=v=>v.length?sum(v)/v.length:null;
const median=v=>{v=v.slice().sort((a,b)=>a-b);return v.length?(v[(v.length-1)>>1]+v[v.length>>1])/2:null;};
const span=(a,b)=>(Date.parse(b)-Date.parse(a))/dayms;
function sampleSd(v){const m=mean(v);return Math.sqrt(sum(v.map(x=>(x-m)**2))/(v.length-1));}
function proxyFeatures(series){
 const rows=[], log=[];
 for(let i=0;i<series.length;i++){
  if(i)log.push(Math.log(series[i][1]/series[i-1][1]));
  rows.push({date:series[i][0],value:series[i][1],vol:log.length>=21?sampleSd(log.slice(-21))*Math.sqrt(252):null,
   ma:Object.fromEntries([50,100,200].map(n=>[n,i>=n-1?mean(series.slice(i-n+1,i+1).map(r=>r[1])):null]))});
 }
 return rows;
}
const proxies=['us:SOXX','us:QQQ'].map(id=>proxyFeatures(data.proxies[id].series));
function latest(rows,date,strict=false){let a=0,b=rows.length;while(a<b){const m=(a+b)>>1;if((rows[m].date??rows[m][0]) < date || !strict&&(rows[m].date??rows[m][0])===date)a=m+1;else b=m;}return a?rows[a-1]:null;}
const featureRows=dates.map(date=>{
 const v=latest(data.vix,date,true),p=proxies.map(rows=>latest(rows,date));
 return{date,vix:v&&span(v[0],date)<=7?v[1]/v[2]:null,vixDay:v?.[0]??null,
  proxies:p.map(x=>x&&span(x.date,date)<=7?x:null)};
});
function fractions(c,i,old){
 const f=featureRows[i];if(!f)return old;
 if(c.family==='vix_hysteresis'){
  if(f.vix==null)return old;
  if(f.vix>c.high)return[c.off,c.off];if(f.vix<c.low)return[1,1];return old;
 }
 return f.proxies.map((p,j)=>{
  if(!p||p.ma[c.ma]==null)return old[j];
  if(c.family==='proxy_vol_trend')return p.vol==null?old[j]:p.value<p.ma[c.ma]&&p.vol>c.vol?c.off:1;
  if(c.family==='proxy_vix_joint')return f.vix==null?old[j]:p.value<p.ma[c.ma]&&f.vix>c.high?c.off:1;
  throw new Error('Unknown family '+c.family);
 });
}
function runAccount(origin,weights,c=null,detail=false){
 const first=index.get(origin.start),last=index.get(origin.end);assert(first!==undefined&&last!==undefined);
 const permanent=100*(1-sum(weights)),sleeves=weights.map(w=>({cash:100*w,units:0}));
 assert(permanent>=-1e-9);let target=[1,1],peak=100,mdd=0,maxExposure=0,totalFees=0,transactions=0,missingDays=0;
 const trades=[],curve=[],decisions=[];
 for(let i=first;i<=last;i++){
  const [date,prices]=daily[i];
  const preMarket=sum(sleeves.map((s,j)=>s.units*prices[j])),preValue=permanent+sum(sleeves.map((s,j)=>s.cash+s.units*prices[j]));
  maxExposure=Math.max(maxExposure,preValue>0?preMarket/preValue:0);
  if(i===first || c&&i%c.every===0){
   if(c){
    const before=target;target=fractions(c,i-1,target);
    const f=featureRows[i-1];
    if(!f||c.family==='vix_hysteresis'&&f.vix==null||c.family==='proxy_vix_joint'&&(f.vix==null||f.proxies.some(p=>!p||p.ma[c.ma]==null))||c.family==='proxy_vol_trend'&&f.proxies.some(p=>!p||p.ma[c.ma]==null||p.vol==null))missingDays++;
    if(detail)decisions.push({day:date,signalDay:dates[i-1]??null,vixDay:f?.vixDay??null,target:target.slice()});
   }
   sleeves.forEach((s,j)=>{
    const current=s.units*prices[j],equity=s.cash+current,f=target[j];
    let desired=f*equity;
    if(desired>current)desired=f*(equity+fee*current)/(1+f*fee);
    else if(desired<current)desired=f*(equity-fee*current)/(1-f*fee);
    const delta=desired-current;
    if(Math.abs(delta)<=Math.max(1,equity)*1e-12)return;
    const charge=Math.abs(delta)*fee;
    s.units=desired/prices[j];s.cash-=delta+charge;
    assert(s.cash>=-1e-8&&s.units>=-1e-10,'Self-financing constraint');
    if(Math.abs(s.cash)<1e-10)s.cash=0;
    transactions++;totalFees+=charge;
    if(detail)trades.push({day:date,signalDay:dates[i-1]??null,leg:j,side:delta>0?'buy':'sell',amount:Math.abs(delta),fee:charge,target:f,cash:s.cash,units:s.units});
   });
  }
  const market=sum(sleeves.map((s,j)=>s.units*prices[j])),value=permanent+sum(sleeves.map((s,j)=>s.cash+s.units*prices[j]));
  maxExposure=Math.max(maxExposure,value>0?market/value:0);peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));
  assert(value>0&&maxExposure<=1+1e-9);
  if(detail)curve.push({day:date,value,exposure:market/value,cash:permanent+sum(sleeves.map(s=>s.cash))});
 }
 const value=permanent+sum(sleeves.map((s,j)=>s.cash+s.units*daily[last][1][j]));
 return{start:origin.start,end:origin.end,years:origin.years,weights,value,annualReturn:100*((value/100)**(YEAR/span(origin.start,origin.end))-1),mdd,
  totalFees,transactions,maxExposure,permanentCash:permanent,finalCash:permanent+sum(sleeves.map(s=>s.cash)),missingDays,...(detail?{trades,curve,decisions}:{})};
}
function compare(rows,base){
 assert.equal(rows.length,base.length);const yy={};
 const deltas=rows.map((r,i)=>{assert(r.start===base[i].start);const d=r.annualReturn-base[i].annualReturn;(yy[r.start.slice(0,4)]??=[]).push(d);return d;});
 const values=rows.map((r,i)=>100*(r.value/base[i].value-1));
 return{n:rows.length,yearEqualCAGRpp:mean(Object.values(yy).map(mean)),meanCAGRpp:mean(deltas),wins:deltas.filter(d=>d>1e-9).length,ties:deltas.filter(d=>Math.abs(d)<=1e-9).length,losses:deltas.filter(d=>d< -1e-9).length,medianWealthRelativePct:median(values),medianMDD:median(rows.map(r=>r.mdd)),worstMDD:Math.min(...rows.map(r=>r.mdd)),medianTradingCost:median(rows.map(r=>r.totalFees)),medianTransactions:median(rows.map(r=>r.transactions)),maxActualETFExposure:Math.max(...rows.map(r=>r.maxExposure)),byEntryYear:Object.fromEntries(Object.entries(yy).map(([y,v])=>[y,{n:v.length,meanCAGRpp:mean(v)}])),baseline:{medianMDD:median(base.map(r=>r.mdd)),medianTradingCost:median(base.map(r=>r.totalFees)),maxActualETFExposure:Math.max(...base.map(r=>r.maxExposure))}};
}
const development=data.origins.filter(r=>r.years===10&&r.start>='2011-09-01'&&r.start<'2014');assert.equal(development.length,28);
const evaluation=data.origins.filter(r=>r.years===10&&r.start>='2014'&&r.start<'2017');assert.equal(evaluation.length,35);
const provenance={input:hash(inputBytes),protocol:hash(fs.readFileSync(path.join(DIR,'protocol.json'))),code:hash(fs.readFileSync(__filename))};
function write(name,d){const dest=path.join(DIR,name);assert(!fs.existsSync(dest),'Refuse overwrite '+name);fs.writeFileSync(dest,JSON.stringify(d,null,2)+'\n');}
if(require.main===module){
 const mode=process.argv[2];
 if(mode==='develop'){
  const base=development.map(r=>runAccount(r,[.3,.3]));
  const results=protocol.candidates.map(c=>{const rows=development.map(r=>runAccount(r,[.3,.3],c));return{c,summary:compare(rows,base),rows};});
  results.sort((a,b)=>b.summary.yearEqualCAGRpp-a.summary.yearEqualCAGRpp||a.summary.medianTransactions-b.summary.medianTransactions||a.c.id.localeCompare(b.c.id));
  const selected=[],used=new Set();for(const r of results){if(used.has(r.c.family))continue;used.add(r.c.family);selected.push({c:r.c,development:r.summary});if(selected.length===3)break;}
  write('development.json',{provenance,results,baseline:base});write('selection.json',{provenance,selected,reason:protocol.selection});
  console.log(JSON.stringify({selected,range:[results[0].summary.yearEqualCAGRpp,results.at(-1).summary.yearEqualCAGRpp]},null,2));
 }else if(mode==='evaluate'){
  const selected=JSON.parse(fs.readFileSync(path.join(DIR,'selection.json')));assert.deepEqual(selected.provenance,provenance);
  const result=[];
  for(const {c} of selected.selected)for(const weights of [[.3,.3],...protocol.allocation.stress])for(const [label,origins] of [['later10',evaluation],['all15',data.origins.filter(r=>r.years===15)]]){
   const base=origins.map(r=>runAccount(r,weights));const rows=origins.map(r=>runAccount(r,weights,c,true));
   result.push({c,weights,label,summary:compare(rows,base),rows,baseline:base});
  }
  write('evaluation.json',{provenance,selectionSHA256:hash(fs.readFileSync(path.join(DIR,'selection.json'))),results:result});
  console.log(JSON.stringify(result.map(r=>({id:r.c.id,weights:r.weights,label:r.label,summary:r.summary})),null,2));
 }else if(mode==='self-test'){
  const o=data.origins[0],base=runAccount(o,[.3,.3]);const a=daily[index.get(o.start)][1],b=daily[index.get(o.end)][1];
  const exact=40+30/(1+fee)*b[0]/a[0]+30/(1+fee)*b[1]/a[1];assert(Math.abs(base.value-exact)<1e-9);
  const c=protocol.candidates[0],r=runAccount(o,[.3,.3],c,true);assert(r.trades.every(t=>t.signalDay<t.day));assert(r.decisions.every(d=>d.vixDay===null||d.vixDay<d.signalDay));assert(r.curve.every(x=>x.cash>=40-1e-8));
  console.log('self-tests passed');
 }else throw new Error('develop | evaluate | self-test');
}
module.exports={runAccount,compare,fractions,featureRows,protocol,data,provenance};
