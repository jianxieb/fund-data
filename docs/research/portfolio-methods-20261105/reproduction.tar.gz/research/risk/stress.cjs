'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const S=require('./study.cjs'),T=require('./stage2.cjs'),E=require('./stress-engine.cjs');
const protocol=JSON.parse(fs.readFileSync(path.join(__dirname,'stress-protocol.json')));
assert.equal(protocol.inputSHA256,S.provenance.input);
const results=[];
for(const fee of protocol.feesPerSide)for(const phase of protocol.commonDatePhases)for(const delay of protocol.additionalExecutionDelayCommonDays)for(const weights of protocol.weights)for(const[label,origins]of Object.entries(T.periods)){
 const setting={fee,phase,delay},rows=origins.map(o=>E.account(o,weights,protocol.center,protocol.mask,false,setting));
 const baseline=origins.map(o=>E.account(o,weights,protocol.center,[false,false],false,{fee}));
 results.push({setting,weights,label,summary:T.compare(rows,baseline),rows});
}
const original=JSON.parse(fs.readFileSync(path.join(__dirname,'stage2-results.json')));
for(const r of results.filter(r=>r.setting.fee===.001&&r.setting.phase===0&&r.setting.delay===0)){
 const old=original.results.find(x=>x.maskName==='tqqq_only'&&x.weights.join()===r.weights.join()&&x.label===r.label);
 assert.deepEqual(r.summary,old.summary);assert.deepEqual(r.rows,old.rows);
}
T.write('stress-results.json',{input:S.provenance.input,protocolSHA256:T.hash(fs.readFileSync(path.join(__dirname,'stress-protocol.json'))),codeSHA256:T.hash(fs.readFileSync(__filename)),engineSHA256:T.hash(fs.readFileSync(path.join(__dirname,'stress-engine.cjs'))),originalCenterExactlyReproduced:true,results});
const summary=protocol.weights.flatMap(weights=>Object.keys(T.periods).map(label=>{
 const r=results.filter(r=>r.weights.join()===weights.join()&&r.label===label),v=r.map(r=>r.summary.yearEqualCAGRpp);
 return{weights,label,n:r.length,positive:r.filter(r=>r.summary.yearEqualCAGRpp>0).length,min:Math.min(...v),max:Math.max(...v),worstWinCount:Math.min(...r.map(r=>r.summary.wins)),bestWinCount:Math.max(...r.map(r=>r.summary.wins))};
}));
T.write('stress-summary.json',summary);console.log(JSON.stringify(summary,null,2));
