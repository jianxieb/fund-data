'use strict';
// Evaluation-only output adapter: preserves the already-frozen study module and
// selection, retaining order ledgers and curve hashes instead of multi-GB curves.
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const {runAccount,compare,data,protocol,provenance}=require('./study.cjs');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),DIR=__dirname;
const locked=JSON.parse(fs.readFileSync(path.join(DIR,'selection.json')));assert.deepEqual(locked.provenance,provenance);
const later=data.origins.filter(r=>r.years===10&&r.start>='2014'&&r.start<'2017');assert.equal(later.length,35);
const results=[];
for(const {c} of locked.selected)for(const weights of [[.3,.3],...protocol.allocation.stress])for(const[label,origins]of[['later10',later],['all15',data.origins.filter(r=>r.years===15)]]){
 const baseline=origins.map(o=>runAccount(o,weights));
 const rows=origins.map(o=>{const r=runAccount(o,weights,c,true);const curveSHA256=hash(JSON.stringify(r.curve));const{curve,...record}=r;return{...record,curveSHA256};});
 results.push({c,weights,label,summary:compare(rows,baseline),rows,baseline});
}
const out=path.join(DIR,'evaluation.json');assert(!fs.existsSync(out),'Refuse overwrite');
fs.writeFileSync(out,JSON.stringify({provenance,selectionSHA256:hash(fs.readFileSync(path.join(DIR,'selection.json'))),outputAdapterSHA256:hash(fs.readFileSync(__filename)),note:'Original frozen evaluation serialization exceeded JS string limit without producing output. This adapter only omits per-day curves; account formulas and selected rules unchanged. Every curve hash retained; runAccount(detail=true) reproduces daily valuations.',results}));
console.log(JSON.stringify(results.map(r=>({family:r.c.family,weights:r.weights,label:r.label,summary:r.summary})),null,2));
