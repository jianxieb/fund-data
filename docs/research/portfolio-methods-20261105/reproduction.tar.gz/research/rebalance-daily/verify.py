"""Verify cash-flow identities, dividend-tax accounting, signal lag and causal prefix."""
from pathlib import Path
import json
import study as S
P=Path(__file__).parent
cases=[]
for name in ['taxed-results.json','pretax-results.json']:cases.extend(json.loads((P/name).read_text())['results'])
errors={'cashIdentity':0.,'pretaxLumpAnalytical':0.,'traceValue':0.,'traceCash':0.,'traceTaxReserve':0.,'tracePaidTax':0.,'traceCostBasis':0.}
for case in cases:
 w=case['weights'];fee=case['fee'];W=sum(w)
 for kind in ['rows','baseline']:
  for r in case[kind]:
   e=abs(r['actualPurchaseNotional']+r['fees']+r['finalCash']-100);errors['cashIdentity']=max(errors['cashIdentity'],e);assert e<1e-8
   assert r['paidCapitalGainsTax']==0 and r['minimumCash']>=-1e-9 and r['maxStockFractionAfterAdditionalBuy']<=W+1e-9
   if W==1:assert r['additionalBuyDates']==0
   if kind=='baseline' and case['tax']['capitalGains']==0:
    p0,p1=S.PX[S.IDX[r['start']]],S.PX[S.IDX[r['end']]];net=100/(1+fee*W)
    exact=(1-W)*net+sum(net*w[k]*p1[k]/p0[k] for k in range(2))
    e=abs(exact-r['value']);errors['pretaxLumpAnalytical']=max(errors['pretaxLumpAnalytical'],e);assert e<1e-8
traces=json.loads((P/'traces.json').read_text())['traces']
for case in traces:
 r=case['account'];w=case['weights'];fee=case['fee'];q=[0.,0.];basis=[0.,0.];cash=100.;paid=0.;orders={o['date']:o for o in r['orders']};curve={c['date']:c for c in r['curve']}
 for row in r['curve']:
  i=S.IDX[row['date']];prices=S.PX[i]
  if row['date']!=r['start']:
   for k in range(2):
    gross=q[k]*prices[k]*S.FRAC[i][k];tax=.2*gross;q[k]-=tax/prices[k];basis[k]+=.8*gross;paid+=tax
  order=orders.get(row['date'])
  if order:
   if order['reason']!='initial':
    assert S.IDX[order['date']]-S.IDX[order['signalDate']]==1+case['extraDelay']
    assert curve[order['signalDate']]['stockFraction']<sum(w)-1e-10
   for k,a in enumerate(order['notionals']):q[k]+=a/prices[k];basis[k]+=a*(1+fee);cash-=a*(1+fee)
  marked=[q[k]*prices[k] for k in range(2)];reserve=.2*sum(max(0,marked[k]*(1-fee)-basis[k]) for k in range(2));v=cash+sum(marked)-reserve
  for key,e in [('traceValue',abs(v-row['value'])),('traceCash',abs(cash-row['cash'])),('traceTaxReserve',abs(reserve-row['taxReserve'])),('tracePaidTax',abs(paid-row['paidTax'])),('traceCostBasis',max(abs(basis[k]-row['costBasis'][k]) for k in range(2)))]:
   errors[key]=max(errors[key],e);assert e<1e-8,(key,e)
# Future-price changes cannot alter earlier signals, sizes or valuations.
o=next(o for o in S.PERIODS[10] if o['start']=='2014-01-02');cutoff='2015-01-02'
original=[p[:] for p in S.PX]
for delay in [0,1]:
 before=S.run(o,[.3,.3],delay=delay,trace=True)
 for i,d in enumerate(S.DAYS):
  if d>cutoff:S.PX[i]=[original[i][0]*(.2+i%7),original[i][1]*(.5+(i%11)/5)]
 after=S.run(o,[.3,.3],delay=delay,trace=True)
 for k in ['orders','curve']:assert [r for r in before[k] if r['date']<=cutoff]==[r for r in after[k] if r['date']<=cutoff]
 assert before['value']!=after['value'];S.PX[:]=[p[:] for p in original]
S.save('verification.json',{'status':'PASS','cases':len(cases),'accountRowsChecked':sum(len(c['rows'])+len(c['baseline']) for c in cases),'traceAccounts':len(traces),'checks':['cash purchases+trade fees+cash remaining=initial100, all accounts','all no-cash cases equal lump and never top up','all pretax baseline endpoints equal buy-hold analytical formula','four full daily tax traces reconstructed from orders and actual dividend fractions','capital gain reserve and paid dividend tax are distinct and reconciled','signals use complete t-1/t-2 snapshots; future-price mutation preserves past orders and daily values exactly','all purchase target caps respected'],'maxAbsoluteErrors':errors,'futureMutationCutoff':cutoff,'studyCodeSHA256':S.SHA((P/'study.py').read_bytes())})
print(json.dumps({'status':'PASS','cases':len(cases),'errors':errors},indent=2))
