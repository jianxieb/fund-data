"""Frozen daily buy-only cash-deficit replenishment; independent tax-aware ledger.
Tax accounting mirrors assets/portfolio-model.js formulas, not legal tax advice.
"""
from pathlib import Path
from datetime import date,datetime,timezone
from collections import defaultdict
import json,hashlib,math,statistics,sys
P=Path(__file__).resolve().parent
RAW=(P.parent/'inputs.json').read_bytes();TAXRAW=(P.parent/'tax-inputs.json').read_bytes()
I=json.loads(RAW);T=json.loads(TAXRAW);DAYS=[r[0] for r in I['daily']];PX=[r[1] for r in I['daily']];IDX={d:i for i,d in enumerate(DAYS)}
IDS=['us:USD','us:TQQQ'];FRAC=[[T[k]['dividendEvidence']['fractions'].get(d,0) for k in IDS] for d in DAYS]
PERIODS={y:[o for o in I['origins'] if o['years']==y] for y in [10,15]}
WEIGHTS=[[.3,.3],[.2,.4],[.4,.2],[.35,.25],[.15,.65],[.5,.5]]
CONFIG={'initialCapital':100,'weights':WEIGHTS,'fees':[.001,.005],'extraDelayCommonDays':[0,1],'taxes':[{'capitalGains':.2,'dividends':.2},{'capitalGains':0,'dividends':0}],'threshold':None,'cooldown':None,'sells':False,'deposits':0,'interest':0,'terminalLiquidation':False}
SHA=lambda b:hashlib.sha256(b).hexdigest();MEAN=statistics.mean;MED=statistics.median
assert [len(PERIODS[y]) for y in [10,15]]==[81,21]
for y,oo in PERIODS.items():
 for k in IDS:
  e=T[k]['dividendEvidence'];assert e['status']=='recorded' and e['first']<=min(o['start'] for o in oo) and e['through']>=max(o['end'] for o in oo)

def save(name,x):
 with (P/name).open('x') as f:json.dump(x,f,separators=(',',':'))

def freeze():
 save('protocol.json',{'createdUTC':datetime.now(timezone.utc).isoformat(),'config':CONFIG,'inputSHA256':SHA(RAW),'taxInputSHA256':SHA(TAXRAW),'codeSHA256':SHA(Path(__file__).read_bytes()),
 'rule':'Every common date, use the actual post-trade account snapshot of t-1 (t-2 for extra delay1). If gross stock/(cash+gross stock)<sum(initial weights), buy only with existing cash. Split purchase by positive individual gaps max(0,initialWeight-priorActualWeight). Never sell; no drawdown threshold, cooldown or optimized parameter.',
 'size':'At current close after dividend-tax processing, with gross wealth V, stock K, target W, fee f: B=max(0,min(cash/(1+f),(W*V-K)/(1+W*f))). Execute B allocated according to frozen signal gaps, enforcing immediate post-trade total stock weight<=W. Naturally appreciated stock weights can exceed W between trades.',
 'initial':'Production invest(): usable=100/(1+f*W), gross purchases=usable*individual weights. The remainder cash=100-gross purchases-fees is the initial reserve. Both method and lump use exactly this same initial allocation and fee.',
 'taxAccounting':'Match production tax formulas: adjusted total-return price already reinvests gross distributions. On distribution dates after account start, gross=units*currentPrice*fraction; units-=gross*divRate/currentPrice; basis+=gross*(1-divRate). Buys add notional+fee to cost basis. No sales occur, so no realized capital-gains tax. For all daily performance and final value subtract per-asset max(0,units*price*(1-fee)-basis)*capitalGainsRate as an unrealized liability, without spending reserve cash or pretending this liability is already paid.',
 'priceAndExposureBasis':'Actual frozen USD/TQQQ CNY adjusted-price common trading dates. Signals and target checks use gross asset/portfolio market value as production rebalance does; after-tax wealth and drawdown subtract gain-tax reserve. Excludes extra FX-only calendar dates.',
 'comparison':'Same100 starting capital, same initial user weights, same fee and tax assumptions, same exact origin/end vs buy-and-hold. All81 full10year and21 full15year origins; weights never individually retuned; full cartesian sensitivity grid reported.',
 'interpretation':'Any gain from this rule deploys original idle cash into stocks after the portfolio falls below target, changing market exposure. This is a cash-management policy, not evidence of a predictive timing signal or risk-matched alpha. With zero initial cash it must match lump.',
 'selection':'No selection/ranking of parameters, weights, delay or fee; all fixed cases retained even if negative. Diagnostic was prompted by earlier research and is retrospective, not untouched validation.'})
 print('Daily cash-deficit protocol frozen before new tax-aware performance calculation.')

def run(o,w,cap=.2,div=.2,fee=.001,delay=0,hold=False,trace=False):
 first,last=IDX[o['start']],IDX[o['end']];W=sum(w);usable=100/(1+fee*W)
 q=[usable*w[k]/PX[first][k] for k in range(2)];cash=100-usable*W*(1+fee);basis=[usable*w[k]*(1+fee) for k in range(2)]
 if abs(cash)<1e-10:cash=0.
 initialCash=cash;initialBuy=usable*W;cost=initialBuy*fee;paid=0.;purchased=initialBuy;tradecount=sum(a>0 for a in w);turnover=initialBuy/100
 peak=100.;mdd=0.;grossPeak=100.;grossMdd=0.;mincash=cash;maxexp=0.;sumexp=0.;maxAfterBuy=W;maxEach=[0.,0.];values=[];snapshots=[];orders=[];curve=[];additions=0
 if trace:orders.append({'date':o['start'],'signalDate':None,'notionals':[usable*a for a in w],'fee':cost,'reason':'initial'})
 for i in range(first,last+1):
  p=PX[i]
  if i>first:
   for k in range(2):
    gross=q[k]*p[k]*FRAC[i][k];charge=gross*div;q[k]-=charge/p[k];basis[k]+=gross-charge;paid+=charge
   lag=i-first-1-delay
   if not hold and lag>=0:
    signal=snapshots[lag]
    if signal['stockFraction']<W-1e-10:
     gaps=[max(0,w[k]-signal['weights'][k]) for k in range(2)];gs=sum(gaps)
     stock=sum(q[k]*p[k] for k in range(2));wealth=stock+cash
     budget=max(0,min(cash/(1+fee),(W*wealth-stock)/(1+W*fee)))
     if budget>1e-10 and gs>0:
      aa=[budget*g/gs for g in gaps]
      for k in range(2):q[k]+=aa[k]/p[k];basis[k]+=aa[k]*(1+fee)
      charge=budget*fee;cash-=budget+charge;cost+=charge;purchased+=budget;tradecount+=sum(a>1e-12 for a in aa);turnover+=budget/wealth;additions+=1
      stock=sum(q[k]*p[k] for k in range(2));exposure=stock/(cash+stock);assert cash>=-1e-9 and exposure<=W+1e-10
      maxAfterBuy=max(maxAfterBuy,exposure)
      if trace:orders.append({'date':DAYS[i],'signalDate':signal['date'],'notionals':aa,'fee':charge,'reason':'cash_deficit','exposureAfterBuy':exposure})
  marked=[q[k]*p[k] for k in range(2)];stock=sum(marked);grossValue=cash+stock
  reserve=sum(max(0,marked[k]*(1-fee)-basis[k])*cap for k in range(2));value=grossValue-reserve
  assert value>0 and cash>=-1e-9
  peak=max(peak,value);mdd=min(mdd,100*(value/peak-1));grossPeak=max(grossPeak,grossValue);grossMdd=min(grossMdd,100*(grossValue/grossPeak-1))
  actual=[x/grossValue for x in marked];exposure=stock/grossValue;sumexp+=exposure;maxexp=max(maxexp,exposure);mincash=min(mincash,cash);maxEach=[max(maxEach[k],actual[k]) for k in range(2)]
  snapshots.append({'date':DAYS[i],'weights':actual,'stockFraction':exposure});values.append(value)
  if trace:curve.append({'date':DAYS[i],'value':value,'grossValue':grossValue,'cash':cash,'stock':stock,'taxReserve':reserve,'paidTax':paid,'costBasis':basis[:],'units':q[:],'stockFraction':exposure})
 elapsed=(date.fromisoformat(o['end'])-date.fromisoformat(o['start'])).days/365.2425
 rr=sorted(100*(values[i]/values[i-1]-1) for i in range(1,len(values)))
 r={'start':o['start'],'end':o['end'],'years':o['years'],'value':value,'grossValue':grossValue,'annualReturn':100*((value/100)**(1/elapsed)-1),'mdd':mdd,'grossMDD':grossMdd,'dailyCVaR95Pct':MEAN(rr[:math.ceil(.05*len(rr))]),'initialCash':initialCash,'finalCash':cash,'minimumCash':mincash,'cashConsumed':initialCash-cash,'initialPurchaseNotional':initialBuy,'actualPurchaseNotional':purchased,'additionalPurchaseNotional':purchased-initialBuy,'maxStockFraction':maxexp,'meanStockFraction':sumexp/len(values),'maxIndividualStockFraction':maxEach,'maxStockFractionAfterAdditionalBuy':maxAfterBuy,'fees':cost,'paidDividendTax':paid,'paidCapitalGainsTax':0,'capitalGainsTaxReserve':reserve,'taxCost':paid+reserve,'costBasis':basis,'transactions':tradecount,'additionalBuyDates':additions,'annualTurnoverPct':turnover*100/elapsed}
 if trace:r.update(orders=orders,curve=curve)
 return r

def compare(rows,base):
 yy=defaultdict(list);d=[];wealth=[];pairs=[]
 for r,b in zip(rows,base):
  assert (r['start'],r['end'])==(b['start'],b['end']);x=r['annualReturn']-b['annualReturn'];v=100*(r['value']/b['value']-1);d.append(x);wealth.append(v);yy[r['start'][:4]].append(x);pairs.append({'start':r['start'],'end':r['end'],'CAGRpp':x,'wealthRelativePct':v,'value':r['value'],'baselineValue':b['value'],'mdd':r['mdd'],'baselineMDD':b['mdd']})
 worst=min(pairs,key=lambda p:p['CAGRpp'])
 return {'n':len(rows),'yearEqualCAGRpp':MEAN(MEAN(v) for v in yy.values()),'meanCAGRpp':MEAN(d),'wins':sum(x>1e-9 for x in d),'ties':sum(abs(x)<=1e-9 for x in d),'losses':sum(x< -1e-9 for x in d),'medianWealthRelativePct':MED(wealth),'worstOriginByCAGRpp':worst,'medianCAGR':MED(r['annualReturn'] for r in rows),'medianMDD':MED(r['mdd'] for r in rows),'worstMDD':min(r['mdd'] for r in rows),'medianPairedMDDChangePP':MED(r['mdd']-b['mdd'] for r,b in zip(rows,base)),'medianDailyCVaR95Pct':MED(r['dailyCVaR95Pct'] for r in rows),'medianCashConsumed':MED(r['cashConsumed'] for r in rows),'minimumCashAcrossAccounts':min(r['minimumCash'] for r in rows),'medianFinalCash':MED(r['finalCash'] for r in rows),'medianActualPurchaseNotional':MED(r['actualPurchaseNotional'] for r in rows),'medianAdditionalPurchaseNotional':MED(r['additionalPurchaseNotional'] for r in rows),'meanStockFraction':MEAN(r['meanStockFraction'] for r in rows),'maxStockFractionAcrossAccounts':max(r['maxStockFraction'] for r in rows),'maxStockFractionAfterAdditionalBuy':max(r['maxStockFractionAfterAdditionalBuy'] for r in rows),'medianFees':MED(r['fees'] for r in rows),'medianPaidDividendTax':MED(r['paidDividendTax'] for r in rows),'medianGainTaxReserve':MED(r['capitalGainsTaxReserve'] for r in rows),'medianAdditionalBuyDates':MED(r['additionalBuyDates'] for r in rows),'medianAnnualTurnoverPct':MED(r['annualTurnoverPct'] for r in rows),'baseline':{'medianCAGR':MED(r['annualReturn'] for r in base),'medianMDD':MED(r['mdd'] for r in base),'worstMDD':min(r['mdd'] for r in base),'medianDailyCVaR95Pct':MED(r['dailyCVaR95Pct'] for r in base),'meanStockFraction':MEAN(r['meanStockFraction'] for r in base),'medianActualPurchaseNotional':MED(r['actualPurchaseNotional'] for r in base),'medianFees':MED(r['fees'] for r in base),'medianPaidDividendTax':MED(r['paidDividendTax'] for r in base),'medianGainTaxReserve':MED(r['capitalGainsTaxReserve'] for r in base)},'byEntryYear':{y:{'n':len(v),'meanCAGRpp':MEAN(v)} for y,v in yy.items()}}

def evaluate():
 pp=(P/'protocol.json').read_bytes();p=json.loads(pp)
 assert p['config']==CONFIG and p['inputSHA256']==SHA(RAW) and p['taxInputSHA256']==SHA(TAXRAW) and p['codeSHA256']==SHA(Path(__file__).read_bytes())
 results=[]
 for tax in CONFIG['taxes']:
  for w in WEIGHTS:
   for fee in CONFIG['fees']:
    baselines={y:[run(o,w,cap=tax['capitalGains'],div=tax['dividends'],fee=fee,hold=True) for o in oo] for y,oo in PERIODS.items()}
    for delay in CONFIG['extraDelayCommonDays']:
     for y,oo in PERIODS.items():
      rows=[run(o,w,cap=tax['capitalGains'],div=tax['dividends'],fee=fee,delay=delay) for o in oo];s=compare(rows,baselines[y])
      results.append({'tax':tax,'weights':w,'fee':fee,'extraDelay':delay,'years':y,'summary':s,'rows':rows,'baseline':baselines[y]})
      print(json.dumps({'tax':tax,'weights':w,'fee':fee,'delay':delay,'years':y,'CAGRpp':s['yearEqualCAGRpp'],'winTieLoss':[s['wins'],s['ties'],s['losses']],'worst':s['worstOriginByCAGRpp']}),flush=True)
  name='taxed-results.json' if tax['capitalGains'] else 'pretax-results.json'
  save(name,{'protocolSHA256':SHA(pp),'inputSHA256':SHA(RAW),'taxInputSHA256':SHA(TAXRAW),'results':[r for r in results if r['tax']==tax]})
 traces=[]
 for y,start,w,fee,delay in [(10,'2014-01-02',[.3,.3],.001,0),(15,PERIODS[15][0]['start'],[.3,.3],.001,0),(10,'2014-01-02',[.35,.25],.005,1),(10,'2014-01-02',[.5,.5],.001,0)]:
  o=next(o for o in PERIODS[y] if o['start']==start)
  traces.append({'weights':w,'fee':fee,'extraDelay':delay,'tax':{'capitalGains':.2,'dividends':.2},'account':run(o,w,fee=fee,delay=delay,trace=True)})
 save('traces.json',{'protocolSHA256':SHA(pp),'traces':traces})
 save('summary.json',{'protocolSHA256':SHA(pp),'cases':[{k:r[k] for k in ['tax','weights','fee','extraDelay','years','summary']} for r in results]})

if __name__=='__main__':
 if sys.argv[1]=='freeze':freeze()
 elif sys.argv[1]=='evaluate':evaluate()
 else:raise SystemExit('freeze | evaluate')
