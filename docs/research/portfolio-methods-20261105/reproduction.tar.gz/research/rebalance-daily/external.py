"""Separate pretax20-year true SMPIX/UOPIX extension of frozen cash replenishment.
Imports unchanged generic ledger; there is no distribution tax evidence for these funds.
"""
import json,sys
from pathlib import Path
import study as S
P=Path(__file__).parent;RAW=(P.parent/'external-inputs.json').read_bytes();E=json.loads(RAW)
CONFIG={'weights':[.3,.3],'fees':[.001,.005],'extraDelayCommonDays':[0,1],'capitalGainsTax':0,'dividendTax':0,'years':20}
if sys.argv[1]=='freeze':
 S.save('external-protocol.json',{'inputSHA256':S.SHA(RAW),'studyCodeSHA256':S.SHA((P/'study.py').read_bytes()),'codeSHA256':S.SHA(Path(__file__).read_bytes()),'config':CONFIG,'selection':'No parameter selection; all four fixed sensitivities shown.','data':'Actual SMPIX1.5x/UOPIX2x USD fund total-return series. Not USD/TQQQ prehistory.','taxMissing':'No full dividend/distribution fractions for these funds in frozen inputs. This extension is explicitly pretax only; do not apply or imply the ETF after-tax conclusion.','source':E['source']})
 print('External20-year cash topup protocol frozen before evaluation.')
else:
 protocol=json.loads((P/'external-protocol.json').read_text());assert protocol['config']==CONFIG and protocol['inputSHA256']==S.SHA(RAW) and protocol['studyCodeSHA256']==S.SHA((P/'study.py').read_bytes()) and protocol['codeSHA256']==S.SHA(Path(__file__).read_bytes())
 S.DAYS=[r[0] for r in E['daily']];S.PX=[r[1] for r in E['daily']];S.IDX={d:i for i,d in enumerate(S.DAYS)};S.FRAC=[[0.,0.] for _ in S.DAYS]
 oo=[o for o in E['origins'] if o['years']==20];assert len(oo)==77
 out=[]
 for fee in CONFIG['fees']:
  base=[S.run(o,CONFIG['weights'],cap=0,div=0,fee=fee,hold=True) for o in oo]
  for delay in CONFIG['extraDelayCommonDays']:
   rows=[S.run(o,CONFIG['weights'],cap=0,div=0,fee=fee,delay=delay) for o in oo];summary=S.compare(rows,base)
   out.append({'weights':CONFIG['weights'],'fee':fee,'extraDelay':delay,'years':20,'tax':'PRETAX_ONLY_DIVIDEND_EVIDENCE_UNAVAILABLE','summary':summary,'rows':rows,'baseline':base})
   print(json.dumps({'fee':fee,'delay':delay,'summary':summary}),flush=True)
 S.save('external-results.json',{'protocolSHA256':S.SHA((P/'external-protocol.json').read_bytes()),'results':out})
