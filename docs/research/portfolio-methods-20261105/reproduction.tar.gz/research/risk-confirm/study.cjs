 'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const DIR=__dirname,root=path.dirname(DIR),shared=require('../risk-daily/study.cjs');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),protocol=JSON.parse(fs.readFileSync(DIR+'/protocol.json'));
const raw=fs.readFileSync(root+'/inputs.json'),taxRaw=fs.readFileSync(root+'/tax-inputs.json'),data=JSON.parse(raw),taxData=JSON.parse(taxRaw);
assert.equal(hash(raw),protocol.inputsSHA256);assert.equal(hash(taxRaw),protocol.taxInputsSHA256);assert.equal(hash(fs.readFileSync(root+'/risk-daily/study.cjs')),protocol.sharedLedgerSHA256);
const {tradeTo,compare,periods}=shared,daily=data.daily,dates=daily.map(r=>r[0]),ix=new Map(dates.map((d,i)=>[d,i])),qqq=data.proxies['us:QQQ'].series;
const dividends=['us:USD','us:TQQQ'].map(k=>taxData[k].dividendEvidence.fractions),sum=a=>a.reduce((x,y)=>x+y,0),mean=a=>sum(a)/a.length,msday=864e5,year=365.2425;
const qindex=shared.qindex,qf=qqq.map(([day,price],i)=>({day,price,vol:shared.qf[i].vol,high:i>=251?Math.max(...qqq.slice(i-251,i+1).map(r=>r[1])):null,ma:Object.fromEntries([200,300,400].map(n=>[n,i>=n-1?mean(qqq.slice(i-n+1,i+1).map(r=>r[1])):null]))}));
function states(c,features=qf){
 let on=true,exitRun=0,enterRun=0,low=null;
 return features.map(f=>{
  const ma=f.ma[c.ma];if(ma==null||f.high==null)return true;
  if(on){exitRun=f.price<ma&&f.price/f.high<=1-c.depth?exitRun+1:0;if(exitRun>=c.exitConfirm){on=false;exitRun=0;enterRun=0;low=f.price;}}
  else{low=Math.min(low,f.price);if(c.reentry==='ma3'){enterRun=f.price>ma?enterRun+1:0;if(enterRun>=3){on=true;exitRun=0;enterRun=0;low=null;}}else if(c.reentry==='rebound15'){if(f.price>=low*1.15){on=true;exitRun=0;enterRun=0;low=null;}}else throw Error('Unknown reentry');}
  return on;
 });
}
const schedules=new Map();function schedule(c){if(!schedules.has(c.id)){const s=states(c);schedules.set(c.id,qindex.map(j=>j>=0?s[j]:null));}return schedules.get(c.id);}
// Account loop and exact partial-sale tax algebra reused from the independently Python-matched risk-daily ledger; only the signal schedule differs.
function account(o,w,c=null,{cap=.2,div=.2,fee=.001,delay=0,trace=false,mode='daily'}={}){
 const first=ix.get(o.start),last=ix.get(o.end);assert(first!=null&&last!=null&&[0,1].includes(delay));
 const permanent=100*(1-sum(w));assert(permanent>=0);const s=w.map(x=>({cash:100*x,units:0,basis:0})),sched=c&&mode==='daily'?schedule(c):null;
 let priorTarget=null,peak=100,mdd=0,totalFees=0,paidCapitalTax=0,paidDividendTax=0,transactions=0,value=100,grossValue=100,reserve=0,maxExposure=0,maxAfterReserveExposure=0;
 const curve=[],trades=[];
 for(let j=first;j<=last;j++){
  const [day,px]=daily[j];
  if(j>first)for(let k=0;k<2;k++){
   const fraction=dividends[k][day]||0,gross=s[k].units*px[k]*fraction,charge=gross*div;
   s[k].units-=charge/px[k];s[k].basis+=gross-charge;paidDividendTax+=charge;
  }
  const beforeMarket=sum(s.map((x,k)=>x.units*px[k])),beforeGross=permanent+sum(s.map((x,k)=>x.cash+x.units*px[k]));
  maxExposure=Math.max(maxExposure,beforeMarket/beforeGross);
  const firstExecution=j===first+delay;
  let target=1,check=j>=first+delay;
  if(c&&mode==='centerAudit'){
   check=firstExecution||j>first+delay&&(j-delay)%5===0;
   const qi=qindex[j-1-delay];target=qi>=0&&qf[qi].price<qf[qi].ma[200]&&qf[qi].vol>.3?0:1;
  }else if(c){const on=sched[j-1-delay];target=on==null?(priorTarget??1):on?1:c.off;}
  if(check&&(firstExecution||c&&target!==priorTarget)){
   for(let k=0;k<2;k++){
    if(!firstExecution&&k===0)continue;
    const t=tradeTo(s[k],px[k],k===0?1:target,fee,cap);
    if(t){totalFees+=t.fee;paidCapitalTax+=t.tax;transactions++;if(trace)trades.push({day,signalDay:dates[j-1-delay]??null,proxyDay:qindex[j-1-delay]>=0?qqq[qindex[j-1-delay]][0]:null,leg:k,...t,cash:s[k].cash,units:s[k].units,basis:s[k].basis});}
   }
   priorTarget=target;
  }
  const marked=s.map((x,k)=>x.units*px[k]),market=sum(marked);
  reserve=sum(s.map((x,k)=>Math.max(0,marked[k]*(1-fee)-x.basis)*cap));grossValue=permanent+sum(s.map(x=>x.cash))+market;value=grossValue-reserve;
  assert(value>0&&s.every(x=>x.cash>=-1e-7&&x.units>=0));
  maxExposure=Math.max(maxExposure,market/grossValue);maxAfterReserveExposure=Math.max(maxAfterReserveExposure,market/value);
  peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));
  if(trace)curve.push({day,value,grossValue,reserve,market,permanentCash:permanent,cash:permanent+sum(s.map(x=>x.cash)),sleeves:s.map(x=>({...x}))});
 }
 const years=(Date.parse(o.end)-Date.parse(o.start))/msday/year;
 return{start:o.start,end:o.end,years:o.years,weights:w,value,grossValue,annualReturn:100*((value/100)**(1/years)-1),mdd,totalFees,paidCapitalTax,paidDividendTax,paidTax:paidCapitalTax+paidDividendTax,reserve,transactions,maxActualETFExposure:maxExposure,maxAfterReserveExposure,permanentCash:permanent,finalCash:permanent+sum(s.map(x=>x.cash)),...(trace?{trades,curve}:{})};
}

function write(name,content){const dest=DIR+'/'+name;assert(!fs.existsSync(dest),'Refuse overwrite '+name);fs.writeFileSync(dest,JSON.stringify(content,null,2)+'\n');}
const provenance={input:hash(raw),taxInput:hash(taxRaw),protocol:hash(fs.readFileSync(DIR+'/protocol.json')),code:hash(fs.readFileSync(__filename)),sharedLedger:protocol.sharedLedgerSHA256};
if(require.main===module){
 const mode=process.argv[2];
 if(mode==='develop'){
  const baselines=Object.fromEntries([0,.2].map(t=>[t,periods.development28.map(o=>account(o,[.3,.3],null,{cap:t,div:t}))]));
  const results=protocol.candidates.map(c=>{const taxes=[0,.2].map(t=>{const rows=periods.development28.map(o=>account(o,[.3,.3],c,{cap:t,div:t}));return{tax:t,summary:compare(rows,baselines[t]),rows};});return{c,score:Math.min(...taxes.map(r=>r.summary.yearEqualCAGRpp)),medianTransactions:mean(taxes.map(r=>r.summary.medianTransactions)),taxes};});
  results.sort((a,b)=>b.score-a.score||a.medianTransactions-b.medianTransactions||a.c.id.localeCompare(b.c.id));
  const champions=['ma3','rebound15'].map(f=>results.find(r=>r.c.reentry===f)).map(r=>({c:r.c,score:r.score,eligible:r.taxes.find(t=>t.tax===.2).summary.yearEqualCAGRpp>0,taxes:r.taxes.map(t=>({tax:t.tax,summary:t.summary}))}));
  write('development.json',{provenance,results,baselines});write('selection.json',{provenance,selectionRule:protocol.selection,champions,selected:champions.filter(r=>r.eligible)});
  console.log(JSON.stringify({count:results.length,positive:results.filter(r=>r.score>0).length,range:[results[0].score,results.at(-1).score],champions},null,2));
 }else if(mode==='evaluate'||mode==='stress'){
  const selection=JSON.parse(fs.readFileSync(DIR+'/selection.json'));assert.deepEqual(selection.provenance,provenance);const results=[];
  const variants=mode==='evaluate'?[{fee:.001,delay:0}]:protocol.evaluation.stressFees.flatMap(fee=>protocol.evaluation.extraDelay.map(delay=>({fee,delay})));
  const labels=mode==='evaluate'?Object.keys(periods):['later35','all10_81','all15_21'];
  for(const {c}of selection.selected)for(const w of protocol.account.evaluationWeights)for(const t of [0,.2])for(const v of variants)for(const label of labels){const rows=periods[label].map(o=>account(o,w,c,{cap:t,div:t,...v})),baseline=periods[label].map(o=>account(o,w,null,{cap:t,div:t,fee:v.fee,delay:0}));results.push({c,weights:w,tax:t,...v,label,summary:compare(rows,baseline),rows,baseline});}
  write(mode+'.json',{provenance,selectionSHA256:hash(fs.readFileSync(DIR+'/selection.json')),results});
  console.log(JSON.stringify(results.filter(r=>r.weights[0]===.3).map(({c,weights,tax,fee,delay,label,summary})=>({id:c.id,weights,tax,fee,delay,label,...summary})),null,2));
 }else throw Error('develop | evaluate | stress');
}
module.exports={account,compare,states,qf,qindex,schedule,periods,protocol,data,provenance,write};
