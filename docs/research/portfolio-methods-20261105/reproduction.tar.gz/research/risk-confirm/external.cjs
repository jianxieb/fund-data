 'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto'),S=require('./study.cjs'),L=require('../risk-daily/study.cjs');
const root=path.dirname(__dirname),raw=fs.readFileSync(root+'/external-inputs.json'),data=JSON.parse(raw),daily=data.daily,dates=daily.map(r=>r[0]),ix=new Map(dates.map((d,i)=>[d,i])),qqq=data.proxies['us:QQQ'].series,dividends=[{},{}],sum=a=>a.reduce((x,y)=>x+y,0),msday=864e5,year=365.2425,tradeTo=L.tradeTo;
assert.deepEqual(qqq,S.data.proxies['us:QQQ'].series);const qf=S.qf;
function last(d){let lo=0,hi=qqq.length;while(lo<hi){const m=(lo+hi)>>1;if(qqq[m][0]<=d)lo=m+1;else hi=m;}return lo-1;}
const qindex=dates.map(d=>{const j=last(d);return j>=0&&(Date.parse(d)-Date.parse(qqq[j][0]))/msday<=7?j:-1;});
const c=JSON.parse(fs.readFileSync(__dirname+'/selection.json')).selected.find(r=>r.c.reentry==='ma3').c,qs=S.states(c),mapped=qindex.map(j=>j<0?null:qs[j]),schedule=()=>mapped;
function account(o,w,c=null,{cap=.2,div=.2,fee=.001,delay=0,trace=false,mode='daily'}={}){
 const first=ix.get(o.start),last=ix.get(o.end);assert(first!=null&&last!=null&&[0,1].includes(delay));
 const permanent=100*(1-sum(w));assert(permanent>=0);const s=w.map(x=>({cash:100*x,units:0,basis:0})),sched=c&&mode==='daily'?schedule(c):null;
 let priorTarget=null,peak=100,mdd=0,totalFees=0,paidCapitalTax=0,paidDividendTax=0,transactions=0,value=100,grossValue=100,reserve=0,maxExposure=0,maxAfterReserveExposure=0;
 const curve=[],trades=[];
 for(let j=first;j<=last;j++){
  const [day,px]=daily[j];
  if(j>first)for(let k=0;k<2;k++){
   const fraction=dividends[k][day]||0,gross=s[k].units*px[k]*fraction,charge=gross*div;
   s[k].units-=charge/px[k];s[k].basis+=gross-charge;paidDividendTax+=charge;
  }
  const beforeMarket=sum(s.map((x,k)=>x.units*px[k])),beforeGross=permanent+sum(s.map((x,k)=>x.cash+x.units*px[k]));
  maxExposure=Math.max(maxExposure,beforeMarket/beforeGross);
  const firstExecution=j===first+delay;
  let target=1,check=j>=first+delay;
  if(c&&mode==='centerAudit'){
   check=firstExecution||j>first+delay&&(j-delay)%5===0;
   const qi=qindex[j-1-delay];target=qi>=0&&qf[qi].price<qf[qi].ma[200]&&qf[qi].vol>.3?0:1;
  }else if(c){const on=sched[j-1-delay];target=on==null?(priorTarget??1):on?1:c.off;}
  if(check&&(firstExecution||c&&target!==priorTarget)){
   for(let k=0;k<2;k++){
    if(!firstExecution&&k===0)continue;
    const t=tradeTo(s[k],px[k],k===0?1:target,fee,cap);
    if(t){totalFees+=t.fee;paidCapitalTax+=t.tax;transactions++;if(trace)trades.push({day,signalDay:dates[j-1-delay]??null,proxyDay:qindex[j-1-delay]>=0?qqq[qindex[j-1-delay]][0]:null,leg:k,...t,cash:s[k].cash,units:s[k].units,basis:s[k].basis});}
   }
   priorTarget=target;
  }
  const marked=s.map((x,k)=>x.units*px[k]),market=sum(marked);
  reserve=sum(s.map((x,k)=>Math.max(0,marked[k]*(1-fee)-x.basis)*cap));grossValue=permanent+sum(s.map(x=>x.cash))+market;value=grossValue-reserve;
  assert(value>0&&s.every(x=>x.cash>=-1e-7&&x.units>=0));
  maxExposure=Math.max(maxExposure,market/grossValue);maxAfterReserveExposure=Math.max(maxAfterReserveExposure,market/value);
  peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));
  if(trace)curve.push({day,value,grossValue,reserve,market,permanentCash:permanent,cash:permanent+sum(s.map(x=>x.cash)),sleeves:s.map(x=>({...x}))});
 }
 const years=(Date.parse(o.end)-Date.parse(o.start))/msday/year;
 return{start:o.start,end:o.end,years:o.years,weights:w,value,grossValue,annualReturn:100*((value/100)**(1/years)-1),mdd,totalFees,paidCapitalTax,paidDividendTax,paidTax:paidCapitalTax+paidDividendTax,reserve,transactions,maxActualETFExposure:maxExposure,maxAfterReserveExposure,permanentCash:permanent,finalCash:permanent+sum(s.map(x=>x.cash)),...(trace?{trades,curve}:{})};
}


const oo=data.origins.filter(o=>o.years===20);assert.equal(oo.length,77);const variants=[.001,.005].flatMap(fee=>[0,1].map(delay=>({fee,delay}))),protocol={status:'Fixed selected rule transferred unchanged; actual distinct US1.5x semiconductor/2xNasdaq100 mutual funds, not synthetic TQQQ/USD and not same asset proof',rule:c,weights:[.3,.3],cash:.4,tax:0,taxEvidence:'Earlier mutual-fund dividend tax evidence absent; do not infer taxable-account result',variants,inputSHA256:crypto.createHash('sha256').update(raw).digest('hex'),ruleSelectionSHA256:crypto.createHash('sha256').update(fs.readFileSync(__dirname+'/selection.json')).digest('hex')};
S.write('external-protocol.json',protocol);const results=variants.map(v=>{const rows=oo.map(o=>account(o,[.3,.3],c,{cap:0,div:0,...v})),baseline=oo.map(o=>account(o,[.3,.3],null,{cap:0,div:0,fee:v.fee,delay:0}));return{...v,summary:S.compare(rows,baseline),rows,baseline};});
const transitions=[];for(let i=1;i<qs.length;i++)if(qs[i]!==qs[i-1]&&qqq[i][0]>='2000')transitions.push({signalDay:qqq[i][0],on:qs[i],price:qqq[i][1],ma:S.qf[i].ma[c.ma],drawdown:S.qf[i].price/S.qf[i].high-1});
const output={protocol,codeSHA256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),source:data.source,transitions,results};S.write('external-results.json',output);console.log(JSON.stringify({transitions,results:results.map(r=>({fee:r.fee,delay:r.delay,...r.summary}))},null,2));
