'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),S=require('./study.cjs');
const audit=JSON.parse(fs.readFileSync(path.dirname(__dirname)+'/tax-audit.json'));let checked=0,maxDifference=0;
const close=(a,b)=>assert(Math.abs(a-b)<=Math.max(1,Math.abs(a),Math.abs(b))*1e-10);
for(const b of audit.results)for(const[active,rows]of [[true,b.rows],[false,b.baseline]])for(const old of rows){
 const r=S.account(old,b.weights,active?{id:'center-audit'}:null,{cap:b.tax[0],div:b.tax[1],mode:'centerAudit'});
 for(const k of ['value','annualReturn','mdd','paidTax','reserve'])close(r[k],old[k]);close(r.totalFees,old.cost);assert.equal(r.transactions,old.trades);maxDifference=Math.max(maxDifference,Math.abs(r.value-old.value));checked++;
}
const c={id:'test',ma:200,exitConfirm:5,depth:.1,off:.5,reentry:'ma3'};
const f=price=>({price,high:100,ma:{200:100}});
assert.deepEqual(S.states(c,[80,80,80,80,99,80,80,80,80,80,101,101,101].map(f)),[true,true,true,true,true,true,true,true,true,false,false,false,true]);
assert.deepEqual(S.states({...c,reentry:'rebound15'},[80,80,80,80,80,70,80,81].map(f)),[true,true,true,true,false,false,false,true]);
for(const cc of S.protocol.candidates){const a=S.states(cc);assert.deepEqual(S.states(cc,S.qf.slice(0,999)),a.slice(0,999));}
const r=S.account(S.periods.development28[0],[.3,.3],S.protocol.candidates.find(c=>c.off===.5),{trace:true});
assert(r.trades.every(t=>t.signalDay<t.day&&t.proxyDay<=t.signalDay));assert(r.curve.every(x=>x.cash>=40-1e-7));
const tr=r.trades.filter(t=>t.leg===1);for(let j=1;j<tr.length;j++)assert.notEqual(tr[j].target,tr[j-1].target);
const out={passed:true,accountReferenceMatches:checked,maxAbsoluteValueDifference:maxDifference,checks:['reused tax ledger still matches independent Python1,344accounts','252high and sameMA exit conditions must both persist; a failing day resets confirmation','MA3 reentry requires3consecutive closes','15%rebound uses only running low since exit signal inclusive','state prefix invariant to future observations','prior common day signal; no borrow/permanent cash use','half-off does not rebalance during unchanged state'],provenance:S.provenance};S.write('validation.json',out);console.log(JSON.stringify(out,null,2));
