'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const DIR=__dirname,root=path.dirname(DIR),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const raw=fs.readFileSync(root+'/inputs.json'),taxRaw=fs.readFileSync(root+'/tax-inputs.json');
const protocol=JSON.parse(fs.readFileSync(DIR+'/protocol.json')),data=JSON.parse(raw),taxData=JSON.parse(taxRaw);
assert.equal(hash(raw),protocol.inputsSHA256);assert.equal(hash(taxRaw),protocol.taxInputsSHA256);
const daily=data.daily,dates=daily.map(r=>r[0]),ix=new Map(dates.map((d,i)=>[d,i])),qqq=data.proxies['us:QQQ'].series;
const dividends=['us:USD','us:TQQQ'].map(k=>taxData[k].dividendEvidence.fractions);
const msday=864e5,year=365.2425,sum=a=>a.reduce((x,y)=>x+y,0),mean=a=>sum(a)/a.length;
const median=a=>{a=a.slice().sort((x,y)=>x-y);return(a[(a.length-1)>>1]+a[a.length>>1])/2;};
function lastLE(rows,date){let lo=0,hi=rows.length;while(lo<hi){const m=(lo+hi)>>1;if(rows[m][0]<=date)lo=m+1;else hi=m;}return lo-1;}
const qf=qqq.map(([day,price],j)=>{
 const ma=j>=199?mean(qqq.slice(j-199,j+1).map(r=>r[1])):null;
 const logs=j>=21?qqq.slice(j-20,j+1).map((r,k)=>Math.log(r[1]/qqq[j-21+k][1])):null;
 const m=logs?mean(logs):null,vol=logs?Math.sqrt(sum(logs.map(x=>(x-m)**2))/20)*Math.sqrt(252):null;
 return{day,price,ma,vol};
});
const qindex=dates.map(d=>{const j=lastLE(qqq,d);return j>=0&&(Date.parse(d)-Date.parse(qqq[j][0]))/msday<=7?j:-1;});
function states(c,features=qf){
 let on=true,exitRun=0,enterRun=0;
 return features.map(f=>{
  if(f.ma==null||f.vol==null)return true;
  if(on){exitRun=f.price<f.ma*(1-c.buffer)&&f.vol>c.vol?exitRun+1:0;if(exitRun>=c.exitConfirm){on=false;exitRun=0;enterRun=0;}}
  else{enterRun=f.price>f.ma*(1+c.buffer)?enterRun+1:0;if(enterRun>=c.enterConfirm){on=true;exitRun=0;enterRun=0;}}
  return on;
 });
}
const schedules=new Map();
function schedule(c){if(!schedules.has(c.id)){const s=states(c);schedules.set(c.id,qindex.map(j=>j>=0?s[j]:null));}return schedules.get(c.id);}
function tradeTo(s,price,f,fee,cap){
 const marked=s.units*price,equity=s.cash+marked;
 let desired=f*equity;
 if(desired>marked)desired=f*(equity+fee*marked)/(1+f*fee);
 else if(desired<marked){const rate=fee+cap*Math.max(0,1-fee-s.basis/marked);desired=f*(equity-rate*marked)/(1-f*rate);}
 const delta=desired-marked;if(Math.abs(delta)<=Math.max(1,equity)*1e-12)return null;
 let charge=Math.abs(delta)*fee,paid=0;
 if(delta>0){s.cash-=delta+charge;s.basis+=delta+charge;}
 else{const sale=-delta,basisSold=s.basis*sale/marked;paid=Math.max(0,sale-charge-basisSold)*cap;s.cash+=sale-charge-paid;s.basis-=basisSold;}
 s.units=desired/price;if(Math.abs(s.cash)<1e-9)s.cash=0;if(Math.abs(s.units)<1e-12)s.units=0;if(Math.abs(s.basis)<1e-9)s.basis=0;
 assert(s.cash>=-1e-7&&s.units>=0&&s.basis>=-1e-7,'self financing');
 return{side:delta>0?'buy':'sell',amount:Math.abs(delta),fee:charge,tax:paid,target:f};
}
function account(o,w,c=null,{cap=.2,div=.2,fee=.001,delay=0,trace=false,mode='daily'}={}){
 const first=ix.get(o.start),last=ix.get(o.end);assert(first!=null&&last!=null&&[0,1].includes(delay));
 const permanent=100*(1-sum(w));assert(permanent>=0);const s=w.map(x=>({cash:100*x,units:0,basis:0})),sched=c&&mode==='daily'?schedule(c):null;
 let priorTarget=null,peak=100,mdd=0,totalFees=0,paidCapitalTax=0,paidDividendTax=0,transactions=0,value=100,grossValue=100,reserve=0,maxExposure=0,maxAfterReserveExposure=0;
 const curve=[],trades=[];
 for(let j=first;j<=last;j++){
  const [day,px]=daily[j];
  if(j>first)for(let k=0;k<2;k++){
   const fraction=dividends[k][day]||0,gross=s[k].units*px[k]*fraction,charge=gross*div;
   s[k].units-=charge/px[k];s[k].basis+=gross-charge;paidDividendTax+=charge;
  }
  const beforeMarket=sum(s.map((x,k)=>x.units*px[k])),beforeGross=permanent+sum(s.map((x,k)=>x.cash+x.units*px[k]));
  maxExposure=Math.max(maxExposure,beforeMarket/beforeGross);
  const firstExecution=j===first+delay;
  let target=1,check=j>=first+delay;
  if(c&&mode==='centerAudit'){
   check=firstExecution||j>first+delay&&(j-delay)%5===0;
   const qi=qindex[j-1-delay];target=qi>=0&&qf[qi].price<qf[qi].ma&&qf[qi].vol>.3?0:1;
  }else if(c){const on=sched[j-1-delay];target=on==null?(priorTarget??1):on?1:c.off;}
  if(check&&(firstExecution||c&&target!==priorTarget)){
   for(let k=0;k<2;k++){
    if(!firstExecution&&k===0)continue;
    const t=tradeTo(s[k],px[k],k===0?1:target,fee,cap);
    if(t){totalFees+=t.fee;paidCapitalTax+=t.tax;transactions++;if(trace)trades.push({day,signalDay:dates[j-1-delay]??null,proxyDay:qindex[j-1-delay]>=0?qqq[qindex[j-1-delay]][0]:null,leg:k,...t,cash:s[k].cash,units:s[k].units,basis:s[k].basis});}
   }
   priorTarget=target;
  }
  const marked=s.map((x,k)=>x.units*px[k]),market=sum(marked);
  reserve=sum(s.map((x,k)=>Math.max(0,marked[k]*(1-fee)-x.basis)*cap));grossValue=permanent+sum(s.map(x=>x.cash))+market;value=grossValue-reserve;
  assert(value>0&&s.every(x=>x.cash>=-1e-7&&x.units>=0));
  maxExposure=Math.max(maxExposure,market/grossValue);maxAfterReserveExposure=Math.max(maxAfterReserveExposure,market/value);
  peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));
  if(trace)curve.push({day,value,grossValue,reserve,market,permanentCash:permanent,cash:permanent+sum(s.map(x=>x.cash)),sleeves:s.map(x=>({...x}))});
 }
 const years=(Date.parse(o.end)-Date.parse(o.start))/msday/year;
 return{start:o.start,end:o.end,years:o.years,weights:w,value,grossValue,annualReturn:100*((value/100)**(1/years)-1),mdd,totalFees,paidCapitalTax,paidDividendTax,paidTax:paidCapitalTax+paidDividendTax,reserve,transactions,maxActualETFExposure:maxExposure,maxAfterReserveExposure,permanentCash:permanent,finalCash:permanent+sum(s.map(x=>x.cash)),...(trace?{trades,curve}:{})};
}
function compare(rows,baseline){
 assert.equal(rows.length,baseline.length);const yy={},delta=[],wealth=[];
 rows.forEach((r,j)=>{const b=baseline[j];assert.equal(r.start,b.start);const d=r.annualReturn-b.annualReturn;delta.push(d);wealth.push(100*(r.value/b.value-1));(yy[r.start.slice(0,4)]??=[]).push(d);});
 const metrics=a=>({medianMDD:median(a.map(r=>r.mdd)),worstMDD:Math.min(...a.map(r=>r.mdd)),medianTradingCost:median(a.map(r=>r.totalFees)),medianTransactions:median(a.map(r=>r.transactions)),medianPaidTax:median(a.map(r=>r.paidTax)),medianPaidCapitalTax:median(a.map(r=>r.paidCapitalTax)),medianPaidDividendTax:median(a.map(r=>r.paidDividendTax)),medianTerminalTaxReserve:median(a.map(r=>r.reserve)),maxActualETFExposure:Math.max(...a.map(r=>r.maxActualETFExposure)),maxAfterReserveExposure:Math.max(...a.map(r=>r.maxAfterReserveExposure))});
 return{n:rows.length,yearEqualCAGRpp:mean(Object.values(yy).map(mean)),meanCAGRpp:mean(delta),wins:delta.filter(d=>d>1e-9).length,ties:delta.filter(d=>Math.abs(d)<=1e-9).length,losses:delta.filter(d=>d< -1e-9).length,medianWealthRelativePct:median(wealth),...metrics(rows),baseline:metrics(baseline),byEntryYear:Object.fromEntries(Object.entries(yy).map(([y,a])=>[y,{n:a.length,meanCAGRpp:mean(a)}]))};
}
const periods={development28:data.origins.filter(o=>o.years===10&&o.start>='2011-09'&&o.start<'2014'),later35:data.origins.filter(o=>o.years===10&&o.start>='2014'&&o.start<'2017'),all10_81:data.origins.filter(o=>o.years===10),all15_21:data.origins.filter(o=>o.years===15)};
assert.deepEqual(Object.values(periods).map(a=>a.length),[28,35,81,21]);
function write(name,content){const dest=DIR+'/'+name;assert(!fs.existsSync(dest),'Refuse overwrite '+name);fs.writeFileSync(dest,JSON.stringify(content,null,2)+'\n');}
const provenance={input:hash(raw),taxInput:hash(taxRaw),protocol:hash(fs.readFileSync(DIR+'/protocol.json')),code:hash(fs.readFileSync(__filename))};
if(require.main===module){
 const mode=process.argv[2];
 if(mode==='develop'){
  const baselines=Object.fromEntries([0,.2].map(t=>[t,periods.development28.map(o=>account(o,[.3,.3],null,{cap:t,div:t}))]));
  const results=protocol.candidates.map(c=>{const taxes=[0,.2].map(t=>{const rows=periods.development28.map(o=>account(o,[.3,.3],c,{cap:t,div:t}));return{tax:t,summary:compare(rows,baselines[t]),rows};});return{c,score:Math.min(...taxes.map(r=>r.summary.yearEqualCAGRpp)),medianTransactions:mean(taxes.map(r=>r.summary.medianTransactions)),taxes};});
  results.sort((a,b)=>b.score-a.score||a.medianTransactions-b.medianTransactions||a.c.id.localeCompare(b.c.id));
  write('development.json',{provenance,results,baselines});write('selection.json',{provenance,selectionRule:protocol.selection,selected:results.slice(0,2).map(r=>({c:r.c,score:r.score,taxes:r.taxes.map(t=>({tax:t.tax,summary:t.summary}))}))});
  console.log(JSON.stringify({count:results.length,positive:results.filter(r=>r.score>0).length,range:[results[0].score,results.at(-1).score],selected:results.slice(0,2).map(r=>({c:r.c,score:r.score,taxes:r.taxes.map(t=>({tax:t.tax,summary:t.summary}))}))},null,2));
 }else if(mode==='evaluate'||mode==='stress'){
  const selection=JSON.parse(fs.readFileSync(DIR+'/selection.json'));assert.deepEqual(selection.provenance,provenance);const results=[];
  const variants=mode==='evaluate'?[{fee:.001,delay:0}]:protocol.stress.fees.flatMap(fee=>protocol.stress.extraDelays.map(delay=>({fee,delay})));
  const labels=mode==='evaluate'?Object.keys(periods):['later35','all10_81','all15_21'];
  for(const {c}of selection.selected)for(const w of protocol.fixedAccount.evaluationWeights)for(const t of [0,.2])for(const v of variants)for(const label of labels){const rows=periods[label].map(o=>account(o,w,c,{cap:t,div:t,...v})),baseline=periods[label].map(o=>account(o,w,null,{cap:t,div:t,fee:v.fee,delay:0}));results.push({c,weights:w,tax:t,...v,label,summary:compare(rows,baseline),rows,baseline});}
  write(mode+'.json',{provenance,selectionSHA256:hash(fs.readFileSync(DIR+'/selection.json')),results});
  console.log(JSON.stringify(results.filter(r=>r.weights[0]===.3).map(({c,weights,tax,fee,delay,label,summary})=>({id:c.id,weights,tax,fee,delay,label,...summary})),null,2));
 }else throw new Error('develop | evaluate | stress');
}
module.exports={account,compare,states,qf,qindex,schedule,tradeTo,periods,protocol,data,provenance,write};
