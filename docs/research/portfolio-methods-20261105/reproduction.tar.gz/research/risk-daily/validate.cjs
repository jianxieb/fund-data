'use strict';
const fs=require('fs'),assert=require('assert/strict'),path=require('path');
const S=require('./study.cjs'),root=path.dirname(__dirname),audit=JSON.parse(fs.readFileSync(root+'/tax-audit.json'));
const close=(a,b,m)=>assert(Math.abs(a-b)<=Math.max(1,Math.abs(a),Math.abs(b))*1e-10,`${m}: ${a} != ${b}`);
let checked=0,maxAbsoluteValueDifference=0;
for(const block of audit.results)for(const [active,rows]of [[true,block.rows],[false,block.baseline]])for(const old of rows){
 const now=S.account(old,block.weights,active?{id:'center-audit',off:0}:null,{cap:block.tax[0],div:block.tax[1],mode:'centerAudit'});
 for(const key of ['value','annualReturn','mdd','paidTax','reserve'])close(now[key],old[key],key);
 close(now.totalFees,old.cost,'fees');assert.equal(now.transactions,old.trades);
 maxAbsoluteValueDifference=Math.max(maxAbsoluteValueDifference,Math.abs(now.value-old.value));checked++;
}
const s={cash:0,units:100,basis:20};const t=S.tradeTo(s,1,.5,.001,.2);
assert.equal(t.side,'sell');close(s.units/(s.cash+s.units),.5,'fee/tax-inclusive partial target');close(100,s.cash+s.units+t.fee+t.tax,'self financing partial sell');close(s.basis,20*s.units/100,'average cost allocation');
const buy=S.tradeTo(s,1,1,.001,.2);close(s.cash,0,'full buy cash');assert.equal(buy.tax,0);
const c={id:'state-test',buffer:0,vol:.3,exitConfirm:3,enterConfirm:3,off:.5};
const features=[90,90,90,90,90,110,110,110].map((price,j)=>({price,ma:100,vol:j<3?.4:.1}));
assert.deepEqual(S.states(c,features),[true,true,false,false,false,false,false,true]);
for(const cc of S.protocol.candidates){const full=S.states(cc);assert.deepEqual(S.states(cc,S.qf.slice(0,999)),full.slice(0,999));}
const o=S.periods.development28[0],tr=S.account(o,[.3,.3],S.protocol.candidates.find(x=>x.off===.5),{trace:true});
assert(tr.trades.every(t=>t.signalDay<t.day&&t.proxyDay<=t.signalDay));assert(tr.curve.every(r=>r.cash>=40-1e-8&&r.permanentCash===40));
const tqqq=tr.trades.filter(t=>t.leg===1);for(let j=1;j<tqqq.length;j++)assert.notEqual(tqqq[j].target,tqqq[j-1].target,'no rebalance while state unchanged');
const result={passed:true,independentRootPythonAccountsMatched:checked,maxAbsoluteValueDifference,checks:['same fees/dividend taxes/realized taxes/tax reserve/terminal NAV/MDD as original independent Python center audit','partial sale exact post-fee/post-tax target fraction and pro-rata basis','no cash overdraft or permanent reserve use','state hysteresis remains off when volatility falls without trend recovery','signal prefix invariance to future appended observations','strict prior-common-day signal and known proxy date','50% off sleeve not rebalanced without state change'],provenance:S.provenance};
S.write('validation.json',result);console.log(JSON.stringify(result,null,2));
