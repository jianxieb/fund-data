const fs=require('fs'), assert=require('assert/strict');
const P=require('/Users/ajin/Projects/fund-data/assets/portfolio-model.js');
const input=JSON.parse(fs.readFileSync(__dirname+'/inputs.json'));
const rows=input.daily, first=rows[0][0], asOf=rows.at(-1)[0], ids=['us:USD','us:TQQQ'];
const catalog={assets:ids.map(id=>({id,name:id+' CNY converted research series',currency:'CNY',kind:'etf',status:'available'}))};
const histories=Object.fromEntries(ids.map((id,j)=>[id,{schemaVersion:1,id,currency:'CNY',basis:'provider_adjusted_close',dividends:'reinvested',first,asOf,series:rows.map(r=>[r[0],r[1][j]])}]));
const prices=new Map(rows), weightsList=[[30,30],[20,40],[40,20],[50,50],[35,25],[15,65]];
const out=[];let maxValueError=0;
for(const weights of weightsList)for(const o of input.origins){
 const config={positions:ids.map((id,j)=>({id,weight:weights[j]})),currency:'CNY',initial:100,monthly:0,years:'custom',start:o.start,end:o.end,initialMethod:'lump_sum',contributionMethod:'dca_month',rebalance:'none',transactionFee:.1,feeBasis:'net',tax:{liquidate:false}};
 const r=P.simulate({catalog,histories,config});assert(!r.error,r.error);
 const equity=weights.reduce((a,b)=>a+b,0)/100, base=100/(1+equity*.001), p0=prices.get(o.start), p1=prices.get(o.end);
 const expected=base*((1-equity)+weights.reduce((s,w,j)=>s+w/100*p1[j]/p0[j],0));maxValueError=Math.max(maxValueError,Math.abs(r.value-expected));
 assert(Math.abs(r.value-expected)<1e-8);assert.equal(r.start,o.start);assert.equal(r.end,o.end);
 out.push({weights,start:o.start,end:o.end,years:o.years,value:r.value,annualReturn:r.annualReturn,mdd:r.mdd,tradeCost:r.tradeCost,cash:r.cash,contributed:r.contributed});
}
fs.writeFileSync(__dirname+'/baseline-audit.json',JSON.stringify({feePct:.1,basis:'actual frozen CNY target prices, common-date risk, production engine',cases:out.length,maxValueError,rows:out}));
console.log(JSON.stringify({cases:out.length,maxValueError}));
