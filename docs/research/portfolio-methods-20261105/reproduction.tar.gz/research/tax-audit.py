import json,math,bisect,statistics,hashlib
from pathlib import Path
p=Path(__file__).parent;raw=(p/'inputs.json').read_bytes();i=json.loads(raw);tax=json.loads((p/'tax-inputs.json').read_text());daily=i['daily'];dates=[r[0] for r in daily];idx={d:j for j,d in enumerate(dates)};qqq=i['proxies']['us:QQQ']['series'];qd=[r[0] for r in qqq];qp=[r[1] for r in qqq];logs=[math.log(qp[j]/qp[j-1]) for j in range(1,len(qp))];signals=[]
for j in range(len(qp)):
 signals.append(j>=199 and qp[j]<sum(qp[j-199:j+1])/200 and statistics.stdev(logs[j-21:j])*math.sqrt(252)>.3)
fractions=[tax[k]['dividendEvidence']['fractions'] for k in ['us:USD','us:TQQQ']]
from datetime import date
D=lambda d:date.fromisoformat(d)

def run(o,w,active,cap=.2,div=.2,fee=.001):
 first,last=idx[o['start']],idx[o['end']];cash=[100*x for x in w];units=[0.,0.];basis=[0.,0.];permanent=100*(1-sum(w));peak=100;dd=0;cost=0;paid=0;trades=0
 for j in range(first,last+1):
  day,px=daily[j]
  if j>first:
   for k in range(2):
    frac=fractions[k].get(day,0)
    gross=units[k]*px[k]*frac;divfee=gross*div
    units[k]-=divfee/px[k];basis[k]+=gross-divfee;paid+=divfee
  if j==first or (active and j%5==0):
   prev=dates[j-1] if j else ''
   qi=bisect.bisect_right(qd,prev)-1
   off=active and qi>=0 and (D(prev)-D(qd[qi])).days<=7 and signals[qi]
   for k in range(2):
    target=0 if off and k==1 else 1
    marked=units[k]*px[k]
    if target==0 and units[k]>1e-12:
     saleFee=marked*fee;gainTax=max(0,marked-saleFee-basis[k])*cap
     cash[k]+=marked-saleFee-gainTax;units[k]=0;basis[k]=0;cost+=saleFee;paid+=gainTax;trades+=1
    elif target==1 and cash[k]>1e-10:
     buy=cash[k]/(1+fee);cost+=buy*fee;units[k]+=buy/px[k];basis[k]+=cash[k];cash[k]=0;trades+=1
  marked=[units[k]*px[k] for k in range(2)];reserve=sum(max(0,marked[k]*(1-fee)-basis[k])*cap for k in range(2));v=permanent+sum(cash)+sum(marked)-reserve
  peak=max(peak,v);dd=min(dd,100*(v/peak-1))
 years=(D(o['end'])-D(o['start'])).days/365.2425
 return {'start':o['start'],'end':o['end'],'years':o['years'],'value':v,'annualReturn':100*((v/100)**(1/years)-1),'mdd':dd,'paidTax':paid,'reserve':reserve,'cost':cost,'trades':trades}

def compare(a,b):
 yy={};dr=[];wealth=[]
 for r,s in zip(a,b):
  d=r['annualReturn']-s['annualReturn'];dr.append(d);wealth.append(100*(r['value']/s['value']-1));yy.setdefault(r['start'][:4],[]).append(d)
 return {'n':len(a),'yearEqualCAGRpp':statistics.mean(statistics.mean(v) for v in yy.values()),'wins':sum(d>1e-9 for d in dr),'ties':sum(abs(d)<=1e-9 for d in dr),'losses':sum(d< -1e-9 for d in dr),'medianWealthRelativePct':statistics.median(wealth),'medianMDD':statistics.median(r['mdd'] for r in a),'baselineMedianMDD':statistics.median(r['mdd'] for r in b),'medianPaidTax':statistics.median(r['paidTax'] for r in a),'baselineMedianPaidTax':statistics.median(r['paidTax'] for r in b),'byYear':{y:statistics.mean(v) for y,v in yy.items()}}

res=[]
for rates in [(0,0),(.2,.2),(.3,.2)]:
 for w in [(.3,.3),(.2,.4),(.4,.2),(.5,.5)]:
  for label,oo in [('later35',[o for o in i['origins'] if o['years']==10 and '2014'<=o['start']<'2017']),('all15',[o for o in i['origins'] if o['years']==15])]:
   a=[run(o,w,True,*rates) for o in oo];b=[run(o,w,False,*rates) for o in oo];s=compare(a,b);res.append({'tax':rates,'weights':w,'period':label,'summary':s,'rows':a,'baseline':b});print(rates,w,label,s['yearEqualCAGRpp'],s['wins'],s['losses'],flush=True)
out={'inputSHA':hashlib.sha256(raw).hexdigest(),'source':'Independent Python, frozen CNY prices and actual dividend fractions, existing production tax formula with same separately funded ETF pools','results':res};(p/'tax-audit.json').write_text(json.dumps(out,separators=(',',':')))
