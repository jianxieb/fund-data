import json,math,bisect,statistics,hashlib
from pathlib import Path
p=Path(__file__).parent;raw=(p/'inputs.json').read_bytes();i=json.loads(raw);tax=json.loads((p/'tax-inputs.json').read_text());daily=i['daily'];dates=[r[0] for r in daily];idx={d:j for j,d in enumerate(dates)};qqq=i['proxies']['us:QQQ']['series'];qd=[r[0] for r in qqq];qp=[r[1] for r in qqq];logs=[math.log(qp[j]/qp[j-1]) for j in range(1,len(qp))];signals=[]
on=True;exit_count=0;enter_count=0
for j,price in enumerate(qp):
 if j<251: signals.append(False);continue
 ma=sum(qp[j-199:j+1])/200;high=max(qp[j-251:j+1])
 if on:
  exit_count=exit_count+1 if price<ma and price/high<=.8 else 0
  if exit_count>=20: on=False;exit_count=0;enter_count=0
 else:
  enter_count=enter_count+1 if price>ma else 0
  if enter_count>=3:on=True;exit_count=0;enter_count=0
 signals.append(not on)

fractions=[tax[k]['dividendEvidence']['fractions'] for k in ['us:USD','us:TQQQ']]
from datetime import date
D=lambda d:date.fromisoformat(d)

def run(o,w,active,cap=.2,div=.2,fee=.001):
 first,last=idx[o['start']],idx[o['end']];cash=[100*x for x in w];units=[0.,0.];basis=[0.,0.];permanent=100*(1-sum(w));peak=100;dd=0;cost=0;paid=0;trades=0
 for j in range(first,last+1):
  day,px=daily[j]
  if j>first:
   for k in range(2):
    frac=fractions[k].get(day,0)
    gross=units[k]*px[k]*frac;divfee=gross*div
    units[k]-=divfee/px[k];basis[k]+=gross-divfee;paid+=divfee
  if j==first or active:
   prev=dates[j-1] if j else ''
   qi=bisect.bisect_right(qd,prev)-1
   off=active and qi>=0 and (D(prev)-D(qd[qi])).days<=7 and signals[qi]
   for k in range(2):
    target=0 if off and k==1 else 1
    marked=units[k]*px[k]
    if target==0 and units[k]>1e-12:
     saleFee=marked*fee;gainTax=max(0,marked-saleFee-basis[k])*cap
     cash[k]+=marked-saleFee-gainTax;units[k]=0;basis[k]=0;cost+=saleFee;paid+=gainTax;trades+=1
    elif target==1 and cash[k]>1e-10:
     buy=cash[k]/(1+fee);cost+=buy*fee;units[k]+=buy/px[k];basis[k]+=cash[k];cash[k]=0;trades+=1
  marked=[units[k]*px[k] for k in range(2)];reserve=sum(max(0,marked[k]*(1-fee)-basis[k])*cap for k in range(2));v=permanent+sum(cash)+sum(marked)-reserve
  peak=max(peak,v);dd=min(dd,100*(v/peak-1))
 years=(D(o['end'])-D(o['start'])).days/365.2425
 return {'start':o['start'],'end':o['end'],'years':o['years'],'value':v,'annualReturn':100*((v/100)**(1/years)-1),'mdd':dd,'paidTax':paid,'reserve':reserve,'cost':cost,'trades':trades}

def compare(a,b):
 yy={};dr=[];wealth=[]
 for r,s in zip(a,b):
  d=r['annualReturn']-s['annualReturn'];dr.append(d);wealth.append(100*(r['value']/s['value']-1));yy.setdefault(r['start'][:4],[]).append(d)
 return {'n':len(a),'yearEqualCAGRpp':statistics.mean(statistics.mean(v) for v in yy.values()),'wins':sum(d>1e-9 for d in dr),'ties':sum(abs(d)<=1e-9 for d in dr),'losses':sum(d< -1e-9 for d in dr),'medianWealthRelativePct':statistics.median(wealth),'medianMDD':statistics.median(r['mdd'] for r in a),'baselineMedianMDD':statistics.median(r['mdd'] for r in b),'medianPaidTax':statistics.median(r['paidTax'] for r in a),'baselineMedianPaidTax':statistics.median(r['paidTax'] for r in b),'byYear':{y:statistics.mean(v) for y,v in yy.items()}}

count=0;max_value=0;max_dd=0;max_tax=0
for name in ['evaluate.json','stress.json']:
 for c in json.loads((p/'risk-confirm'/name).read_text())['results']:
  if c['c']['reentry']!='ma3' or c['delay']!=0 or c['label'] not in ['all10_81','all15_21']:continue
  for active,key in [(True,'rows'),(False,'baseline')]:
   for e in c[key]:
    r=run(e,c['weights'],active,c['tax'],c['tax'],c['fee'])
    v=abs(r['value']-e['value']);dd=abs(r['mdd']-e['mdd']);tx=abs(r['paidTax']-e['paidTax']);max_value=max(max_value,v);max_dd=max(max_dd,dd);max_tax=max(max_tax,tx)
    assert v<1e-7 and dd<1e-7 and tx<1e-7,(c['c']['id'],e['start'],v,dd,tx)
    count+=1
out={'accounts':count,'maxValueError':max_value,'maxMDDError':max_dd,'maxPaidTaxError':max_tax,'method':'Independent Python rolling high, MA, consecutive condition state and transaction/tax ledger; all 10/15year starts, four weights, two taxes and both fees at standard next-day execution.'}
(p/'risk-confirm-independent-audit.json').write_text(json.dumps(out));print(json.dumps(out))
