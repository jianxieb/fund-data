"""Replay frozen research without altering archived records. Python/Node stdlib only."""
from pathlib import Path
import argparse,shutil,subprocess,sys
P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('stage',choices=['cash','buy','rebalance','risk','risk-daily','risk-confirm','external-risk','all'])
parser.add_argument('--destination',type=Path)
a=parser.parse_args();dest=(a.destination or P/'rerun'/a.stage).resolve()
if dest.exists():raise SystemExit('Refuse existing destination: '+str(dest))
dest.mkdir(parents=True)

def copy(rel):
 src=P/rel;out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,out)

def group(name):
 for src in (P/name).iterdir():
  if src.is_file() and (src.suffix in ['.py','.cjs'] or src.name.endswith('protocol.json')):
   if name=='risk-confirm' and src.name=='external-protocol.json':continue
   copy(src.relative_to(P))

def run(*args):
 print('RUN',*args,flush=True);subprocess.run(list(args),cwd=dest,check=True)

for rel in ['inputs.json','tax-inputs.json','external-inputs.json','tax-audit.json']:copy(rel)
stages=['cash','buy','rebalance','risk','risk-daily','external-risk'] if a.stage=='all' else [a.stage]
if a.stage=='all' and (P/'risk-confirm'/'evaluate.json').exists():stages.append('risk-confirm')
for stage in stages:
 if stage=='cash':
  group('rebalance-daily')
  run(sys.executable,'rebalance-daily/study.py','evaluate')
  run(sys.executable,'rebalance-daily/verify.py')
  run(sys.executable,'rebalance-daily/external.py','evaluate')
  for rel in ['production/assets/model.js','production/assets/portfolio-model.js']:copy(rel)
  original=(P/'production-cash-audit.cjs').read_text()
  old="require('/Users/ajin/Projects/fund-data/assets/portfolio-model.js')"
  if old not in original:raise SystemExit('Unexpected original production audit import; do not silently patch')
  adapted=original.replace(old,"require('./production/assets/portfolio-model.js')",1)
  (dest/'production-cash-audit.cjs').write_text(adapted)
  run('node','production-cash-audit.cjs')
 elif stage=='buy':
  group('buy');run('node','buy/study.cjs','develop');run('node','buy/study.cjs','evaluate')
 elif stage=='rebalance':
  group('rebalance');run('node','rebalance/study.cjs','develop');run('node','rebalance/study.cjs','evaluate');run(sys.executable,'rebalance/audit.py');run(sys.executable,'rebalance/diagnostics.py')
 elif stage=='risk':
  group('risk');run('node','risk/study.cjs','develop');run('node','risk/evaluate.cjs');run('node','risk/stage2.cjs');run('node','risk/neighborhood.cjs');run('node','risk/stress.cjs')
 elif stage in ['risk-daily','risk-confirm']:
  if stage=='risk-confirm':group('risk-daily')
  group(stage)
  run('node',stage+'/study.cjs','develop');run('node',stage+'/study.cjs','evaluate');run('node',stage+'/study.cjs','stress');run('node',stage+'/validate.cjs')
  if stage=='risk-confirm':
   run('node','risk-confirm/external.cjs');copy('risk-confirm-independent-audit.py');run(sys.executable,'risk-confirm-independent-audit.py')
   for rel in ['production/assets/model.js','production/assets/portfolio-model.js']:copy(rel)
   for name in ['production-audit.cjs','production-ledger-audit.cjs']:
    original=(P/'risk-confirm'/name).read_text()
    literal="'/Users/ajin/Projects/fund-data/assets/portfolio-model.js'"
    if original.count(literal)!=2:raise SystemExit('Unexpected production risk audit paths')
    (dest/'risk-confirm'/name).write_text(original.replace(literal,"path.join(__dirname,'../production/assets/portfolio-model.js')"))
    run('node','risk-confirm/'+name)
 elif stage=='external-risk':
  group('external');run(sys.executable,'external/study.py','evaluate');run(sys.executable,'external/verify.py')
print('Replay completed in',dest)
