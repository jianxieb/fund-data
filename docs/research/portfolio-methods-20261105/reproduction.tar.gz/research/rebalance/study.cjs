const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const DIR=__dirname, inputPath=path.join(DIR,'../inputs.json');
const source=fs.readFileSync(inputPath),I=JSON.parse(source),H=I.daily,dates=H.map(r=>r[0]),px=H.map(r=>r[1]);
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const di=new Map(dates.map((d,i)=>[d,i])),fee=.001;
const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:null;
const median=a=>{a=a.slice().sort((x,y)=>x-y);return a.length?(a[Math.floor((a.length-1)/2)]+a[Math.floor(a.length/2)])/2:null};
const sd=a=>{if(a.length<2)return null;const m=mean(a);return Math.sqrt(a.reduce((s,x)=>s+(x-m)**2,0)/(a.length-1))};
const origins=I.origins;
const development=origins.filter(o=>o.years===10&&o.start>='2011-09-01'&&o.start<'2014');
const later=origins.filter(o=>o.years===10&&o.start>='2014'&&o.start<'2017');
assert.equal(development.length,28);assert.equal(later.length,35);
const candidates=[];
for(const frequency of ['month','quarter','year'])candidates.push({family:'calendar_rebalance',frequency,id:'calendar|'+frequency});
for(const band of [.1,.25,.5,.75,1])for(const frequency of ['daily','month'])candidates.push({family:'drift_band',band,frequency,id:`drift|${band}|${frequency}`});
for(const drawdown of [.05,.1,.2,.3])for(const cooldown of [21,63,126])candidates.push({family:'buy_only_deficit',drawdown,cooldown,id:`deficit|${drawdown}|${cooldown}`});
for(const profit of [.5,1,2,4])for(const sellFraction of [.1,.25,.5])for(const drawdown of [.2,.35,.5,.65])candidates.push({family:'harvest_then_dip',profit,sellFraction,drawdown,id:`harvest|${profit}|${sellFraction}|${drawdown}`});
for(const lookback of [21,63,126])for(const frequency of ['month','quarter'])candidates.push({family:'proxy_risk_balance',lookback,frequency,id:`risk|${lookback}|${frequency}`});
const protocol={version:1,createdAt:new Date().toISOString(),inputSHA256:sha(source),scope:{initial:100,weights:[.3,.3],cashWeight:.4,feeEachBuySell:fee,borrow:false,interest:0,personalTax:0},
 interpretation:'Ongoing holdings management, not merely finding the first entry. All active target stock exposure <= sum of user initial weights; natural between-trade appreciation can drift above this. Baseline receives the same initial weights and same buy fee. No further deposits, no terminal liquidation.',
 execution:'At common close t, decisions depend only on t-1 holdings/prices/history. Orders execute at t actual CNY close, all costs funded from available cash or sale proceeds. Only available real ETF prices used; max drawdown uses common closes, not union FX dates.',
 definitions:{calendar_rebalance:'Reset all holdings to initial weights monthly, quarterly or annually.',drift_band:'At declared frequency, reset all holdings to initial weights when any previous-close asset weight differs from its initial weight by more than band*initialWeight.',
 buy_only_deficit:'After the target-weight reference drawdown reaches threshold, and previous-close actual total stock weight is below original total, buy deficits only, without sales; restore stock exposure at most original total. Purchase sizes use previous-close deficits, bounded by current-close cash and same total exposure cap. Wait cooldown common trading dates between fills.',
 harvest_then_dip:'Per ETF, after price increases profit fraction from last harvest reference, sell sellFraction of prior-close units; bank net proceeds for that ETF. Buy its bank on drawdown from its running high, bounded by total stock exposure cap. A dip buy latches until drawdown recovers to less than half its threshold or a new harvest. Original unassigned cash is not used by this family.',
 proxy_risk_balance:'At declared frequency, reset stock total to original total and asset split proportional to initialWeight/(proxy log-return volatility *ETF daily leverage); proxy QQQ for TQQQ, SOXX for USD, real adjusted USD closes, prior available close only. Clip ETF1 share of stock allocation to20..80%. If no full proxy window, original weights.'},
 selection:'Evaluate finite grid on fixed28 development ten-year starts only; choose highest year-equal mean paired CAGR gain over same-fee lump in each family, then retain at most3 family champions with highest such development metric. Tie lexical id. Freeze chosen coefficients before viewing later35. Report negatives, no later reselection.',
 development:development.map(o=>o.start),evaluation:later.map(o=>o.start),weightChecks:[[.2,.4],[.4,.2],[.5,.5]],horizonChecks:[15],candidates,
 evidenceBoundary:'These calendar years were already investigated in prior research. This is retrospective new-policy testing, not untouched prospective validation.'};
function save(n,d){const f=path.join(DIR,n);assert(!fs.existsSync(f),'Will not overwrite '+f);fs.writeFileSync(f,JSON.stringify(d));}
function periodic(i,frequency){if(frequency==='daily')return true;const a=dates[i-1],b=dates[i];return frequency==='month'?a.slice(0,7)!==b.slice(0,7):frequency==='quarter'?a.slice(0,4)!==b.slice(0,4)||Math.floor((+a.slice(5,7)-1)/3)!==Math.floor((+b.slice(5,7)-1)/3):a.slice(0,4)!==b.slice(0,4);}
const proxySeries=['us:SOXX','us:QQQ'].map(id=>{const v=I.proxies?.[id];return Array.isArray(v)?v:v?.series??v?.rows??[]});
const proxyVol=new Map();
function proxyRisk(i,lookback,weights){
 const key=lookback+'|'+i;if(!proxyVol.has(key)){
  const sig=dates[i-1];const vv=proxySeries.map((rr,j)=>{let n=rr.length-1;while(n>=0&&rr[n][0]>sig)n--;if(n<lookback)return null;const r=[];for(let k=n-lookback+1;k<=n;k++)r.push(Math.log(rr[k][1]/rr[k-1][1]));return sd(r)*[2,3][j];});proxyVol.set(key,vv);
 }
 const vv=proxyVol.get(key),total=weights[0]+weights[1];if(vv.some(v=>!v))return weights;
 const a=weights[0]/vv[0],b=weights[1]/vv[1],share=Math.max(.2,Math.min(.8,a/(a+b)));return[total*share,total*(1-share)];
}
function account(o,c,weights=[.3,.3],detail=false){
 const begin=di.get(o.start),end=di.get(o.end);assert(begin!=null&&end!=null);const total=weights[0]+weights[1];
 let cash=100,q=[0,0],fees=0,turnover=0,trades=0,peak=100,mdd=0,maxActiveTarget=total,lastFill=-Infinity;
 const priceHigh=px[begin].slice(),harvestRef=px[begin].slice(),bank=[0,0],dipLatched=[false,false],orders=[];
 let reference=1,refPeak=1;
 function value(p){return cash+q[0]*p[0]+q[1]*p[1];}
 function trade(i,delta,why){
  const p=px[i],before=value(p),notional=Math.abs(delta[0])*p[0]+Math.abs(delta[1])*p[1],cost=notional*fee;
  cash-=delta[0]*p[0]+delta[1]*p[1]+cost;for(let j=0;j<2;j++)q[j]+=delta[j];
  assert(cash>=-1e-8&&q.every(x=>x>=-1e-10));if(cash<0)cash=0;
  fees+=cost;turnover+=notional/before;trades+=delta.filter(x=>Math.abs(x)>1e-12).length;
  if(detail&&notional>1e-10)orders.push({date:dates[i],signalDate:i===begin?null:dates[i-1],delta,notional,cost,why,cash});
 }
 function rebalance(i,w,why){
  assert(w[0]+w[1]<=total+1e-12);maxActiveTarget=Math.max(maxActiveTarget,w[0]+w[1]);const p=px[i],v=value(p),old=q.map((x,j)=>x*p[j]);let net=v;
  for(let k=0;k<8;k++)net=v-fee*(Math.abs(w[0]*net-old[0])+Math.abs(w[1]*net-old[1]));
  trade(i,w.map((a,j)=>a*net/p[j]-q[j]),why);
 }
 rebalance(begin,weights,'initial');
 for(let i=begin;i<=end;i++){
  if(i>begin){
   const prev=px[i-1],vPrev=value(prev),stockPrev=q[0]*prev[0]+q[1]*prev[1],actual=q.map((x,j)=>x*prev[j]/vPrev),dd=1-reference/refPeak;
   for(let j=0;j<2;j++)priceHigh[j]=Math.max(priceHigh[j],prev[j]);
   if(c.family==='calendar_rebalance'&&periodic(i,c.frequency))rebalance(i,weights,'calendar');
   if(c.family==='drift_band'&&periodic(i,c.frequency)&&actual.some((w,j)=>Math.abs(w-weights[j])>c.band*weights[j]))rebalance(i,weights,'drift');
   if(c.family==='proxy_risk_balance'&&periodic(i,c.frequency))rebalance(i,proxyRisk(i,c.lookback,weights),'proxy_risk');
   if(c.family==='buy_only_deficit'&&dd>=c.drawdown&&stockPrev/vPrev<total-1e-10&&i-lastFill>=c.cooldown){
    const current=px[i],v=value(current),stock=q[0]*current[0]+q[1]*current[1],maxBuy=Math.max(0,Math.min(cash/(1+fee),(total*v-stock)/(1+total*fee)));
    const deficit=actual.map((a,j)=>Math.max(0,weights[j]-a)),sum=deficit[0]+deficit[1];
    if(maxBuy>1e-10&&sum>0){trade(i,deficit.map((d,j)=>maxBuy*d/sum/current[j]),'cash_deficit');lastFill=i;}
   }
   if(c.family==='harvest_then_dip')for(let j=0;j<2;j++){
    const drawdown=1-prev[j]/priceHigh[j];if(drawdown<c.drawdown*.5)dipLatched[j]=false;
    if(prev[j]>=harvestRef[j]*(1+c.profit)){
     const sell=q[j]*c.sellFraction,delta=[0,0];delta[j]=-sell;trade(i,delta,'harvest');bank[j]+=sell*px[i][j]*(1-fee);harvestRef[j]=prev[j];dipLatched[j]=false;
    }else if(drawdown>=c.drawdown&&!dipLatched[j]&&bank[j]>1e-10){
     const p=px[i],v=value(p),stock=q[0]*p[0]+q[1]*p[1],buy=Math.max(0,Math.min(bank[j]/(1+fee),cash/(1+fee),(total*v-stock)/(1+total*fee)));
     if(buy>1e-10){const delta=[0,0];delta[j]=buy/p[j];trade(i,delta,'buy_back');bank[j]-=buy*(1+fee);dipLatched[j]=true;}
    }
   }
   reference*=1-total+weights[0]*px[i][0]/prev[0]+weights[1]*px[i][1]/prev[1];refPeak=Math.max(refPeak,reference);
  }
  const v=value(px[i]);peak=Math.max(peak,v);mdd=Math.min(mdd,100*(v/peak-1));
 }
 const final=value(px[end]),years=(Date.parse(o.end)-Date.parse(o.start))/864e5/365.2425;
 return{start:o.start,end:o.end,years:o.years,value:final,annualReturn:100*((final/100)**(1/years)-1),mdd,fees,turnoverPct:turnover*100,annualTurnoverPct:turnover*100/years,trades,cash,maxActiveTarget,...detail?{orders}:{} };
}
function summarize(rows,baselines){
 const pairs=rows.map((r,i)=>{const b=baselines[i];assert(r.start===b.start&&r.end===b.end);return{start:r.start,d:r.annualReturn-b.annualReturn,wealth:100*(r.value/b.value-1)}}),yy={};for(const p of pairs)(yy[p.start.slice(0,4)]??=[]).push(p.d);
 return{n:rows.length,yearEqualCAGRpp:mean(Object.values(yy).map(mean)),wins:pairs.filter(p=>p.d>1e-9).length,ties:pairs.filter(p=>Math.abs(p.d)<=1e-9).length,losses:pairs.filter(p=>p.d< -1e-9).length,medianWealthRelativePct:median(pairs.map(p=>p.wealth)),medianCAGR:median(rows.map(r=>r.annualReturn)),medianMDD:median(rows.map(r=>r.mdd)),worstMDD:Math.min(...rows.map(r=>r.mdd)),medianCosts:median(rows.map(r=>r.fees)),medianAnnualTurnoverPct:median(rows.map(r=>r.annualTurnoverPct)),meanTrades:mean(rows.map(r=>r.trades)),byYear:Object.fromEntries(Object.entries(yy).map(([k,v])=>[k,{n:v.length,meanCAGRpp:mean(v)}])),pairs};
}
function evaluate(c,oo,weights,detail=false){const base=oo.map(o=>account(o,{family:'lump_sum'},weights));const rows=oo.map(o=>account(o,c,weights,detail));return{summary:summarize(rows,base),rows,baseline:base};}
const mode=process.argv[2];
if(mode==='freeze')save('protocol.json',protocol);
else{
 const locked=JSON.parse(fs.readFileSync(path.join(DIR,'protocol.json')));assert.equal(locked.inputSHA256,sha(source));assert.deepEqual(locked.candidates,candidates);
 if(mode==='develop'){
  const results=candidates.map(c=>({c,...evaluate(c,development,[.3,.3])}));results.sort((a,b)=>b.summary.yearEqualCAGRpp-a.summary.yearEqualCAGRpp||a.c.id.localeCompare(b.c.id));save('development.json',{inputSHA256:sha(source),protocolSHA256:sha(fs.readFileSync(path.join(DIR,'protocol.json'))),results});
  const seen=new Set(),chosen=[];for(const r of results){if(seen.has(r.c.family))continue;seen.add(r.c.family);chosen.push({c:r.c,development:r.summary});if(chosen.length===3)break;}
  save('selection.json',{protocolSHA256:sha(fs.readFileSync(path.join(DIR,'protocol.json'))),developmentSHA256:sha(fs.readFileSync(path.join(DIR,'development.json'))),chosen});console.log(JSON.stringify(chosen,null,2));
 }else if(mode==='evaluate'){
  const selection=JSON.parse(fs.readFileSync(path.join(DIR,'selection.json')));const results=selection.chosen.map(r=>({c:r.c,later35:evaluate(r.c,later,[.3,.3],true),all10:evaluate(r.c,origins.filter(o=>o.years===10),[.3,.3]),all15:evaluate(r.c,origins.filter(o=>o.years===15),[.3,.3]),weights:locked.weightChecks.map(w=>({weights:w,later35:evaluate(r.c,later,w),all15:evaluate(r.c,origins.filter(o=>o.years===15),w)}))}));
  save('evaluation.json',{selectionSHA256:sha(fs.readFileSync(path.join(DIR,'selection.json'))),inputSHA256:sha(source),results});console.log(JSON.stringify(results.map(r=>({c:r.c,later:r.later35.summary,all10:r.all10.summary,all15:r.all15.summary,weights:r.weights.map(w=>({weights:w.weights,later:w.later35.summary,all15:w.all15.summary}))})),null,2));
 }else throw Error('mode freeze / develop / evaluate');
}
module.exports={account,evaluate,summarize};
