"""Independent cash-only replenishment replay and attribution controls.
Controls are diagnostics after the selected rule was locked, not new winners.
"""
import json, math, statistics, hashlib
from pathlib import Path
from datetime import date
from collections import defaultdict

HERE = Path(__file__).resolve().parent
inputs = json.loads((HERE.parent / 'inputs.json').read_text())
evaluation = json.loads((HERE / 'evaluation.json').read_text())
selection = json.loads((HERE / 'selection.json').read_text())
winner = next(x for x in selection['chosen'] if x['c']['family'] == 'buy_only_deficit')
assert winner['c'] == {'family': 'buy_only_deficit', 'drawdown': .05, 'cooldown': 21, 'id': 'deficit|0.05|21'}
days = [x[0] for x in inputs['daily']]
prices = [x[1] for x in inputs['daily']]
index = {day: i for i, day in enumerate(days)}
fee = .001

def run(origin, weights, threshold=.05, cooldown=21, hold=False, fee_rate=.001):
    fee = fee_rate
    start, end = index[origin['start']], index[origin['end']]
    total = sum(weights)
    net = 100 / (1 + fee * total)
    quantities = [weights[j] * net / prices[start][j] for j in range(2)]
    cash = (1-total)*net
    cost = fee * total * net
    reference, high, peak, mdd = 1., 1., 100., 0.
    last_fill = -10**9
    orders = []
    mean_exposure = []
    marked_values = []
    max_individual = [0., 0.]
    min_cash = cash
    max_after_buy = total
    for i in range(start, end+1):
        if i > start:
            p0, p1 = prices[i-1], prices[i]
            previous_holdings = [quantities[j] * p0[j] for j in range(2)]
            previous_value = cash + sum(previous_holdings)
            observed_exposure = sum(previous_holdings) / previous_value
            if not hold and 1-reference/high >= threshold and observed_exposure < total-1e-10 and i-last_fill >= cooldown:
                holdings = [quantities[j] * p1[j] for j in range(2)]
                before = cash + sum(holdings)
                budget = max(0, min(cash/(1+fee), (total*before-sum(holdings))/(1+total*fee)))
                shortfalls = [max(0, weights[j]-previous_holdings[j]/previous_value) for j in range(2)]
                if budget > 1e-10 and sum(shortfalls) > 0:
                    allocation = [budget * v / sum(shortfalls) for v in shortfalls]
                    for j in range(2):
                        quantities[j] += allocation[j] / p1[j]
                    cash -= budget * (1+fee)
                    cost += budget*fee
                    after_holdings = sum(quantities[j]*p1[j] for j in range(2))
                    after_value = cash + after_holdings
                    exposure = after_holdings / after_value
                    assert cash >= -1e-10 and exposure <= total + 1e-10
                    max_after_buy = max(max_after_buy, exposure)
                    orders.append({'date': days[i], 'signalDate': days[i-1], 'notional': budget, 'fee': budget*fee,
                                   'cash': cash, 'allocation': allocation, 'exposureAfterBuy': exposure})
                    last_fill = i
            reference *= 1-total + sum(weights[j]*p1[j]/p0[j] for j in range(2))
            high = max(high, reference)
        stock_value = sum(quantities[j]*prices[i][j] for j in range(2))
        value = cash + stock_value
        peak = max(peak, value)
        mdd = min(mdd, 100*(value/peak-1))
        mean_exposure.append(stock_value/value)
        marked_values.append(value)
        for j in range(2):
            max_individual[j] = max(max_individual[j], quantities[j]*prices[i][j]/value)
        min_cash = min(min_cash, cash)
    elapsed = (date.fromisoformat(origin['end'])-date.fromisoformat(origin['start'])).days / 365.2425
    returns = sorted(100*(marked_values[i]/marked_values[i-1]-1) for i in range(1,len(marked_values)))
    cvar = statistics.mean(returns[:math.ceil(.05*len(returns))])
    return dict(start=origin['start'], end=origin['end'], years=origin['years'], value=value,
                annualReturn=100*((value/100)**(1/elapsed)-1), mdd=mdd, costs=cost,
                addedBuyNotional=sum(o['notional'] for o in orders), remainingCash=cash,
                meanStockExposure=statistics.mean(mean_exposure), minimumCash=min_cash,
                maxExposureImmediatelyAfterAdditionalBuy=max_after_buy,
                maximumStockExposureAcrossHistory=max(mean_exposure),maximumIndividualETFWeights=max_individual,
                dailyCVaR95Pct=cvar, totalActualPurchaseNotional=total*net+sum(o['notional'] for o in orders),orders=orders)

def summary(a, b):
    assert len(a)==len(b)
    grouped=defaultdict(list)
    diffs=[]
    for r,c in zip(a,b):
        assert (r['start'],r['end'])==(c['start'],c['end'])
        d=r['annualReturn']-c['annualReturn'];diffs.append(d);grouped[r['start'][:4]].append(d)
    return dict(n=len(a),yearEqualCAGRpp=statistics.mean(statistics.mean(v) for v in grouped.values()),
                wins=sum(d>1e-9 for d in diffs),ties=sum(abs(d)<=1e-9 for d in diffs),losses=sum(d< -1e-9 for d in diffs),
                medianWealthRelativePct=statistics.median(100*(r['value']/c['value']-1) for r,c in zip(a,b)),
                medianMDD=statistics.median(r['mdd'] for r in a),medianBaselineMDD=statistics.median(r['mdd'] for r in b),
                medianMDDDifferencePP=statistics.median(r['mdd']-c['mdd'] for r,c in zip(a,b)),
                medianAdditionalBuyNotional=statistics.median(r['addedBuyNotional'] for r in a),
                medianRemainingCash=statistics.median(r['remainingCash'] for r in a),
                meanStockExposure=statistics.mean(r['meanStockExposure'] for r in a),
                meanBaselineStockExposure=statistics.mean(r['meanStockExposure'] for r in b),
                medianDailyCVaR95Pct=statistics.median(r['dailyCVaR95Pct'] for r in a),
                medianBaselineDailyCVaR95Pct=statistics.median(r['dailyCVaR95Pct'] for r in b),
                minimumCashAcrossAccounts=min(r['minimumCash'] for r in a),
                maximumStockExposureAcrossAccounts=max(r['maximumStockExposureAcrossHistory'] for r in a),
                maximumBaselineStockExposureAcrossAccounts=max(r['maximumStockExposureAcrossHistory'] for r in b),
                maximumStockExposureAfterAnyAdditionalBuy=max(r['maxExposureImmediatelyAfterAdditionalBuy'] for r in a),
                medianTotalActualPurchaseNotional=statistics.median(r['totalActualPurchaseNotional'] for r in a),
                medianBaselinePurchaseNotional=statistics.median(r['totalActualPurchaseNotional'] for r in b),
                medianTotalTransactionFee=statistics.median(r['costs'] for r in a),
                medianBaselineTransactionFee=statistics.median(r['costs'] for r in b))

def main():
    records=[];max_error={'value':0,'annualReturn':0,'mdd':0};selected=next(r for r in evaluation['results'] if r['c']['family']=='buy_only_deficit')
    for weights in [[.3,.3],[.2,.4],[.4,.2],[.5,.5]]:
        for period in ['later35','all10','all15']:
            origins=[o for o in inputs['origins'] if o['years']==(15 if period=='all15' else 10) and (period!='later35' or '2014'<=o['start']<'2017')]
            base=[run(o,weights,hold=True) for o in origins]
            chosen=[run(o,weights) for o in origins]
            same_cooldown=[run(o,weights,threshold=0) for o in origins]
            everyday=[run(o,weights,threshold=0,cooldown=1) for o in origins]
            frozen=selected[period]['rows'] if weights==[.3,.3] else next((r[period]['rows'] for r in selected['weights'] if r['weights']==weights and period in r),None)
            if frozen:
                assert len(chosen)==len(frozen)
                for x,y in zip(chosen,frozen):
                    assert (x['start'],x['end'])==(y['start'],y['end'])
                    for k in max_error:
                        err=abs(x[k]-y[k]);max_error[k]=max(max_error[k],err);assert err<1e-8,(k,err)
            records.append({'weights':weights,'period':period,'selectedVsLump':summary(chosen,base),
                            'selectedVsNoDrawdownGateSame21Cooldown':summary(chosen,same_cooldown),
                            'selectedVsNoGateDailyCashReplenishment':summary(chosen,everyday),
                            'noDrawdownGateSame21CooldownVsLump':summary(same_cooldown,base),
                            'noGateDailyCashReplenishmentVsLump':summary(everyday,base),
                            'selectedAccounts':chosen,'lumpAccounts':base})
    result={'inputSHA256':hashlib.sha256((HERE.parent/'inputs.json').read_bytes()).hexdigest(),
            'selectionSHA256':hashlib.sha256((HERE/'selection.json').read_bytes()).hexdigest(),
            'method':'Independent Python fractional-holdings ledger, no import of JS implementation.',
            'controlsStatus':'Diagnostic after selection/evaluation, no new rule chosen; distinguishes a drawdown gate from mechanical deployment of the same available cash.',
            'performanceInterpretation':'Same initial100, same original risk weights, no borrowing/deposits; selected method consumes some original40 cash reserve after declines. Its average market exposure can exceed buy-and-hold, despite not buying above original60% target. It is not a risk-exposure-matched alpha estimate.',
            'maximumIndependentErrors':max_error,'records':records}
    destination=HERE/'independent-audit.json'
    assert not destination.exists()
    destination.write_text(json.dumps(result,separators=(',',':')))
    print(json.dumps({'errors':max_error,'selected':[{k:r[k] for k in ['weights','period','selectedVsLump','selectedVsNoDrawdownGateSame21Cooldown','selectedVsNoGateDailyCashReplenishment']} for r in records]},indent=2))

if __name__ == "__main__":
    main()
