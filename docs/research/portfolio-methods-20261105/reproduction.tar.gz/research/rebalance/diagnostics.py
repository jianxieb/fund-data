"""Locked-rule fee/risk/parameter-neighborhood diagnostics, no reselection."""
import json, hashlib, statistics, math
from pathlib import Path
from audit import run, summary, inputs, HERE, days

def origins(period):
    return [o for o in inputs['origins'] if o['years']==(15 if period=='all15' else 10)
            and (period!='later35' or '2014'<=o['start']<'2017')]

def evaluate(weights,period,fee,threshold=.05,cooldown=21):
    oo=origins(period)
    base=[run(o,weights,hold=True,fee_rate=fee) for o in oo]
    rr=[run(o,weights,threshold=threshold,cooldown=cooldown,fee_rate=fee) for o in oo]
    return dict(weights=weights,period=period,fee=fee,threshold=threshold,cooldown=cooldown,summary=summary(rr,base),accounts=rr,baseline=base)

fees=[]
for weights in [[.3,.3],[.2,.4],[.4,.2],[.5,.5]]:
    for period in ['later35','all15']:
        for fee in [.001,.002,.005]:
            fees.append(evaluate(weights,period,fee))

neighborhood=[]
for threshold in [.025,.05,.1]:
    for cooldown in [5,21,63]:
        for period in ['later35','all15']:
            neighborhood.append(evaluate([.3,.3],period,.001,threshold,cooldown))

control=[]
for weights in [[.3,.3],[.2,.4],[.4,.2],[.5,.5]]:
    for period in ['later35','all15']:
        chosen=evaluate(weights,period,.001)
        for cooldown in [1,21]:
            other=evaluate(weights,period,.001,0,cooldown)
            control.append({'weights':weights,'period':period,'control':'no_drawdown_gate','cooldown':cooldown,
                            'selectedVsControl':summary(chosen['accounts'],other['accounts']),
                            'controlVsLump':other['summary']})

examples=[]
for start in ['2014-01-02','2015-01-02','2016-01-04']:
    o=next(o for o in inputs['origins'] if o['years']==10 and o['start']==start)
    r=run(o,[.3,.3]);examples.append(r)

out={'selectionSHA256':hashlib.sha256((HERE/'selection.json').read_bytes()).hexdigest(),
     'status':'POST_SELECTION_DIAGNOSTIC_ONLY_NO_CHAMPION_REPLACEMENT',
     'cvarDefinition':'Mean of the worst ceil(5%*N) common-close daily account returns, including transaction costs; negative percent. This is historical CVaR, not a forecast.',
     'riskMeaning':'Additional buys use original cash and increase long-run stock exposure. Original maximum active target is respected, but stock weights may naturally appreciate above it between buys. All exposure and cash extrema explicitly reported.',
     'neighborhoodDefinition':'All 2.5/5/10 percent drawdown x5/21/63 common-date cooldown cases shown together; not used to replace the previously chosen5/21 rule.',
     'feeSensitivity':fees,'neighborhood':neighborhood,'controls':control,'exampleAccounts':examples}
p=HERE/'diagnostics.json';assert not p.exists();p.write_text(json.dumps(out,separators=(',',':')))
print(json.dumps({'fees':[{'weights':r['weights'],'period':r['period'],'fee':r['fee'],**r['summary']} for r in fees],
                  'neighborhood':[{'period':r['period'],'threshold':r['threshold'],'cooldown':r['cooldown'],**r['summary']} for r in neighborhood]},indent=2))
