"""Independent Python stress verification from raw QQQ and simple cash/units arithmetic."""
import json,hashlib,statistics
from pathlib import Path
P=Path(__file__).resolve().parent
# Reuse only our separately authored Python feature/ledger functions, never the risk JS.
source=(P/'risk-independent-audit.py').read_text().split('records=[];')[0]
source=source.replace('def run(o,w,hold=False,trace=False):','def run(o,w,hold=False,trace=False,fee=.001,phase=0,delay=0):').replace("a,b=di[o['start']],di[o['end']];f=.001;","a,b=di[o['start']],di[o['end']];f=fee;")
source=source.replace('if i==a or not hold and i%5==0:', 'if i==a+delay or i>a+delay and not hold and (i-delay)%5==phase:').replace('feature=features[i-1] if i else None','feature=features[i-1-delay] if i-1-delay>=0 else None').replace("ds[i-1] if i else None","ds[i-1-delay] if i-1-delay>=0 else None")
ns={'__file__':str(P/'risk-independent-audit.py')};exec(source,ns)
run,cmp,D,di=ns['run'],ns['cmp'],ns['D'],ns['di']
R=P.parent/'risk';S=json.loads((R/'stress-results.json').read_text());errs={k:0. for k in ['value','annualReturn','mdd','maxExposure','totalFees','transactions','permanentCash','finalCash']};groups=[];bcache={};n=points=0
for g in S['results']:
 if g['label'] not in ['later35','all15_21']:continue
 a=[];b=[];setting=g['setting']
 for row in g['rows']:
  o={'start':row['start'],'end':row['end']};r=run(o,g['weights'],**setting)
  for k in errs:
   delta=abs(r[k]-row[k]);errs[k]=max(errs[k],delta);assert delta<1e-8,(setting,g['weights'],g['label'],row['start'],k,delta)
  key=(o['start'],o['end'],tuple(g['weights']),setting['fee'])
  if key not in bcache:bcache[key]=run(o,g['weights'],hold=True,fee=setting['fee'])
  a.append(r);b.append(bcache[key]);n+=1;points+=di[o['end']]-di[o['start']]+1
 summary=cmp(a,b)
 for k in ['yearEqualCAGRpp','wins','losses','ties','medianWealthRelativePct','medianMDD','medianTradingCost']:
  assert abs(summary[k]-g['summary'][k])<1e-8,(setting,g['weights'],g['label'],k)
 groups.append({'setting':setting,'weights':g['weights'],'period':g['label'],'summary':summary})
 print(json.dumps({'doneGroups':len(groups),'accounts':n}),flush=True) if len(groups)%40==0 else None
ranges=[]
for w in [[.3,.3],[.2,.4],[.4,.2],[.5,.5]]:
 for label in ['later35','all15_21']:
  allg=[g for g in groups if g['weights']==w and g['period']==label];phase=[g for g in allg if g['setting']['fee']==.001 and g['setting']['delay']==0]
  ranges.append({'weights':w,'period':label,'originalFeeNoDelayAll5Phases':{'minYearEqualCAGRpp':min(g['summary']['yearEqualCAGRpp'] for g in phase),'maxYearEqualCAGRpp':max(g['summary']['yearEqualCAGRpp'] for g in phase),'minWins':min(g['summary']['wins'] for g in phase),'maxLosses':max(g['summary']['losses'] for g in phase)},'all30StressScenarios':{'minYearEqualCAGRpp':min(g['summary']['yearEqualCAGRpp'] for g in allg),'maxYearEqualCAGRpp':max(g['summary']['yearEqualCAGRpp'] for g in allg),'minWins':min(g['summary']['wins'] for g in allg),'maxLosses':max(g['summary']['losses'] for g in allg),'positiveAverageScenarios':sum(g['summary']['yearEqualCAGRpp']>0 for g in allg)}})
out={'passed':True,'candidateAccounts':n,'uniqueSameFeeBaselines':len(bcache),'valuationPoints':points,'groups':len(groups),'maxErrors':errs,'ranges':ranges,'records':groups,'sourceHashes':{str(p.relative_to(P.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [P.parent/'inputs.json',R/'stress-protocol.json',R/'stress-results.json',R/'stress-engine.cjs',P/'risk-independent-audit.py',P/'risk-stress-independent-audit.py']},'interpretation':'All fixed scenarios reported; no best-phase selection. This is independent numerical replication, not unseen empirical validation.'}
(P/'risk-stress-independent-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2))
