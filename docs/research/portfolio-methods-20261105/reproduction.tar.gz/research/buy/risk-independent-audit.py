"""Independent raw-QQQ reconstruction of the TQQQ-only rule; does not import risk JS."""
import json,math,statistics,hashlib,bisect
from pathlib import Path
from datetime import date
from collections import defaultdict
P=Path(__file__).resolve().parent;R=P.parent/'risk';I=json.loads((P.parent/'inputs.json').read_text());E=json.loads((R/'stage2-results.json').read_text());D=I['daily'];ds=[r[0] for r in D];di={d:i for i,d in enumerate(ds)};Q=I['proxies']['us:QQQ']['series'];qd=[r[0] for r in Q];qv=[r[1] for r in Q]
F=[]
for k,(d,p) in enumerate(Q):
 ma=statistics.mean(qv[k-199:k+1]) if k>=199 else None
 vol=statistics.stdev(math.log(qv[j]/qv[j-1]) for j in range(k-20,k+1))*math.sqrt(252) if k>=21 else None
 F.append((d,p,ma,vol))
features=[]
for day in ds:
 k=bisect.bisect_right(qd,day)-1
 features.append(F[k] if k>=0 and (date.fromisoformat(day)-date.fromisoformat(qd[k])).days<=7 else None)

def run(o,w,hold=False,trace=False):
 a,b=di[o['start']],di[o['end']];f=.001;cash=[100*x for x in w];permanent=100*(1-sum(w));q=[0.,0.];target=1;peak=100.;mdd=0.;maxexp=0.;fees=0.;trades=[];curve=[];decisions=[]
 for i in range(a,b+1):
  p=D[i][1];stock=sum(q[j]*p[j] for j in range(2));before=permanent+sum(cash)+stock;maxexp=max(maxexp,stock/before)
  if i==a or not hold and i%5==0:
   feature=features[i-1] if i else None
   if not hold and feature and feature[2] is not None and feature[3] is not None:target=0 if feature[1]<feature[2] and feature[3]>.3 else 1
   decisions.append((ds[i],ds[i-1] if i else None,target))
   for j in range(2):
    wanted=1 if j==0 or hold else target
    if wanted==1:
     amount=cash[j]/(1+f)
     if amount<=max(1,cash[j]+q[j]*p[j])*1e-12:continue
     q[j]+=amount/p[j];cash[j]-=amount*(1+f);side='buy'
    else:
     amount=q[j]*p[j]
     if amount<=max(1,cash[j]+amount)*1e-12:continue
     cash[j]+=amount*(1-f);q[j]=0.;side='sell'
    fee=amount*f;fees+=fee
    if abs(cash[j])<1e-10:cash[j]=0.
    assert cash[j]>=-1e-8 and q[j]>=0
    trades.append({'day':ds[i],'signalDay':ds[i-1] if i else None,'leg':j,'side':side,'amount':amount,'fee':fee,'target':wanted,'cash':cash[j],'units':q[j]})
  stock=sum(q[j]*p[j] for j in range(2));value=permanent+sum(cash)+stock;peak=max(peak,value);mdd=min(mdd,100*(value/peak-1));maxexp=max(maxexp,stock/value)
  if trace:curve.append({'day':ds[i],'value':value,'market':stock,'cash':permanent+sum(cash),'permanentCash':permanent,'units':q.copy(),'sleeveCash':cash.copy()})
 elapsed=(date.fromisoformat(o['end'])-date.fromisoformat(o['start'])).days/365.2425
 return {'start':o['start'],'end':o['end'],'value':value,'annualReturn':100*((value/100)**(1/elapsed)-1),'mdd':mdd,'maxExposure':maxexp,'totalFees':fees,'transactions':len(trades),'permanentCash':permanent,'finalCash':permanent+sum(cash),'trades':trades,'curve':curve,'decisions':decisions}

def cmp(a,b):
 years=defaultdict(list);diff=[]
 for r,s in zip(a,b):
  x=r['annualReturn']-s['annualReturn'];diff.append(x);years[r['start'][:4]].append(x)
 return {'n':len(a),'yearEqualCAGRpp':statistics.mean(statistics.mean(x) for x in years.values()),'wins':sum(x>1e-9 for x in diff),'ties':sum(abs(x)<=1e-9 for x in diff),'losses':sum(x< -1e-9 for x in diff),'medianWealthRelativePct':statistics.median(100*(r['value']/s['value']-1) for r,s in zip(a,b)),'medianMDD':statistics.median(r['mdd'] for r in a),'baselineMedianMDD':statistics.median(r['mdd'] for r in b),'medianTradingCost':statistics.median(r['totalFees'] for r in a),'byYear':{y:statistics.mean(v) for y,v in years.items()}}
records=[];err={k:0 for k in ['value','annualReturn','mdd','maxExposure','totalFees','transactions','permanentCash','finalCash']};count=points=trades=0
for g in E['results']:
 if g['maskName']!='tqqq_only' or g['label'] not in ['later35','all15_21']:continue
 actual=[];base=[]
 for row,baseRow in zip(g['rows'],g['baseline']):
  o={'start':row['start'],'end':row['end']};a=run(o,g['weights']);b=run(o,g['weights'],hold=True)
  for got,want in [(a,row),(b,baseRow)]:
   for k in err:
    z=abs(got[k]-want[k]);err[k]=max(err[k],z);assert z<1e-8,(k,z)
  count+=1;points+=di[o['end']]-di[o['start']]+1;trades+=len(a['trades']);actual.append(a);base.append(b)
 records.append({'weights':g['weights'],'period':g['label'],'summary':cmp(actual,base)})
# Full-precision comparison with separately saved first later trace, including every decision execution and cash move.
T=json.loads((R/'stage2-trace-example.json').read_text())['trace'];o={'start':T['start'],'end':T['end']};x=run(o,T['weights'],trace=True)
assert len(x['curve'])==len(T['curve']) and len(x['trades'])==len(T['trades'])
traceerr=0.
for a,b in zip(x['curve'],T['curve']):
 assert a['day']==b['day']
 for k in ['value','market','cash','permanentCash']:traceerr=max(traceerr,abs(a[k]-b[k]))
 for k in ['units','sleeveCash']:
  for c,d in zip(a[k],b[k]):traceerr=max(traceerr,abs(c-d))
for a,b in zip(x['trades'],T['trades']):
 for k in ['day','signalDay','leg','side','target']:assert a[k]==b[k],(k,a,b)
 for k in ['amount','fee','cash','units']:traceerr=max(traceerr,abs(a[k]-b[k]))
assert traceerr<1e-8
out={'passed':True,'independentEngine':'Python raw QQQ21-log-return sample SD annualized sqrt252, raw trailing200 closing SMA; direct all-in/all-out sleeve cash arithmetic, no JS reuse','accountCount':count,'baselineAccountCount':count,'valuationPoints':points,'trades':trades,'maxErrors':err,'traceMaxError':traceerr,'tracePoints':len(x['curve']),'traceTrades':len(x['trades']),'records':records,'feeConvention':'Each sleeve initially receives100*w, acquisitionnotional=budget/1.001, inactive original cash stays100*(1-sumw). Every sale charged0.10%. No final assumed liquidation. Baseline identical sleeve convention.','phase':'i%5==0 using common ETF history beginning2010-02-11; first entry always evaluated regardlessphase. This anchor is arbitrary and all5 phase sensitivity is required.','interpretation':'TQQQ-only mask was isolated after viewing later outcomes. Reproduction is not a new independent statistical validation.','sources':{str(p.relative_to(P.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [P.parent/'inputs.json',R/'study.cjs',R/'stage2.cjs',R/'stage2-protocol.json',R/'stage2-results.json']}}
(P/'risk-independent-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
