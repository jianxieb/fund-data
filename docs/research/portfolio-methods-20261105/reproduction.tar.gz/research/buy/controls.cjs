'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
process.argv[2]='library';const S=require('./study.cjs'),D=S.D,ix=new Map(D.map((r,i)=>[r[0],i]));
function fixed(o,n,w=[.3,.3]){const i=ix.get(o.start)+n,e=ix.get(o.end),sum=w[0]+w[1],f=100/(1+sum*.001);let v=f*(1-sum);for(let j=0;j<2;j++)v+=f*w[j]*D[e][1][j]/D[i][1][j];return{start:o.start,end:o.end,years:o.years,value:v,annualReturn:100*((v/100)**(365.2425/o.calendarDays)-1),weightedWaitCalendarDays:(Date.parse(D[i][0])-Date.parse(o.start))/864e5,initialStockPct:n?0:f*sum,missing:false};}
const E=JSON.parse(fs.readFileSync(path.join(__dirname,'evaluation.json'))),out={rule:'Fixed waiting controls enumerated in full, no post-selection change to candidate rules',controls:[]};
for(const[period,origins]of [['development',S.train],['later10',S.later],['all15',S.input.origins.filter(o=>o.years===15)]])for(const delay of [1,3,5,10,21]){
 const base=origins.map(o=>S.account(o,null)),rows=origins.map(o=>fixed(o,delay));
 out.controls.push({period,delayTradingSessions:delay,vsLump:S.summary(rows,base),candidateVsThisControl:E.results.map(r=>({id:r.c.id,summary:S.summary(origins.map(o=>S.account(o,r.c)),rows)}))});
}
fs.writeFileSync(path.join(__dirname,'fixed-delay-controls.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out.controls.filter(r=>r.period==='later10').map(r=>({delay:r.delayTradingSessions,vsLump:r.vsLump.yearEqualCAGRpp,candidates:r.candidateVsThisControl.map(x=>[x.id,x.summary.yearEqualCAGRpp])})),null,2));
