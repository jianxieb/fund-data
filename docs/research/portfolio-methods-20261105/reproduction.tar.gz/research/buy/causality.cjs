'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const dir=__dirname,code=fs.readFileSync(path.join(dir,'study.cjs'),'utf8'),original=JSON.parse(fs.readFileSync(path.join(dir,'..','inputs.json')));
const selection=JSON.parse(fs.readFileSync(path.join(dir,'selection.json'))).selected.map(r=>r.c);
function loaded(input){const module={exports:{}};const customFS={...fs,readFileSync(n,encoding){return path.basename(String(n))==='inputs.json'?(encoding?JSON.stringify(input):Buffer.from(JSON.stringify(input))):fs.readFileSync(n,encoding);}};
 const req=n=>n==='fs'?customFS:require(n);
 new Function('require','module','__dirname','__filename','process',code)(req,module,dir,path.join(dir,'study.cjs'),{argv:['node','study.cjs','library']});return module.exports;
}
const base=loaded(original);let checks=0;
for(const origin of [base.later[0],base.later[13],base.later.at(-1)]){
 const di=base.D.findIndex(r=>r[0]===origin.start),cutoff=base.D[di+2][0];
 const changed=structuredClone(original);
 changed.daily=changed.daily.map(([d,p])=>[d,d>cutoff?p.map((x,j)=>x*(j+3)):p]);
 changed.vix=changed.vix.map(r=>r[0]>cutoff?[r[0],99,11]:r);
 for(const p of Object.values(changed.proxies))p.series=p.series.map(([d,x])=>[d,d>cutoff?x*5:x]);
 const mutant=loaded(changed);
 for(const c of selection)for(const leg of [0,1]){
  const prefix=rows=>rows.filter(([i])=>base.D[i][0]<=cutoff);
  assert.deepEqual(prefix(base.legPlan(origin,c,leg).plan),prefix(mutant.legPlan(origin,c,leg).plan));checks++;
 }
}
const out={passed:true,checks,meaning:'ETF/FX converted prices, proxy prices and VIX after each cutoff are mutated; earlier actual decisions stay identical. Frozen chosen formulas unchanged.'};
fs.writeFileSync(path.join(dir,'causality-audit.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
