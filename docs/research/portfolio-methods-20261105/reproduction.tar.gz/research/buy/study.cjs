'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const dir=__dirname, inputFile=path.join(dir,'..','inputs.json');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const input=JSON.parse(fs.readFileSync(inputFile,'utf8')),D=input.daily,dates=D.map(r=>r[0]),ix=new Map(dates.map((d,i)=>[d,i]));
const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:null;
const median=a=>{a=a.slice().sort((a,b)=>a-b);return a.length?(a[Math.floor((a.length-1)/2)]+a[Math.floor(a.length/2)])/2:null;};
const days=(a,b)=>(Date.parse(b)-Date.parse(a))/864e5;
const sd=a=>{const m=mean(a);return Math.sqrt(a.reduce((s,x)=>s+(x-m)**2,0)/(a.length-1));};
const fee=.001, sourceModes=['self','QQQ','paired_proxy'];
function features(series){
 const vals=series.map(r=>r[1]),rr=vals.map((v,i)=>i?Math.log(v/vals[i-1]):0);
 return series.map(([date,v],i)=>{
  const row={date,value:v,ret1:i?v/vals[i-1]-1:null,vol:i>=21?sd(rr.slice(i-20,i+1)):null};
  for(const n of [2,3,5,14]){if(i<n){row['rsi'+n]=null;continue;}let gain=0,loss=0;for(let k=i-n+1;k<=i;k++){const d=vals[k]-vals[k-1];if(d>=0)gain+=d;else loss-=d;}row['rsi'+n]=gain+loss?100*gain/(gain+loss):50;}
  row.z20=i>=19?(v-mean(vals.slice(i-19,i+1)))/(sd(vals.slice(i-19,i+1))||Infinity):null;
  row.ma5=i>=4?mean(vals.slice(i-4,i+1)):null;row.ma20=i>=19?mean(vals.slice(i-19,i+1)):null;
  return row;
 });
}
const sources={};
for(let j=0;j<2;j++)sources['self'+j]=features(D.map(r=>[r[0],r[1][j]]));
for(const id of ['us:QQQ','us:SOXX']){
 const all=features(input.proxies[id].series);let k=-1;
 sources[id]=dates.map(day=>{while(k+1<all.length&&all[k+1].date<=day)k++;return k>=0&&days(all[k].date,day)<=7?all[k]:null;});
}
function source(mode,leg){return mode==='self'?sources['self'+leg]:sources[mode==='QQQ'?'us:QQQ':leg===0?'us:SOXX':'us:QQQ'];}
const candidates=[];
function add(family,p){candidates.push({family,...p,id:family+'|'+Object.values(p).join('|')});}
// Finite grid specified before running any outcome ranking.
for(const source of sourceModes)for(const gate of ['always','rsi14_70','z20_1'])for(const maxDays of [1,3,5,10,21])for(const sigma of [.5,1,2])for(const chase of [null,2])
 add('bounded_dip',{source,gate,maxDays,sigma,chase});
for(const source of sourceModes)for(const lookback of [2,3,5,14])for(const threshold of [10,30,50])for(const maxDays of [1,3,5,10])
 add('short_rsi',{source,lookback,threshold,maxDays});
for(const source of sourceModes)for(const maxDays of [3,5,10,21])for(const initial of [.5,.75,.9])for(const sigma of [.5,1,2])
 add('volatility_ladder',{source,maxDays,initial,sigma});
for(const source of sourceModes)for(const gate of ['rsi14_70','z20_1'])for(const maxDays of [3,5,10,21])for(const buySignal of ['red_vol_half','below_ma5','below_ma20'])
 add('stretch_wait',{source,gate,maxDays,buySignal});
for(const source of sourceModes)for(const maxDays of [3,5,10,21])for(const vixGate of [1,1.05,1.1])for(const initial of [0,.5])
 add('stress_recovery',{source,maxDays,vixGate,initial});
assert.equal(new Set(candidates.map(c=>c.id)).size,candidates.length);
const vix=dates.map(day=>{let j=input.vix.length-1;while(j>=0&&input.vix[j][0]>=day)j--;return j>=0&&days(input.vix[j][0],day)<=7?input.vix[j][1]/input.vix[j][2]:null;});
const train=input.origins.filter(o=>o.years===10&&o.start>='2011-09-01'&&o.start<'2014');
const later=input.origins.filter(o=>o.years===10&&o.start>='2014'&&o.start<'2017');
assert.equal(train.length,28);assert.equal(later.length,35);
function gate(f,name){return name==='always'||name==='rsi14_70'&&f.rsi14>=70||name==='z20_1'&&f.z20>=1;}
function legPlan(o,c,leg){
 const si=ix.get(o.start),f=source(c.source,leg),anchor=f[si-1];
 if(!anchor||!Number.isFinite(anchor.vol)||!Number.isFinite(anchor.rsi14))return{plan:[[si,1]],missing:true};
 const plan=[],push=(i,a)=>{if(a>1e-12)plan.push([i,a]);};
 const last=si+c.maxDays;assert(last<=ix.get(o.end));
 if(c.family==='bounded_dip'){
  if(!gate(anchor,c.gate))return{plan:[[si,1]],missing:false};
  for(let i=si;i<=last;i++){
   const p=f[i-1],r=p.value/anchor.value-1;
   if(i===last||r<=-c.sigma*anchor.vol||c.chase!==null&&r>=c.chase*anchor.vol){push(i,1);break;}
  }
 }else if(c.family==='short_rsi'){
  for(let i=si;i<=last;i++)if(i===last||f[i-1]['rsi'+c.lookback]<=c.threshold){push(i,1);break;}
 }else if(c.family==='volatility_ladder'){
  push(si,c.initial);let used=c.initial;
  for(let i=si+1;i<=last;i++){
   const d=1-f[i-1].value/anchor.value;
   const levels=[1,2,3].filter(k=>d>=k*c.sigma*anchor.vol).length;
   const target=i===last?1:Math.max(used,c.initial+(1-c.initial)*levels/3);
   push(i,target-used);used=target;
  }
 }else if(c.family==='stretch_wait'){
  if(!gate(anchor,c.gate))return{plan:[[si,1]],missing:false};
  for(let i=si;i<=last;i++){
   const p=f[i-1],buy=c.buySignal==='red_vol_half'?p.ret1<=-.5*p.vol:c.buySignal==='below_ma5'?p.value<=p.ma5:p.value<=p.ma20;
   if(i===last||buy){push(i,1);break;}
  }
 }else if(c.family==='stress_recovery'){
  if(vix[si-1]===null||vix[si-1]<c.vixGate)return{plan:[[si,1]],missing:vix[si-1]===null};
  push(si,c.initial);
  for(let i=si;i<=last;i++)if(i===last||f[i-1].ret1>0&&f[i-1].value>f[i-1].ma5){push(i,1-c.initial);break;}
 }else throw new Error('Bad family');
 assert(Math.abs(plan.reduce((s,p)=>s+p[1],0)-1)<1e-9);
 assert(plan.every(([i,a])=>i>=si&&i<=last&&a>0));
 return{plan,missing:false};
}
function account(o,c,weights=[.3,.3],detail=false){
 const start=ix.get(o.start),end=ix.get(o.end),stock=weights[0]+weights[1],factor=100/(1+stock*fee),cashFinal=factor*(1-stock);
 const plans=c?[legPlan(o,c,0),legPlan(o,c,1)]:[{plan:[[start,1]],missing:false},{plan:[[start,1]],missing:false}];
 const q=[0,0];let waitMoneyDays=0,initialNotional=0;
 for(let j=0;j<2;j++)for(const [i,fraction]of plans[j].plan){const cost=factor*weights[j]*fraction;q[j]+=cost/D[i][1][j];waitMoneyDays+=cost*days(o.start,dates[i]);if(i===start)initialNotional+=cost;}
 const value=cashFinal+q.reduce((s,u,j)=>s+u*D[end][1][j],0);
 const result={start:o.start,end:o.end,years:o.years,value,annualReturn:100*((value/100)**(365.2425/days(o.start,o.end))-1),cost:factor*stock*fee,initialStockPct:initialNotional,weightedWaitCalendarDays:stock?waitMoneyDays/(factor*stock):0,missing:plans.some(p=>p.missing)};
 if(detail){
  let peak=100,mdd=0,cash=100,q=[0,0];const byDay=new Map();
  for(let j=0;j<2;j++)for(const [i,fraction]of plans[j].plan){const cost=factor*weights[j]*fraction;const r=byDay.get(i)||[];r.push({leg:j,notional:cost,fee:cost*fee});byDay.set(i,r);}
  const trades=[];for(let i=start;i<=end;i++){
   for(const tr of byDay.get(i)||[]){cash-=tr.notional+tr.fee;q[tr.leg]+=tr.notional/D[i][1][tr.leg];trades.push({date:dates[i],signalDate:dates[i-1],...tr});}
   const value=cash+q.reduce((s,u,j)=>s+u*D[i][1][j],0);peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));assert(cash>=-1e-8);
  }
  assert(Math.abs(cash-cashFinal)<1e-8);assert(Math.abs(cash+q.reduce((s,u,j)=>s+u*D[end][1][j],0)-value)<1e-8);
  Object.assign(result,{mdd,trades,cash});
 }
 return result;
}
function summary(rows,base){
 const pairs=rows.map((r,i)=>{assert.equal(r.start,base[i].start);return{year:r.start.slice(0,4),d:r.annualReturn-base[i].annualReturn,wealth:100*(r.value/base[i].value-1)};});
 const years=[...new Set(pairs.map(p=>p.year))],byYear=Object.fromEntries(years.map(y=>[y,mean(pairs.filter(p=>p.year===y).map(p=>p.d))]));
 return{n:rows.length,yearEqualCAGRpp:mean(Object.values(byYear)),meanCAGRpp:mean(pairs.map(p=>p.d)),medianCAGRpp:median(pairs.map(p=>p.d)),medianWealthRelativePct:median(pairs.map(p=>p.wealth)),wins:pairs.filter(p=>p.d>1e-9).length,ties:pairs.filter(p=>Math.abs(p.d)<=1e-9).length,losses:pairs.filter(p=>p.d< -1e-9).length,byYear,meanWaitCalendarDays:mean(rows.map(r=>r.weightedWaitCalendarDays)),meanInitialStockPct:mean(rows.map(r=>r.initialStockPct)),missingN:rows.filter(r=>r.missing).length,medianMDD:rows.every(r=>r.mdd!==undefined)?median(rows.map(r=>r.mdd)):null,medianBaseMDD:base.every(r=>r.mdd!==undefined)?median(base.map(r=>r.mdd)):null};
}
function write(n,d){const file=path.join(dir,n);assert(!fs.existsSync(file),n+' exists');fs.writeFileSync(file,JSON.stringify(d,null,2)+'\n');}
const stage=process.argv[2];
if(stage==='freeze')write('protocol.json',{createdUTC:new Date().toISOString(),inputsSHA:hash(fs.readFileSync(inputFile)),codeSHA:hash(fs.readFileSync(__filename)),fee,initial:100,weights:[.3,.3],cashInterest:0,candidates,trainDates:train.map(o=>o.start),laterDates:later.map(o=>o.start),selection:'One development champion per family ranked by entry-year equal CAGR difference vs same-fee lump; select top3 families before later evaluation. Parameters fixed thereafter.',signals:'Only previous common close; VIX source date strictly earlier than signal common close, max7 calendar days. Assets execute at next common close. All purchased amounts use original fixed budget, no selling or external funding.',risk:'MDD on common ETF dates only, separate from system union FX valuation dates.',interpretation:'Retrospective grid/development labels overlap calendar outcomes. This is not a future guarantee or untouched independent validation.'});
else if(stage==='develop'){
 const protocol=JSON.parse(fs.readFileSync(path.join(dir,'protocol.json')));assert.equal(protocol.inputsSHA,hash(fs.readFileSync(inputFile)));assert.equal(protocol.codeSHA,hash(fs.readFileSync(__filename)));
 const base=train.map(o=>account(o,null)),rows=candidates.map(c=>({c,summary:summary(train.map(o=>account(o,c)),base)}));
 rows.sort((a,b)=>b.summary.yearEqualCAGRpp-a.summary.yearEqualCAGRpp||b.summary.medianWealthRelativePct-a.summary.medianWealthRelativePct||a.c.id.localeCompare(b.c.id));
 const champions=[];for(const r of rows)if(!champions.some(x=>x.c.family===r.c.family))champions.push(r);
 write('development.json',{protocolSHA:hash(fs.readFileSync(path.join(dir,'protocol.json'))),rows});write('selection.json',{selected:champions.slice(0,3),familyChampions:champions,selectionUTC:new Date().toISOString()});console.log(JSON.stringify(champions,null,2));
}else if(stage==='evaluate'){
 const selected=JSON.parse(fs.readFileSync(path.join(dir,'selection.json'))).selected,results=[];
 for(const item of selected){
  const c=item.c,groups=[];
  for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const[period,origins]of [['later10',later],['all15',input.origins.filter(o=>o.years===15)]]){
   const rows=origins.map(o=>account(o,c,weights,true)),base=origins.map(o=>account(o,null,weights,true));groups.push({period,weights,summary:summary(rows,base),rows,base});
  }
  results.push({c,development:item.summary,groups});
 }
 write('evaluation.json',{selectionSHA:hash(fs.readFileSync(path.join(dir,'selection.json'))),results});console.log(JSON.stringify(results.map(r=>({c:r.c,groups:r.groups.map(g=>({period:g.period,weights:g.weights,...g.summary}))})),null,2));
}else if(stage!=='library')throw new Error('freeze/develop/evaluate/library');
module.exports={account,legPlan,summary,features,train,later,candidates,D,input,sources};
