"use strict";
// Edge and perturbation harness. The Python sibling independently reconstructs the financial engine.
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto');
const ROOT=path.resolve(__dirname,'..'),R=path.join(ROOT,'risk'),input=JSON.parse(fs.readFileSync(path.join(ROOT,'inputs.json')));
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
function load(data){
 const bytes=Buffer.from(JSON.stringify(data)), fakeFs={...fs,readFileSync(p,opt){
  const file=path.resolve(String(p));let value;
  if(file===path.join(ROOT,'inputs.json'))value=bytes;
  else if(file===path.join(R,'protocol.json')){const protocol=JSON.parse(fs.readFileSync(file));protocol.inputsSHA256=hash(bytes);value=Buffer.from(JSON.stringify(protocol));}
  else return fs.readFileSync(p,opt);
  return typeof opt==='string'||opt?.encoding?value.toString(typeof opt==='string'?opt:opt.encoding):value;
 },writeFileSync(){throw new Error('Audited source may not write in harness');}};
 const modules={};
 function moduleAt(name){if(modules[name])return modules[name];const file=path.join(R,name),m={exports:{}};
  const req=id=>id==='fs'?fakeFs:id==='./study.cjs'?moduleAt('study.cjs'):require(id);req.main=null;
  new Function('require','module','exports','__filename','__dirname',fs.readFileSync(file,'utf8'))(req,m,m.exports,file,R);
  modules[name]=m.exports;return m.exports;
 }
 return {S:moduleAt('study.cjs'),T:moduleAt('stage2.cjs')};
}
const reference=load(input),rule=reference.T.protocol.lockedRule,mask=[false,true];
const result={passed:true,checks:[],sourceHashes:Object.fromEntries(['inputs.json','risk/study.cjs','risk/stage2.cjs','risk/stage2-protocol.json'].map(p=>[p,hash(fs.readFileSync(path.join(ROOT,p)))]))};
function record(kind,description,details={}){result.checks.push({kind,description,...details});}
// Strict comparison boundaries, absent source, missing warmup, and retained state.
{
 const {S}=load(input),idx=S.featureRows.findIndex(r=>r.date==='2014-06-02'),row=S.featureRows[idx];
 const cases=[
  ['equal MA keeps all-in',{value:100,ma:{200:100},vol:.31},0,1],
  ['equal volatility keeps all-in',{value:99,ma:{200:100},vol:.3},0,1],
  ['strict both thresholds exits',{value:99,ma:{200:100},vol:.3000000001},1,0],
  ['above MA keeps all-in',{value:100.0001,ma:{200:100},vol:.9},0,1],
  ['missing QQQ retains invested',null,1,1],
  ['missing QQQ retains cash',null,0,0],
  ['insufficient MA history retains cash',{value:90,ma:{200:null},vol:.31},0,0],
  ['insufficient vol history retains invested',{value:90,ma:{200:100},vol:null},1,1]
 ];
 for(const [label,p,old,want]of cases){row.proxies[1]=p;assert.equal(S.fractions(rule,idx,[1,old])[1],want);record('boundary',label,{old,want});}
 assert.deepEqual(S.fractions(rule,-1,[1,0]),[1,0]);record('boundary','No previous feature row retains both old targets');
}
// Source observations may be seven calendar days old, never eight; initial missing source defaults full investment.
{
 const d=structuredClone(input);d.proxies['us:QQQ'].series=d.proxies['us:QQQ'].series.filter(r=>r[0]<='2014-06-02');const {S}=load(d);
 const a=S.featureRows.find(r=>r.date==='2014-06-09'),b=S.featureRows.find(r=>r.date==='2014-06-10');
 assert.equal(a.proxies[1].date,'2014-06-02');assert.equal(b.proxies[1],null);
 record('freshness','QQQ last observation exactly seven calendar days old is accepted; eight days is absent',{last:'2014-06-02',accepted:'2014-06-09',absent:'2014-06-10'});
}
{
 const d=structuredClone(input);d.proxies['us:QQQ'].series=[];const {S,T}=load(d),o=T.periods.later35[0];
 assert(S.featureRows.every(r=>r.proxies[1]===null));
 const a=T.account(o,[.3,.3],rule,mask,true),b=T.account(o,[.3,.3],rule,[false,false],true);
 assert.deepEqual(a.curve,b.curve);assert.equal(a.value,b.value);assert.equal(a.trades.filter(t=>t.leg===1).length,1);
 record('missing','Entire QQQ source absent: initial state is all-in and stays all-in, equal to baseline',{warning:'This is a fallback state, not evidence supporting an all-in signal. Product must expose source absence.'});
}
{
 const d=structuredClone(input);d.proxies['us:QQQ'].series=d.proxies['us:QQQ'].series.filter(r=>r[0]>='2013-12-01');const {S}=load(d);
 const p=S.featureRows.find(r=>r.date==='2014-01-02').proxies[1];assert.equal(p.ma[200],null);
 record('missing','Present QQQ close with fewer than 200 observations cannot establish MA200; last target is retained');
}
// Perturb every future target and proxy price independently of old histories. Prefix outcomes must remain bit-for-bit equal.
for(const [start,cutoff]of [['2014-01-02','2014-06-30'],['2015-01-02','2018-12-31'],['2010-12-01','2020-03-31']]){
 const o=input.origins.find(o=>o.start===start);assert(o,start);
 for(const kind of ['target_prices','proxy_prices','all_future_inputs']){
  const d=structuredClone(input);
  if(kind!=='proxy_prices')for(const r of d.daily)if(r[0]>cutoff)r[1]=r[1].map((p,j)=>p*(j?5:3));
  if(kind!=='target_prices')for(const proxy of Object.values(d.proxies))for(const r of proxy.series)if(r[0]>cutoff)r[1]*=7;
  if(kind==='all_future_inputs')for(const r of d.vix)if(r[0]>cutoff){r[1]*=9;r[2]*=.5;}
  const altered=load(d),a=reference.T.account(o,[.3,.3],rule,mask,true),b=altered.T.account(o,[.3,.3],rule,mask,true);
  const keep=rows=>rows.filter(r=>r.day<=cutoff),prefixA=keep(a.curve),prefixB=keep(b.curve);
  assert.deepEqual(prefixA,prefixB);assert.deepEqual(keep(a.trades),keep(b.trades));
  assert.deepEqual(reference.S.featureRows.filter(r=>r.date<=cutoff),altered.S.featureRows.filter(r=>r.date<=cutoff));
  record('future_perturbation','Future input mutation leaves all earlier feature rows, transaction records and account curves exactly unchanged',{start,cutoff,mutation:kind,points:prefixA.length,trades:keep(a.trades).length});
 }
}
// A two-day exact cash ledger tests cost funding and previous-close signal execution through the actual reviewed module.
{
 const d=structuredClone(input),i=d.daily.findIndex((r,i)=>r[0]>='2014-06-01'&&i%5===0),first=i-1;
 d.daily[first][1]=[100,100];d.daily[i][1]=[100,80];const {S,T}=load(d);
 S.featureRows[first-1].proxies[1]={value:100,ma:{200:90},vol:.31,date:d.daily[first-1][0]};
 S.featureRows[first].proxies[1]={value:90,ma:{200:100},vol:.31,date:d.daily[first][0]};
 const o={start:d.daily[first][0],end:d.daily[i][0],years:10},a=T.account(o,[.3,.3],rule,mask,true);
 const buy=30/1.001,sale=buy*.8,saleCash=sale*.999,want=40+buy+saleCash,expectedFees=buy*.001*2+sale*.001;
 assert(Math.abs(a.value-want)<1e-12);assert(Math.abs(a.totalFees-expectedFees)<1e-12);assert.equal(a.trades.length,3);
 assert.equal(a.trades.at(-1).signalDay,d.daily[first][0]);assert.equal(a.trades.at(-1).day,d.daily[i][0]);
 assert.equal(a.permanentCash,40);assert(a.curve.every(r=>r.sleeveCash.every(c=>c>=0)));
 record('fees_and_timing','Each initial 30 budget includes its own fee; later sell fee comes from proceeds; 40 permanent cash untouched; t-1 signal sells at t close',{start:o.start,end:o.end,expectedValue:want,actualValue:a.value,expectedFees,actualFees:a.totalFees,trades:a.trades});
}
result.caveats=[
 'The global common-date i%5 anchor is arbitrary; all five phases need comparison without choosing the best phase.',
 'Same-date QQQ close is available only after its close; the model uses it at the next common ETF close, not on the same day.',
 'Seven-calendar-day stale observations are permitted and can retain stale risk information. An eight-day source gap holds the previous target. At first entry missing data means full allocation, not an evidenced recommendation.',
 'This verifies time indexing of the supplied adjusted-price history. It cannot prove a historical vendor revision or original publication timestamp from data that has no archived as-of snapshots.',
 'TQQQ-only isolation followed inspection of later results, so these are exploratory retrospective results, not an untouched out-of-sample trial.'
];
fs.writeFileSync(path.join(__dirname,'risk-causality-audit.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({passed:result.passed,count:result.checks.length,kinds:result.checks.reduce((a,r)=>(a[r.kind]=(a[r.kind]||0)+1,a),{}),caveats:result.caveats},null,2));
