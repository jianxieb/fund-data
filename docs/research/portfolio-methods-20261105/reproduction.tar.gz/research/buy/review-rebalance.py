"""Read-only third-ledger review of the cash-deficit rule and execution sizing."""
import json,statistics,hashlib
from pathlib import Path
from datetime import date
from collections import defaultdict
P=Path(__file__).resolve().parent;I=json.loads((P.parent/'inputs.json').read_text());rows=I['daily'];dates=[r[0] for r in rows];px=[r[1] for r in rows];index={d:i for i,d in enumerate(dates)}

def run(o,w,mode='fill_price'):
 f=.001;W=sum(w);net=100/(1+f*W);a=index[o['start']];b=index[o['end']]
 q=[net*w[j]/px[a][j] for j in range(2)];cash=net*(1-W);ref=1.;refhigh=1.;peak=100.;mdd=0.;last=-99999;orders=[];maximum_post=0.;exposures=[]
 for t in range(a,b+1):
  if t>a:
   old=px[t-1];now=px[t];oldstocks=sum(q[j]*old[j] for j in range(2));oldvalue=cash+oldstocks;oldexp=oldstocks/oldvalue
   if mode!='hold' and 1-ref/refhigh>=.05 and oldexp<W-1e-10 and t-last>=21:
    marked=old if mode=='signal_price' else now
    stock=sum(q[j]*marked[j] for j in range(2));value=cash+stock
    B=max(0.,min(cash/(1+f),(W*value-stock)/(1+W*f)))
    gaps=[max(0.,w[j]-q[j]*old[j]/oldvalue) for j in range(2)];den=sum(gaps)
    if B>1e-10 and den>0:
     for j in range(2):q[j]+=B*gaps[j]/den/now[j]
     cash-=B*(1+f);last=t
     stock=sum(q[j]*now[j] for j in range(2));actual=stock/(cash+stock);maximum_post=max(maximum_post,actual)
     assert cash>=-1e-9
     orders.append({'day':dates[t],'signal':dates[t-1],'amount':B,'exposure':actual})
   ref*=1-W+sum(w[j]*now[j]/old[j] for j in range(2));refhigh=max(refhigh,ref)
  stocks=sum(q[j]*px[t][j] for j in range(2));value=cash+stocks;peak=max(peak,value);mdd=min(mdd,100*(value/peak-1));exposures.append(stocks/value)
 years=(date.fromisoformat(o['end'])-date.fromisoformat(o['start'])).days/365.2425
 return dict(start=o['start'],value=value,cagr=100*((value/100)**(1/years)-1),mdd=mdd,cash=cash,maxPostBuy=maximum_post,meanExposure=statistics.mean(exposures),orders=orders)

def compare(rs,bs):
 years=defaultdict(list);ds=[]
 for r,b in zip(rs,bs):
  x=r['cagr']-b['cagr'];years[r['start'][:4]].append(x);ds.append(x)
 return dict(yearEqualCAGRpp=statistics.mean(statistics.mean(y) for y in years.values()),wins=sum(x>1e-9 for x in ds),ties=sum(abs(x)<=1e-9 for x in ds),losses=sum(x< -1e-9 for x in ds),maxPostBuy=max(r['maxPostBuy'] for r in rs),medianMDD=statistics.median(r['mdd'] for r in rs),medianBaselineMDD=statistics.median(r['mdd'] for r in bs),meanExposure=statistics.mean(r['meanExposure'] for r in rs),meanBaselineExposure=statistics.mean(r['meanExposure'] for r in bs))
E=json.loads((P.parent/'rebalance/evaluation.json').read_text());selected=next(r for r in E['results'] if r['c']['family']=='buy_only_deficit');records=[];err=0.
for w in [[.3,.3],[.2,.4],[.4,.2],[.5,.5]]:
 for period in ['later35','all15']:
  oo=[o for o in I['origins'] if o['years']==(10 if period=='later35' else 15) and (period=='all15' or '2014'<=o['start']<'2017')]
  a=[run(o,w) for o in oo];b=[run(o,w,'hold') for o in oo];c=[run(o,w,'signal_price') for o in oo]
  saved=selected[period]['rows'] if w==[.3,.3] else next(x for x in selected['weights'] if x['weights']==w)[period]['rows']
  for r,s in zip(a,saved):err=max(err,abs(r['value']-s['value']),abs(r['cagr']-s['annualReturn']),abs(r['mdd']-s['mdd']))
  records.append({'weights':w,'period':period,'existingFillPriceSizingVsLump':compare(a,b),'fixedSignalDayAmountVsLump':compare(c,b),'fixedSignalDayAmountVsExistingSizing':compare(c,a)})
assert err<1e-8
out={'maxIndependentError':err,'method':'Third independent ledger; diagnostic changes only sizing to frozen signal-day dollars, leaving gates/cooldown/fee/initial budgets unchanged. No new strategy selected.','findings':'Current sizing preserves exact60% cap at fill. Frozen prior-day sizing gives executable predetermined dollar budget but post-buy exposure can exceed target due to price moves. Positive advantage is not caused only by fill-price amount sizing.','records':records,'sourceSHA':hashlib.sha256((P.parent/'rebalance/study.cjs').read_bytes()).hexdigest()}
(P/'rebalance-execution-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
