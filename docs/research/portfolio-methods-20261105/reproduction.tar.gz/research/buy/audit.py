import json,math,statistics,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;d=json.loads((p.parent/'inputs.json').read_text());e=json.loads((p/'evaluation.json').read_text())
px=dict(d['daily']);dates=list(px);di={x:i for i,x in enumerate(dates)}
from datetime import date
span=lambda a,b:(date.fromisoformat(b)-date.fromisoformat(a)).days
qqq=d['proxies']['us:QQQ']['series'];qi={x[0]:i for i,x in enumerate(qqq)};qv=[x[1] for x in qqq]
maximum={'value':0,'cagr':0,'mdd':0,'notional':0};plans=accounts=0
for res in e['results']:
 c=res['c']
 for group in res['groups']:
  w=group['weights'];S=sum(w);factor=100/(1+S*.001)
  for r in group['rows']+group['base']:
   q=[0.,0.];cash=100.;peak=100.;mdd=0.;events={}
   for t in r['trades']:events.setdefault(t['date'],[]).append(t)
   for day in dates[di[r['start']]:di[r['end']]+1]:
    for t in events.get(day,[]):
     assert t['signalDate']<day
     q[t['leg']]+=t['notional']/px[day][t['leg']];cash-=t['notional']+t['fee']
     assert abs(t['fee']-t['notional']*.001)<1e-12
    value=cash+sum(a*b for a,b in zip(q,px[day]));peak=max(peak,value);mdd=min(mdd,100*(value/peak-1))
   cagr=100*((value/100)**(365.2425/span(r['start'],r['end']))-1)
   for key,a,b in [('value',value,r['value']),('cagr',cagr,r['annualReturn']),('mdd',mdd,r['mdd'])]:maximum[key]=max(maximum[key],abs(a-b))
   assert abs(cash-factor*(1-S))<1e-8
   for leg in range(2):
    total=sum(t['notional'] for t in r['trades'] if t['leg']==leg)
    maximum['notional']=max(maximum['notional'],abs(total-factor*w[leg]));assert abs(total-factor*w[leg])<1e-8
   accounts+=1
  # Independently reconstruct all selected signals using raw QQQ prices.
  for r in group['rows']:
   start=di[r['start']];signal=start-1;an=qi[dates[signal]];anchor=qv[an]
   sd=statistics.stdev(math.log(qv[k]/qv[k-1]) for k in range(an-20,an+1));got=[]
   if c['family']=='bounded_dip':
    for i in range(start,start+c['maxDays']+1):
     k=qi[dates[i-1]];ret=qv[k]/anchor-1
     if i==start+c['maxDays'] or ret<=-sd or ret>=2*sd:got=[(dates[i],1.)];break
   elif c['family']=='short_rsi':
    for i in range(start,start+c['maxDays']+1):
     k=qi[dates[i-1]];v=[qv[j]-qv[j-1] for j in range(k-2,k+1)];up=sum(max(x,0) for x in v);dn=sum(max(-x,0) for x in v);rsi=100*up/(up+dn) if up+dn else 50
     if i==start+c['maxDays'] or rsi<=10:got=[(dates[i],1.)];break
   else:
    used=.5;got=[(dates[start],.5)]
    for i in range(start+1,start+22):
     k=qi[dates[i-1]];dd=1-qv[k]/anchor;n=sum(dd>=l*.5*sd for l in [1,2,3]);target=1. if i==start+21 else max(used,.5+.5*n/3)
     if target-used>1e-12:got.append((dates[i],target-used))
     used=target
   for leg in range(2):
    actual=[(t['date'],t['notional']/(factor*w[leg])) for t in r['trades'] if t['leg']==leg]
    assert len(actual)==len(got)
    for a,b in zip(actual,got):assert a[0]==b[0] and abs(a[1]-b[1])<1e-12
   plans+=1
assert max(maximum.values())<1e-8
out={'passed':True,'independentLanguage':'Python standard library, raw QQQ and actual ETF CNY closes','accounts':accounts,'independentlyRebuiltSelectedPlans':plans,'maxErrors':maximum,'evaluationSHA':hashlib.sha256((p/'evaluation.json').read_bytes()).hexdigest()}
(p/'independent-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
