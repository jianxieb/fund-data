import json,math,hashlib
from collections import defaultdict
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parent/'risk';source=(P/'risk-independent-audit.py').read_text().split('records=[];')[0]
source=source.replace('def run(o,w,hold=False,trace=False):','def run(o,w,hold=False,trace=False,phase=0):').replace('i%5==0','i%5==phase')
ns={'__file__':str(P/'risk-independent-audit.py')};exec(source,ns);run,D,di=ns['run'],ns['D'],ns['di']
E=json.loads((R/'phase-episode-attribution.json').read_text());o=E['origin'];records=[]
for phase in range(5):
 r=run(o,[.3,.3],trace=True,phase=phase);b=run(o,[.3,.3],hold=True,trace=True);sell=None;episodes=[]
 for t in [t for t in r['trades'] if t['leg']==1]:
  if t['side']=='sell':sell=t
  elif sell:
   before=D[di[sell['day']]][1][1];after=D[di[t['day']]][1][1]
   episodes.append({'sellDay':sell['day'],'sellSignal':sell['signalDay'],'buyDay':t['day'],'buySignal':t['signalDay'],'assetReturnWhileOutPct':100*(after/before-1),'relativeWealthFactor':.999/1.001*before/after});sell=None
 assert sell is None,'Example ends invested, expected all closed episodes'
 factor=math.prod(e['relativeWealthFactor'] for e in episodes);actual=r['curve'][-1]['units'][1]/b['curve'][-1]['units'][1]
 assert abs(factor-actual)<1e-12
 old=next(x for x in E['results'] if x['phase']==phase)
 assert abs(factor-old['verifiedEpisodeProduct'])<1e-12
 assert len(episodes)==len(old['episodes'])
 for a,c in zip(episodes,old['episodes']):
  for key in ['sellDay','sellSignal','buyDay','buySignal']:assert a[key]==c[key]
  for key in ['assetReturnWhileOutPct','relativeWealthFactor']:assert abs(a[key]-c[key])<1e-12
 yy=defaultdict(list)
 for e in episodes:yy[e['sellDay'][:4]].append(e['relativeWealthFactor'])
 records.append({'phase':phase,'start':o['start'],'end':o['end'],'portfolioCAGR':r['annualReturn'],'baselineCAGR':b['annualReturn'],'cagrDifferencePP':r['annualReturn']-b['annualReturn'],'tqqqTerminalRelativeFactor':factor,'episodeCount':len(episodes),'profitableEpisodes':sum(e['relativeWealthFactor']>1 for e in episodes),'lossEpisodes':sum(e['relativeWealthFactor']<1 for e in episodes),'factorsByExitYear':{y:math.prod(f) for y,f in yy.items()},'episodes':episodes})
out={'passed':True,'originChosen':'Earliest later origin already used in source, without outcome selection','records':records,'interpretation':'Relative factors multiply in the TQQQ sleeve; they are not additive whole-portfolio percentage-point contributions. Calendar grouping uses exit year. Origins overlap heavily and reuse the same episodes.','sourceHashes':{str(p.relative_to(P.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [P.parent/'inputs.json',R/'phase-episode-attribution.json',P/'risk-independent-audit.py',P/'risk-episodes-independent-audit.py']}}
(P/'risk-episodes-independent-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k!='episodes'} for r in records],indent=2))
