"use strict";
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const ROOT=path.resolve(process.env.FUND_DATA_ROOT||process.argv[2]||process.cwd());
const E=require('./engine.cjs'),V=require('./volatility/policies.cjs'),H=require('./hybrid/study.cjs'),R=require('./rotation/ensemble/policy.cjs');
const P=require(path.join(ROOT,'assets/portfolio-model.js'));
const sha=p=>E.hash(fs.readFileSync(p)),json=p=>JSON.parse(fs.readFileSync(p));
const sources={},read=relative=>{const p=path.join(ROOT,relative);sources[relative]=sha(p);return json(p);};
for(const file of ['assets/portfolio-model.js','assets/portfolio-systematic.js','assets/model.js','data/portfolio/catalog.js'])sources[file]=sha(path.join(ROOT,file));
const text=fs.readFileSync(path.join(ROOT,'data/portfolio/catalog.js'),'utf8'),allCatalog=JSON.parse(text.slice(text.indexOf('=')+1).trim().replace(/;$/,''));
const files={'us:USD':'data/portfolio/us/USD-b2e099b598f25d1d.json','us:TQQQ':'data/portfolio/us/TQQQ-235126570a4b63be.json','us:QQQ':'data/portfolio/us/QQQ-2d88370080c88a85.json'};
const histories=Object.fromEntries(Object.entries(files).map(([id,f])=>[id,read(f)]));
const fxFile='data/portfolio/fx/CNY-5f1b9958db2b35db.json',fxHistory=read(fxFile),marketContext=read('data/portfolio/entry-context.json');
const assets=Object.entries(files).map(([id,f])=>({...allCatalog.assets.find(a=>a.id===id),historyUrl:f,sha256:sources[f],first:histories[id].first,asOf:histories[id].asOf}));
const catalog={...allCatalog,assets,fx:{...allCatalog.fx,historyUrl:fxFile,sha256:sources[fxFile],first:fxHistory.first,asOf:fxHistory.asOf}};
let pricesChecked=0;
for(const [day,prices]of E.input.daily){for(let k=0;k<2;k++)assert.equal(prices[k],P.at(histories[['us:USD','us:TQQQ'][k]].series,day).value*P.at(fxHistory.series,day,7).value);pricesChecked++;}
for(const id of ['us:USD','us:TQQQ'])assert.deepEqual(histories[id].dividendEvidence.fractions,E.taxInput[id].dividendEvidence.fractions);
const contextMap=new Map(marketContext.series.map(r=>[r[0],r]));for(const row of E.input.vix)assert.deepEqual(row,contextMap.get(row[0]));
const qqqMap=new Map(histories['us:QQQ'].series);for(const row of E.input.proxies['us:QQQ'].series)assert.equal(row[1],qqqMap.get(row[0]));
const vixCandidate=json(path.join(__dirname,'volatility/selection.json')).selected.find(r=>r.c.family==='fear_reversal').c;
const methods=[['vix_panic_reentry',V.makeFactory(vixCandidate,E.sleeveTargetOrders),[0,.2]],['dual_risk_guard',H.factory('hybrid'),[.2]],['relative_strength_rotation',R.ensembleFactory(E.stockMixOrders,0),[0,.2]]];
const counters={accounts:0,fills:0,commonValuations:0,maxValueError:0,maxCommonMddError:0,maxFullCalendarMddDifference:0,maxPaidTaxError:0,maxFillError:0},results=[];
const close=(a,b,label,tol=1e-7)=>{const error=Math.abs(a-b);assert(error<=tol,`${label}: ${a} != ${b}`);return error;};
const origins=E.periods.all10_81.concat(E.periods.all15_21),one=process.argv.includes('--one'),startTime=performance.now();
outer:for(const [method,factory,taxes]of methods)for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const fee of [.001,.005])for(const tax of taxes){
 for(const o of origins){
  const config={positions:['us:USD','us:TQQQ'].map((id,k)=>({id,weight:weights[k]*100})),currency:'CNY',initial:100,monthly:0,rebalance:'none',transactionFee:fee*100,feeBasis:'net',years:'custom',start:o.start,end:o.end,initialMethod:method,contributionMethod:'dca_month',tax:{usCapitalGains:tax*100,usDividend:tax*100,liquidate:false}};
  const a=P.simulate({catalog,histories,fxHistory,marketContext,config});assert(!a.error,method+' '+o.start+': '+a.error);
  const b=E.account(o,weights,factory,{fee,tax,dividendTax:tax,delay:0,trace:true});
  const error=close(a.value,b.value,'value'),paidTaxError=close(a.capitalTax+a.dividendTax,b.paidTax,'paid tax');
  close(a.annualReturn,b.annualReturn,'annual');close(a.tradeCost,b.fees,'fees');close(a.taxReserve,b.reserve,'reserve');close(a.cash,b.finalCash,'cash');
  const byDay=new Map(a.curve.map(row=>[row.day,row]));let peak=100,commonMDD=0;
  for(const r of b.curve){const s=byDay.get(r.day);assert(s);close(s.value,r.value,'common date value');peak=Math.max(peak,s.value);commonMDD=Math.min(commonMDD,100*(s.value/peak-1));counters.commonValuations++;}
  const riskError=close(commonMDD,b.mdd,'common-date mdd');
  const key=t=>[t.day,t.signalDay||'',t.id||['us:USD','us:TQQQ'][t.leg],t.side].join('|');
  const bt=b.trades.slice().sort((x,y)=>key(x).localeCompare(key(y))),at=a.transactions.slice().sort((x,y)=>key(x).localeCompare(key(y)));
  assert.equal(at.length,bt.length,'transaction count');
  for(let i=0;i<bt.length;i++){assert.equal(key(at[i]),key(bt[i]),'trade date or identity');for(const f of ['amount','fee','tax'])counters.maxFillError=Math.max(counters.maxFillError,close(at[i][f],bt[i][f],'fill '+f));}
  counters.accounts++;counters.fills+=at.length;counters.maxValueError=Math.max(counters.maxValueError,error);counters.maxCommonMddError=Math.max(counters.maxCommonMddError,riskError);counters.maxPaidTaxError=Math.max(counters.maxPaidTaxError,paidTaxError);counters.maxFullCalendarMddDifference=Math.max(counters.maxFullCalendarMddDifference,Math.abs(a.mdd-b.mdd));
  results.push({method,weights,fee,tax,years:o.years,start:o.start,end:o.end,value:a.value,referenceValue:b.value,annualReturn:a.annualReturn,commonMDD,fullCalendarMDD:a.mdd,referenceCommonMDD:b.mdd,paidTax:a.capitalTax+a.dividendTax,taxReserve:a.taxReserve,tradeCost:a.tradeCost,trades:at.length,valueError:error});
  if(one)break outer;
 }
 console.log(JSON.stringify({progress:counters.accounts,method,weights,fee,tax,elapsedSeconds:(performance.now()-startTime)/1000}));
}
for(const [file,h]of Object.entries(sources))assert.equal(sha(path.join(ROOT,file)),h,'source changed during audit '+file);
const out={status:'pass',scope:'Actual production core versus frozen research: genuine native USD/TQQQ/QQQ adjusted-price snapshots and CNY FX, 4207 common quote dates reconstructed exactly. VIX source identity retained. Zero monthly funding/rebalance; production next-common-close delay0. VIX/rotation taxes0/20%, hybrid20% only. Full native union-calendar risk is explicitly separate from frozen common-date research risk.',sources,researchInputsSHA256:sha(path.join(__dirname,'inputs.json')),auditScriptSHA256:sha(__filename),engineSHA256:sha(path.join(__dirname,'engine.cjs')),pricesChecked,counters,elapsedSeconds:(performance.now()-startTime)/1000,results};
fs.writeFileSync(path.join(__dirname,one?'production-core-one.json':'production-core-audit.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({...out,results:results.length,sources:Object.keys(sources).length}));
