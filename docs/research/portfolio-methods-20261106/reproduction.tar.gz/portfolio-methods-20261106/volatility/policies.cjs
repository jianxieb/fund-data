'use strict';

// Inputs are immutable adjusted-price observations. All state transitions below
// advance once per source observation, never once per requesting account day.
const featureCache = new WeakMap();
const targetCache = new WeakMap();
const calendarGap = (a,b) => (Date.parse(a)-Date.parse(b))/86400000;
function latest(rows, day, strict=false) {
  let lo=0,hi=rows.length;
  while(lo<hi) {const m=(lo+hi)>>1; if(rows[m].day<day||(!strict&&rows[m].day===day))lo=m+1;else hi=m;}
  return lo ? rows[lo-1] : null;
}
function volatility(x) {
  if(x.length<2)return null;
  const mean=x.reduce((a,b)=>a+b,0)/x.length;
  return Math.sqrt(x.reduce((a,b)=>a+(b-mean)**2,0)/(x.length-1)*252);
}
function proxyFeatures(series) {
  const returns=[],out=[];
  for(let i=0;i<series.length;i++) {
    if(i)returns.push(Math.log(series[i][1]/series[i-1][1]));
    const r21=returns.slice(-21),r126=returns.slice(-126);
    const sq=r21.reduce((a,b)=>a+b*b,0),down=r21.reduce((a,b)=>a+Math.min(b,0)**2,0);
    out.push({day:series[i][0],rv21:r21.length===21?volatility(r21):null,
      rv126:r126.length===126?volatility(r126):null,
      downsideFraction21:r21.length===21?(sq?down/sq:.5):null});
  }
  return out;
}
function features(input) {
  if(featureCache.has(input))return featureCache.get(input);
  const f={
    qqq:proxyFeatures(input.proxies['us:QQQ'].series),
    soxx:proxyFeatures(input.proxies['us:SOXX'].series),
    vix:input.vix.filter(x=>x[1]>0&&x[2]>0).map(x=>({day:x[0],vix:x[1],ratio:x[1]/x[2]}))
  };
  featureCache.set(input,f);return f;
}
function proxyStates(rows,c) {
  let on=true,exitCount=0,enterCount=0;
  return rows.map(f=>{
    const valid=c.family==='vol_expansion'?f.rv21!==null&&f.rv126!==null:f.rv21!==null&&f.downsideFraction21!==null;
    if(valid) {
      const stressed=c.family==='vol_expansion'
        ? f.rv21>f.rv126*c.ratio&&f.rv21>c.absoluteFloor
        : f.downsideFraction21>c.asym&&f.rv21>c.vol;
      const calm=c.family==='vol_expansion'
        ? f.rv21<f.rv126*c.reentryRelative
        : f.downsideFraction21<c.reentryAsym||f.rv21<c.reentryVol;
      if(on) {
        exitCount=stressed?exitCount+1:0;enterCount=0;
        if(exitCount>=c.confirm){on=false;exitCount=0;}
      } else {
        enterCount=calm?enterCount+1:0;exitCount=0;
        if(enterCount>=c.reentryConfirm){on=true;enterCount=0;}
      }
    }
    return {...f,target:on?1:c.off};
  });
}
function fearStates(rows,c) {
  let on=true,armed=true,exitCount=0,calmCount=0,held=0,peak=0;
  return rows.map(f=>{
    const calm=f.ratio<c.normalRatio;
    calmCount=calm?calmCount+1:0;
    if(on) {
      if(!armed&&calmCount>=c.normalConfirm)armed=true;
      exitCount=armed&&f.ratio>c.ratio?exitCount+1:0;
      if(exitCount>=c.confirm) {on=false;exitCount=0;calmCount=0;held=0;peak=f.vix;}
    } else {
      held++;peak=Math.max(peak,f.vix);
      if((held>=c.minHold&&f.vix<=peak*(1-c.peakDrop))||calmCount>=c.normalConfirm) {
        on=true;armed=false;exitCount=0;calmCount=0;held=0;
      }
    }
    return {...f,target:on?1:c.off,armed,held,peak};
  });
}
function targets(input,c) {
  let cache=targetCache.get(input);if(!cache){cache=new Map();targetCache.set(input,cache);}
  if(cache.has(c.id))return cache.get(c.id);
  const f=features(input);
  const t=c.family==='fear_reversal'?{vix:fearStates(f.vix,c)}:{qqq:proxyStates(f.qqq,c),soxx:proxyStates(f.soxx,c)};
  cache.set(c.id,t);return t;
}
function makeFactory(c,sleeveTargetOrders) {
  return ({input})=>{
    const state=targets(input,c);
    let requested=[1,1];
    return {step(ctx) {
      const next=requested.slice();
      for(let leg=0;leg<2;leg++) {
        if(leg===0&&c.mask==='tqqq')continue;
        const f=c.family==='fear_reversal'?latest(state.vix,ctx.day,true):latest(leg===0?state.soxx:state.qqq,ctx.day);
        if(f&&calendarGap(ctx.day,f.day)<=7)next[leg]=f.target;
      }
      if(next.every((v,i)=>v===requested[i]))return null;
      const changed=next.map((v,i)=>v!==requested[i]);
      requested=next;
      const order=sleeveTargetOrders(ctx,next);
      for(let leg=0;leg<2;leg++)if(!changed[leg]){order.sellFractions[leg]=0;order.buyAmounts[leg]=0;}
      return {...order,signalMetadata:{candidate:c.id,targets:next}};
    }};
  };
}
module.exports={latest,volatility,proxyFeatures,proxyStates,fearStates,features,targets,makeFactory};
