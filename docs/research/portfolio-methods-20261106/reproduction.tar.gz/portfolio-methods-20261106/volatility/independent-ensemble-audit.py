"""One real tax account holding the arithmetic mean of 27 risk states.
Independent Python accounting and raw VIX automata; no JS imports.
"""
from pathlib import Path
from datetime import date
from statistics import mean
import json, math, hashlib
ROOT=Path(__file__).resolve().parent
read=lambda f:json.loads((ROOT/f).read_text())
D=read('../inputs.json');T=read('../tax-inputs.json');P=read('ensemble-protocol.json');R=read('ensemble-evaluation.json')
days=[r[0] for r in D['daily']];px=[r[1] for r in D['daily']];ix={d:i for i,d in enumerate(days)};od=[date.fromisoformat(d).toordinal() for d in days]
div=[[T[k]['dividendEvidence']['fractions'].get(d,0) for d in days] for k in ['us:USD','us:TQQQ']]
vix=[r for r in D['vix'] if r[1]>0 and r[2]>0]
members=[]
for c in P['parameters']:
    on=armed=True;stress=normal=held=0;peak=0.;states=[]
    for day,v,three in vix:
        ratio=v/three;normal=normal+1 if ratio<c['normalRatio'] else 0
        if on:
            if not armed and normal>=c['normalConfirm']:armed=True
            stress=stress+1 if armed and ratio>c['ratio'] else 0
            if stress>=c['confirm']:on=False;stress=normal=held=0;peak=v
        else:
            held+=1;peak=max(peak,v)
            if (held>=c['minHold'] and v<=peak*(1-c['peakDrop'])) or normal>=c['normalConfirm']:
                on=True;armed=False;stress=normal=held=0
        states.append(1 if on else c['off'])
    members.append(states)
combined=[sum(member[j] for member in members)/len(members) for j in range(len(vix))]
targets=[];j=-1;target=1.
for day,ordinal in zip(days,od):
    while j+1<len(vix) and vix[j+1][0]<day:j+=1
    if j>=0 and ordinal-date.fromisoformat(vix[j][0]).toordinal()<=7:target=combined[j]
    targets.append(target)

def run(start,end,w,fee,tax,delay,active):
    first,last=ix[start],ix[end];u=[0.,0.];b=[0.,0.];cash=100.;leg=0.;initialcash=0.
    fees=capital=divtax=0.;peak=100.;mdd=0.;stockmax=levmax=stocksum=0.;previous=None;rets=[];trades=plans=caps=0;pending=None;requested=1.
    for i in range(first,last+1):
        prices=px[i]
        if i>first:
            for k in (0,1):
                grossdiv=u[k]*prices[k]*div[k][i];withheld=grossdiv*tax
                u[k]-=withheld/prices[k];b[k]+=grossdiv-withheld;divtax+=withheld
        before=[u[k]*prices[k] for k in (0,1)];prewealth=cash+sum(before)
        if prewealth>0:stockmax=max(stockmax,sum(before)/prewealth);levmax=max(levmax,(2*before[0]+3*before[1])/prewealth)
        if i==first:
            for k in (0,1):
                amount=100*w[k]/(1+fee*sum(w));cost=amount*fee
                u[k]=amount/prices[k];b[k]=amount+cost;cash-=amount+cost;fees+=cost;trades+=1
            initialcash=cash
        if pending and pending[0]==i:
            _,side,size=pending;pending=None
            if side=='sell':
                qty=min(u[1],size);caps+=qty<size-1e-10;amount=qty*prices[1];cost=amount*fee
                basispart=b[1]*qty/u[1] if u[1]>0 else 0.;paid=max(0,amount-cost-basispart)*tax
                u[1]-=qty;b[1]-=basispart;net=amount-cost-paid;cash+=net;leg+=net;capital+=paid
                if u[1]<1e-10:u[1]=b[1]=0.
            else:
                amount=size;cost=amount*fee;u[1]+=amount/prices[1];b[1]+=amount+cost;cash-=amount+cost;leg-=amount+cost
            fees+=cost;trades+=1
        if -1e-7<cash<0:cash=0.
        marks=[u[k]*prices[k] for k in (0,1)];gross=cash+sum(marks);reserve=sum(max(0,marks[k]*(1-fee)-b[k])*tax for k in (0,1));value=gross-reserve
        peak=max(peak,value);mdd=min(mdd,100*(value/peak-1));fraction=sum(marks)/gross;stocksum+=fraction;stockmax=max(stockmax,fraction);levmax=max(levmax,(2*marks[0]+3*marks[1])/gross)
        if previous is not None:rets.append(value/previous-1)
        previous=value
        if active and not pending and targets[i]!=requested:
            requested=targets[i];pool=max(0,leg);desired=requested*(pool+marks[1])
            if marks[1]>desired+1e-10:
                qty=u[1]*(marks[1]-desired)/marks[1]
                if qty/u[1]>1e-10:pending=(i+1+delay,'sell',qty);plans+=1
            elif desired>marks[1]+1e-10:
                amount=min(pool/(1+fee),(desired-marks[1])/(1+requested*fee))
                if amount>1e-10:pending=(i+1+delay,'buy',amount);plans+=1
    years=(od[last]-od[first])/365.2425;rets.sort();n=max(1,math.ceil(len(rets)*.05))
    return dict(value=value,grossValue=gross,annualReturn=100*((value/100)**(1/years)-1),mdd=mdd,fees=fees,capitalTax=capital,paidDividendTax=divtax,paidTax=capital+divtax,reserve=reserve,finalCash=cash,initialCash=initialcash,tradeCount=trades,planCount=plans,maxStockFraction=stockmax,meanStockFraction=stocksum/(last-first+1),maxDailyLeverageExposure=levmax,cvar95=100*mean(rets[:n]),inventoryCapCount=caps)

cache={};errors={};pairs=rows=0
for group in R['results']:
    for active,key in [(True,'rows'),(False,'baseline')]:
        for expected in group[key]:
            args=(expected['start'],expected['end'],tuple(group['weights']),group['fee'],group['tax'],group['delay'] if active else 0,active)
            if args not in cache:cache[args]=run(*args)
            for metric,value in cache[args].items():
                delta=abs(value-expected[metric]);errors[metric]=max(errors.get(metric,0),delta)
                assert delta<1e-7,(args,metric,value,expected[metric],delta)
            rows+=1
    pairs+=len(group['rows'])
out={'passed':True,'candidate':P['id'],'method':'Independent raw VIX27 automata arithmetic exposure; single actual TQQQ tax basis and cash sleeve, fixed prior-close units/notional ledger. No average of independent-account returns.','groups':len(R['results']),'pairedRows':pairs,'accountRows':rows,'uniqueAccounts':len(cache),'maxErrors':errors,'sourceStates':len(combined),'sourceStateTransitions':sum(combined[i]!=combined[i-1] for i in range(1,len(combined))),'sources':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['independent-ensemble-audit.py','ensemble-protocol.json','ensemble-evaluation.json','../inputs.json','../tax-inputs.json']}}
(ROOT/'independent-ensemble-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
