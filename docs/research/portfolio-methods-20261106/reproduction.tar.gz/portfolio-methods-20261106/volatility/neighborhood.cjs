'use strict';
const fs=require('fs'),assert=require('assert/strict'),E=require('../engine.cjs'),P=require('./policies.cjs');
const protocol=JSON.parse(fs.readFileSync('neighborhood-protocol.json'));
assert(!fs.existsSync('neighborhood.json'));
const results=[];
for(const c of protocol.grid)for(const weights of protocol.weights)for(const label of protocol.periods)results.push({c,weights,label,...E.evaluate(E.periods[label],weights,P.makeFactory(c,E.sleeveTargetOrders),{tax:protocol.tax,fee:protocol.fee,delay:protocol.delay})});
const cells=results.map(({c,weights,label,summary})=>({c,weights,label,summary}));
const overview=[];
for(const weights of protocol.weights)for(const label of protocol.periods){
 const group=cells.filter(r=>r.weights.every((x,i)=>x===weights[i])&&r.label===label);
 const center=group.find(r=>r.c.ratio===protocol.center.ratio&&r.c.confirm===protocol.center.confirm&&r.c.peakDrop===protocol.center.peakDrop);
 const values=group.map(r=>r.summary.yearEqualCAGRpp);
 overview.push({weights,label,n:values.length,positive:values.filter(x=>x>1e-9).length,zero:values.filter(x=>Math.abs(x)<=1e-9).length,negative:values.filter(x=>x< -1e-9).length,min:Math.min(...values),median:E.median(values),max:Math.max(...values),center: center.summary.yearEqualCAGRpp});
}
const provenance=Object.fromEntries(['neighborhood-protocol.json','neighborhood.cjs','policies.cjs','../engine.cjs'].map(f=>[f,E.hash(fs.readFileSync(f))]));
fs.writeFileSync('neighborhood.json',JSON.stringify({provenance,overview,results})+'\n');
fs.writeFileSync('neighborhood-summary.json',JSON.stringify({provenance,overview,cells},null,2)+'\n');
console.log(JSON.stringify(overview,null,2));
