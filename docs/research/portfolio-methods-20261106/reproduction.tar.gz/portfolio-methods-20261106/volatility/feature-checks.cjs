'use strict';
const fs=require('fs'),crypto=require('crypto'),assert=require('assert/strict');
const p=require('./policies.cjs');
const input=JSON.parse(fs.readFileSync('../inputs.json'));
const protocol=JSON.parse(fs.readFileSync('./protocol.json'));
const checks=[];
assert.ok(Math.abs(p.volatility([-.1,.1])-Math.sqrt(.02*252))<1e-14);
checks.push('sample rather than population standard deviation, annualized sqrt252');
const c=protocol.candidates.find(c=>c.family==='vol_expansion');
const valid={rv21:.5,rv126:.5/c.ratio,downsideFraction21:.8};
const equal=Array.from({length:30},(_,i)=>({day:`x${i}`,...valid}));
assert.ok(p.proxyStates(equal,c).every(x=>x.target===1));
checks.push('relative volatility stress uses strict greater-than at threshold');
const stressed=Array.from({length:c.confirm+1},(_,i)=>({day:`x${i}`,rv21:.51,rv126:.3,downsideFraction21:.8}));
const st=p.proxyStates(stressed,c);
assert.equal(st[c.confirm-2].target,1);assert.equal(st[c.confirm-1].target,c.off);
checks.push('exit occurs on exact Nth distinct stress observation');
const fc={...protocol.candidates.find(c=>c.family==='fear_reversal'),ratio:1,confirm:3,peakDrop:.2,off:0};
const rows=Array.from({length:3},(_,i)=>({day:`a${i}`,vix:100,ratio:1.2}));
rows.push(...Array.from({length:4},(_,i)=>({day:`b${i}`,vix:100,ratio:1.2})),{day:'b4',vix:80,ratio:1.2});
rows.push(...Array.from({length:20},(_,i)=>({day:`c${i}`,vix:80,ratio:1.2})));
const fear=p.fearStates(rows,fc);
assert.equal(fear[2].target,0);assert.equal(fear[6].target,0);assert.equal(fear[7].target,1);
assert.ok(fear.slice(7).every(x=>x.target===1&&!x.armed));
checks.push('fear recovery includes exact 20% VIX peak decline after five observations; inverted declining-volatility recovery cannot immediately re-trigger exit');
const dates=[{day:'2020-03-02'},{day:'2020-03-03'}];
assert.equal(p.latest(dates,'2020-03-03',true).day,'2020-03-02');
assert.equal(p.latest(dates,'2020-03-03').day,'2020-03-03');
checks.push('VIX strict previous date differs from proxy inclusive current known close');
for(const cutoff of ['2011-12-30','2020-03-20','2022-06-01','2023-02-01']) {
 const changed=JSON.parse(JSON.stringify(input));
 for(const proxy of Object.values(changed.proxies))for(let i=0;i<proxy.series.length;i++)if(proxy.series[i][0]>cutoff)proxy.series[i][1]*=1+(i%7)*.17;
 for(let i=0;i<changed.vix.length;i++)if(changed.vix[i][0]>cutoff){changed.vix[i][1]*=4;changed.vix[i][2]*=.7;}
 for(const cand of protocol.candidates) {
  const a=p.targets(input,cand),b=p.targets(changed,cand);
  for(const key of Object.keys(a))assert.deepEqual(a[key].filter(x=>x.day<=cutoff),b[key].filter(x=>x.day<=cutoff));
 }
 checks.push(`all72 state histories unchanged by future proxy/VIX perturbation after ${cutoff}`);
}
const feature=p.features(input);
const output={passed:true,checks,coverage:Object.fromEntries(Object.entries(feature).map(([k,v])=>[k,{first:v[0].day,last:v.at(-1).day,n:v.length,firstValid21:v.find(x=>Number.isFinite(x.rv21))?.day,firstValid126:v.find(x=>Number.isFinite(x.rv126))?.day}])),sources:Object.fromEntries(['../inputs.json','protocol.json','policies.cjs'].map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')]))};
fs.writeFileSync('feature-checks.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output,null,2));
