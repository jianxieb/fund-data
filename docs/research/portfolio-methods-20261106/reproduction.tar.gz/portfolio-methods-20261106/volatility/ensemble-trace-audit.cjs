'use strict';
const fs=require('fs'),assert=require('assert/strict'),E=require('../engine.cjs'),S=require('./ensemble.cjs');
const traces=[],checks=[];
for(const weights of [[.3,.3],[.5,.5]])for(const delay of [0,1])for(const origin of [E.periods.later35[0],E.periods.all15_21[0]]) {
 const a=E.account(origin,weights,S.factory,{fee:.001,tax:.2,delay,trace:true});
 for(const v of a.curve) {
  assert.ok(v.cash>=a.initialCash-1e-7&&v.cashByLeg.every(x=>x>=-1e-7));
  assert.ok(Math.abs(v.cash-a.initialCash-E.sum(v.cashByLeg))<1e-7);
 }
 for(const plan of a.plans) {
  const snapshot=a.curve.find(x=>x.day===plan.signalDay);
  assert.equal(plan.sellFractions[0],0);assert.equal(plan.buyAmounts[0],0);
  assert.ok(plan.buyAmounts[1]*(1+.001)<=snapshot.cashByLeg[1]+1e-7);
  assert.ok(Math.abs(plan.sellUnits[1]-snapshot.units[1]*plan.sellFractions[1])<1e-9);
 }
 for(const trade of a.trades.filter(x=>x.reason!=='initial')) {
  const plan=a.plans.find(x=>x.signalDay===trade.signalDay);
  assert.equal(trade.day,plan.dueDay);assert.equal(trade.leg,1);
  if(trade.side==='buy')assert.equal(trade.amount,plan.buyAmounts[1]);
  else assert.ok(trade.units<=plan.sellUnits[1]+1e-10);
 }
 traces.push({weights,delay,origin:{start:origin.start,end:origin.end,years:origin.years},account:a});
}
for(const cutoff of ['2015-09-01','2020-03-20','2022-06-01']) {
 const changed=JSON.parse(JSON.stringify(E.input));
 for(const [day,p] of changed.daily)if(day>cutoff){p[0]*=1.8;p[1]*=.2;}
 for(const r of changed.vix)if(r[0]>cutoff){r[1]*=4;r[2]*=.2;}
 const origin=E.periods.later35[0];
 const a=E.account(origin,[.3,.3],S.factory,{fee:.001,tax:.2,delay:0,trace:true});
 const b=E.account(origin,[.3,.3],S.factory,{fee:.001,tax:.2,delay:0,trace:true,env:E.environment(changed)});
 for(const key of ['trades','curve'])assert.deepEqual(a[key].filter(x=>x.day<=cutoff),b[key].filter(x=>x.day<=cutoff));
 assert.deepEqual(a.plans.filter(x=>x.signalDay<=cutoff),b.plans.filter(x=>x.signalDay<=cutoff));
 checks.push({check:'future ETF and VIX prices preserve historical plans/trades/cash/taxes/wealth',cutoff});
}
let previous=1;const transitions=[];
for(const s of S.ensembleStates(E.input))if(s.target!==previous){transitions.push(s);previous=s.target;}
const transitionCountsByYear={};for(const t of transitions)transitionCountsByYear[t.day.slice(0,4)]=(transitionCountsByYear[t.day.slice(0,4)]||0)+1;
fs.writeFileSync('ensemble-traces.json',JSON.stringify({transitions,transitionCountsByYear,traces})+'\n');
const out={passed:true,traceAccounts:traces.length,plans:traces.reduce((s,t)=>s+t.account.plans.length,0),checks,transitionCountsByYear,sourceTransitions:transitions.length,provenance:Object.fromEntries(['ensemble-trace-audit.cjs','ensemble.cjs','ensemble-protocol.json','../engine.cjs'].map(f=>[f,E.hash(fs.readFileSync(f))]))};
fs.writeFileSync('ensemble-trace-audit.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
