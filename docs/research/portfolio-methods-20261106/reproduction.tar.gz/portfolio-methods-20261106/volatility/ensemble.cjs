'use strict';
const fs=require('fs'),assert=require('assert/strict'),E=require('../engine.cjs'),P=require('./policies.cjs');
const protocol=JSON.parse(fs.readFileSync(__dirname+'/ensemble-protocol.json'));
const cache=new WeakMap();
function ensembleStates(input) {
 if(cache.has(input))return cache.get(input);
 const members=protocol.parameters.map(c=>P.targets(input,c).vix);
 const states=members[0].map((r,i)=>{
  assert(members.every(m=>m[i].day===r.day));
  return {day:r.day,target:members.reduce((sum,m)=>sum+m[i].target,0)/members.length};
 });
 cache.set(input,states);return states;
}
function factory({input}) {
 const states=ensembleStates(input);let target=1;
 return {step(ctx){
  const observed=P.latest(states,ctx.day,true);
  if(!observed||(Date.parse(ctx.day)-Date.parse(observed.day))/86400000>7||observed.target===target)return null;
  target=observed.target;
  const orders=E.sleeveTargetOrders(ctx,[1,target]);orders.sellFractions[0]=orders.buyAmounts[0]=0;
  return {...orders,reason:protocol.id};
 }};
}
function provenance(){return Object.fromEntries(['ensemble-protocol.json','ensemble.cjs','policies.cjs','../engine.cjs','../inputs.json','../tax-inputs.json'].map(f=>[f,E.hash(fs.readFileSync(__dirname+'/'+f))]));}
function develop(){
 assert(!fs.existsSync('ensemble-development.json')&&!fs.existsSync('ensemble-lock.json'));
 const result=E.evaluate(E.periods.development28,[.3,.3],factory,{fee:.001,tax:.2,delay:0});
 const doc={provenance:provenance(),candidate:protocol.id,...result};fs.writeFileSync('ensemble-development.json',JSON.stringify(doc)+'\n');
 fs.writeFileSync('ensemble-lock.json',JSON.stringify({lockedUTC:new Date().toISOString(),candidate:protocol.id,selection:'Sole fixed candidate, no search or parameter replacement.',developmentSummary:result.summary,developmentSHA256:E.hash(fs.readFileSync('ensemble-development.json')),provenance:provenance()},null,2)+'\n');
 console.log(JSON.stringify(result.summary,null,2));
}
function evaluate(){
 assert(fs.existsSync('ensemble-lock.json')&&!fs.existsSync('ensemble-evaluation.json'));
 const centers=JSON.parse(fs.readFileSync('evaluation.json')).results.filter(r=>r.c.family==='fear_reversal');
 const results=[];
 for(const weights of protocol.evaluation.weights)for(const tax of protocol.evaluation.taxes)for(const fee of protocol.evaluation.fees)for(const delay of protocol.evaluation.delays)for(const label of protocol.evaluation.periods){
  const result=E.evaluate(E.periods[label],weights,factory,{fee,tax,delay});
  const center=centers.find(r=>r.weights.every((w,i)=>w===weights[i])&&r.tax===tax&&r.fee===fee&&r.delay===delay&&r.label===label);assert(center);
  results.push({id:protocol.id,weights,tax,fee,delay,label,...result,versusCenter:E.compare(result.rows,center.rows),centerRows:center.rows});
 }
 fs.writeFileSync('ensemble-evaluation.json',JSON.stringify({provenance:provenance(),lockSHA256:E.hash(fs.readFileSync('ensemble-lock.json')),results})+'\n');
 const main=results.filter(r=>r.tax===.2&&r.fee===.001&&r.delay===0).map(({rows,baseline,centerRows,...r})=>r);
 const summary={provenance:provenance(),main,signs:{positive:results.filter(r=>r.summary.yearEqualCAGRpp>1e-9).length,zero:results.filter(r=>Math.abs(r.summary.yearEqualCAGRpp)<=1e-9).length,negative:results.filter(r=>r.summary.yearEqualCAGRpp< -1e-9).length},comparedWithCenter:results.map(({id,weights,tax,fee,delay,label,summary,versusCenter})=>({id,weights,tax,fee,delay,label,summary,versusCenter}))};
 fs.writeFileSync('ensemble-summary.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(main,null,2));
}
module.exports={factory,ensembleStates};
if(require.main===module){if(process.argv[2]==='develop')develop();else if(process.argv[2]==='evaluate')evaluate();else throw new Error('develop/evaluate');}
