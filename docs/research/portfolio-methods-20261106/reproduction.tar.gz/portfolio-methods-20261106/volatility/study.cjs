'use strict';
const fs=require('fs'),assert=require('assert/strict');
const engine=require('../engine.cjs');
const {makeFactory}=require('./policies.cjs');
const protocol=JSON.parse(fs.readFileSync('protocol.json'));
const sha=f=>engine.hash(fs.readFileSync(f));
const provenance=()=>Object.fromEntries(['protocol.json','policies.cjs','study.cjs','../engine.cjs','../inputs.json','../tax-inputs.json'].map(f=>[f,sha(f)]));
const mode=process.argv[2];
const enrich=r=>{r.summary.medianPaidCapitalTax=engine.median(r.rows.map(x=>x.capitalTax));r.summary.medianPaidDividendTax=engine.median(r.rows.map(x=>x.paidDividendTax));r.summary.medianTerminalTaxReserve=engine.median(r.rows.map(x=>x.reserve));r.summary.maxActualStockExposure=Math.max(...r.rows.map(x=>x.maxStockFraction));r.summary.maxActualLeverageExposure=Math.max(...r.rows.map(x=>x.maxDailyLeverageExposure));r.summary.medianCVaR95=engine.median(r.rows.map(x=>x.cvar95));r.summary.baselineMedianCVaR95=engine.median(r.baseline.map(x=>x.cvar95));return r;};
if(mode==='develop') {
 assert(!fs.existsSync('development.json')&&!fs.existsSync('selection.json'),'Refuse to overwrite completed development or selection');
 const results=protocol.candidates.map(c=>({c,...enrich(engine.evaluate(engine.periods.development28,[.3,.3],makeFactory(c,engine.sleeveTargetOrders),{fee:.001,tax:.2,delay:0}))}));
 fs.writeFileSync('development.json',JSON.stringify({provenance:provenance(),results})+'\n');
 const selected=Object.keys(protocol.families).map(f=>results.filter(r=>r.c.family===f).sort((a,b)=>b.summary.yearEqualCAGRpp-a.summary.yearEqualCAGRpp||a.summary.medianTradeCount-b.summary.medianTradeCount||a.c.id.localeCompare(b.c.id))[0]).map(r=>({c:r.c,development:r.summary}));
 const selection={frozenAt:new Date().toISOString(),selectionRule:protocol.selection,provenance:provenance(),developmentSHA256:sha('development.json'),selected};
 fs.writeFileSync('selection.json',JSON.stringify(selection,null,2)+'\n');
 console.log(JSON.stringify(selection,null,2));
} else if(mode==='evaluate') {
 assert(fs.existsSync('selection.json')&&!fs.existsSync('evaluation.json'));
 const selection=JSON.parse(fs.readFileSync('selection.json'));
 const results=[];
 for(const {c} of selection.selected)for(const weights of protocol.evaluation.weights)for(const tax of protocol.evaluation.taxes)for(const fee of protocol.evaluation.fees)for(const delay of protocol.evaluation.extraDelays)for(const label of protocol.evaluation.periods) {
  const r=enrich(engine.evaluate(engine.periods[label],weights,makeFactory(c,engine.sleeveTargetOrders),{fee,tax,delay}));
  results.push({c,weights,tax,fee,delay,label,...r});
 }
 fs.writeFileSync('evaluation.json',JSON.stringify({provenance:provenance(),selectionSHA256:sha('selection.json'),results})+'\n');
 const main=results.filter(r=>r.weights[0]===.3&&r.weights[1]===.3&&r.tax===.2&&r.fee===.001&&r.delay===0);
 console.log(JSON.stringify(main.map(({c,label,summary})=>({id:c.id,label,summary})),null,2));
} else throw new Error('Use develop or evaluate');
