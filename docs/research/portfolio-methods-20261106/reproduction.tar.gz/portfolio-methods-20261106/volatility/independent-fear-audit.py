"""Independent Python reconstruction of frozen VIX pressure/recovery candidate.
No imports of the JS policy or accounting engine, no new candidate selection.
"""
from pathlib import Path
from datetime import date
from statistics import mean
import json, math, hashlib

ROOT=Path(__file__).resolve().parent
read=lambda name:json.loads((ROOT/name).read_text())
data=read('../inputs.json'); taxdata=read('../tax-inputs.json')
selection=read('selection.json'); evaluated=read('evaluation.json')
c=next(x['c'] for x in selection['selected'] if x['c']['family']=='fear_reversal')
dates=[x[0] for x in data['daily']]; prices=[x[1] for x in data['daily']]
index={d:i for i,d in enumerate(dates)}; ordinals=[date.fromisoformat(d).toordinal() for d in dates]
divs=[[taxdata[k]['dividendEvidence']['fractions'].get(d,0) for d in dates] for k in ['us:USD','us:TQQQ']]

# Independent event automaton on paired Cboe observation dates.
observations=[]; invested=True; can_exit=True; stress_run=0; normal_run=0; out_days=0; peak_vix=0
events=[]
for d,vix,three in data['vix']:
    if not(vix>0 and three>0):continue
    ratio=vix/three
    normal_run=normal_run+1 if ratio<c['normalRatio'] else 0
    before=invested
    if invested:
        if not can_exit and normal_run>=c['normalConfirm']:can_exit=True
        stress_run=stress_run+1 if can_exit and ratio>c['ratio'] else 0
        if stress_run>=c['confirm']:
            invested=False; stress_run=0; normal_run=0; out_days=0; peak_vix=vix
    else:
        out_days+=1;peak_vix=max(peak_vix,vix)
        if (out_days>=c['minHold'] and vix<=peak_vix*(1-c['peakDrop'])) or normal_run>=c['normalConfirm']:
            invested=True;can_exit=False;stress_run=0;normal_run=0;out_days=0
    observations.append((d,invested))
    if invested!=before:events.append({'sourceDay':d,'target':1 if invested else c['off']})
states=[];p=-1;last=True
for d,od in zip(dates,ordinals):
    while p+1<len(observations) and observations[p+1][0]<d:p+=1
    if p>=0 and od-date.fromisoformat(observations[p][0]).toordinal()<=7:last=observations[p][1]
    states.append(last)
assert events==[{'sourceDay':'2020-03-06','target':0},{'sourceDay':'2020-03-30','target':1}]

def account(start,end,w,fee,tax,delay,active):
    first,last=index[start],index[end]
    units=[0.,0.];basis=[0.,0.];legcash=[0.,0.];cash=100.
    fees=cap=divtax=0.;peak=100.;mdd=0.;initialcash=0.;value=100.;gross=100.;reserve=0.
    maxstock=maxlev=totalstock=0.;prior=None;rets=[];trades=plans=0;pending=None;requested=True;caps=0
    for i in range(first,last+1):
        ps=prices[i]
        if i>first:
            for k in (0,1):
                dividend=units[k]*ps[k]*divs[k][i];charge=dividend*tax
                units[k]-=charge/ps[k];basis[k]+=dividend-charge;divtax+=charge
        pre=[units[k]*ps[k] for k in (0,1)];prewealth=cash+sum(pre)
        if prewealth>0:
            maxstock=max(maxstock,sum(pre)/prewealth);maxlev=max(maxlev,(2*pre[0]+3*pre[1])/prewealth)
        if i==first:
            for k in (0,1):
                notional=100*w[k]/(1+fee*sum(w));charge=notional*fee
                units[k]=notional/ps[k];basis[k]=notional+charge;cash-=notional+charge;fees+=charge;trades+=1
            initialcash=cash
        if pending is not None and pending[0]==i:
            due,side,amount=pending;pending=None
            if side=='sell':
                qty=min(units[1],amount);caps+=qty<amount-1e-10
                notional=qty*ps[1];charge=notional*fee
                cost=basis[1]*qty/units[1] if units[1]>0 else 0
                paid=max(0,notional-charge-cost)*tax;net=notional-charge-paid
                units[1]-=qty;basis[1]-=cost;cash+=net;legcash[1]+=net;cap+=paid
                if units[1]<1e-10:units[1]=basis[1]=0.
            else:
                notional=amount;charge=notional*fee
                units[1]+=notional/ps[1];basis[1]+=notional+charge;cash-=notional+charge;legcash[1]-=notional+charge
            fees+=charge;trades+=1
        if cash<0 and cash>-1e-7:cash=0.
        marks=[units[k]*ps[k] for k in (0,1)];gross=cash+sum(marks)
        reserve=sum(max(0,marks[k]*(1-fee)-basis[k])*tax for k in (0,1));value=gross-reserve
        peak=max(peak,value);mdd=min(mdd,100*(value/peak-1))
        fraction=sum(marks)/gross;totalstock+=fraction;maxstock=max(maxstock,fraction);maxlev=max(maxlev,(2*marks[0]+3*marks[1])/gross)
        if prior is not None:rets.append(value/prior-1)
        prior=value
        if active and pending is None and states[i]!=requested:
            requested=states[i]
            if requested:
                notional=max(0,legcash[1])/(1+fee)
                if notional>1e-10:pending=(i+1+delay,'buy',notional);plans+=1
            elif units[1]>1e-10:pending=(i+1+delay,'sell',units[1]);plans+=1
    years=(ordinals[last]-ordinals[first])/365.2425
    rets.sort();tail=max(1,math.ceil(len(rets)*.05))
    return dict(value=value,grossValue=gross,annualReturn=100*((value/100)**(1/years)-1),mdd=mdd,fees=fees,capitalTax=cap,paidDividendTax=divtax,paidTax=cap+divtax,reserve=reserve,finalCash=cash,initialCash=initialcash,tradeCount=trades,planCount=plans,maxStockFraction=maxstock,meanStockFraction=totalstock/(last-first+1),maxDailyLeverageExposure=maxlev,cvar95=100*mean(rets[:tail]),inventoryCapCount=caps)

cache={};max_errors={};pairs=0;groups=0;comparisons=0
for r in evaluated['results']:
    if r['c']['id']!=c['id']:continue
    groups+=1
    for active,key in [(True,'rows'),(False,'baseline')]:
        for expected in r[key]:
            args=(expected['start'],expected['end'],tuple(r['weights']),r['fee'],r['tax'],r['delay'] if active else 0,active)
            if args not in cache:cache[args]=account(*args)
            actual=cache[args];comparisons+=1
            for field,val in actual.items():
                error=abs(val-expected[field]);max_errors[field]=max(max_errors.get(field,0),error)
                assert error<1e-7,(args,field,val,expected[field],error)
    pairs+=len(r['rows'])
out={'passed':True,'method':'Independent Python state machine and complete daily tax/fee/unit/cash ledger; no JS accounting imports','candidate':c,'groups':groups,'pairedRowsChecked':pairs,'accountRowsChecked':comparisons,'uniqueReconstructedAccounts':len(cache),'events':events,'maxErrors':max_errors,'sources':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['independent-fear-audit.py','protocol.json','selection.json','evaluation.json','../inputs.json','../tax-inputs.json']}}
(ROOT/'independent-fear-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
