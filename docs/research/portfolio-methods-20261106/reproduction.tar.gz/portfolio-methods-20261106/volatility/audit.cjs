'use strict';
const fs=require('fs'),assert=require('assert/strict');
const E=require('../engine.cjs'),P=require('./policies.cjs');
const selected=JSON.parse(fs.readFileSync('selection.json')).selected;
const checks=[],traces=[],transitions=[];
const sha=f=>E.hash(fs.readFileSync(f));
for(const {c} of selected) {
 const target=P.targets(E.input,c),source=c.family==='fear_reversal'?target.vix:target.qqq;
 let prior=1;
 const events=[];for(const r of source){if(r.target!==prior){events.push({sourceDay:r.day,target:r.target,...c.family==='fear_reversal'?{vix:r.vix,ratio:r.ratio,peak:r.peak}:{rv21:r.rv21,rv126:r.rv126,downsideFraction21:r.downsideFraction21}});prior=r.target;}}
 transitions.push({id:c.id,events});
 for(const weights of [[.3,.3],[.5,.5]])for(const delay of [0,1])for(const origin of [E.periods.later35[0],E.periods.all15_21[0]]) {
  const a=E.account(origin,weights,P.makeFactory(c,E.sleeveTargetOrders),{fee:.001,tax:.2,delay,trace:true});
  const price=new Map(E.input.daily);
  for(const point of a.curve) {
   assert.ok(point.cash>=a.initialCash-1e-7,'Original cash spent');
   assert.ok(point.cashByLeg.every(x=>x>=-1e-7),'Borrowed from another leg');
   assert.ok(Math.abs(point.cash-a.initialCash-E.sum(point.cashByLeg))<1e-7,'Cash attribution imbalance');
  }
  for(const plan of a.plans) {
   const snapshot=a.curve.find(x=>x.day===plan.signalDay);
   assert.ok(E.sum(plan.buyAmounts)*(1+.001)<=snapshot.cash+1e-7);
   for(let k=0;k<2;k++) {
    assert.ok(plan.buyAmounts[k]*(1+.001)<=snapshot.cashByLeg[k]+1e-7);
    assert.ok(Math.abs(plan.sellUnits[k]-snapshot.units[k]*plan.sellFractions[k])<1e-9);
   }
  }
  for(const t of a.trades.filter(x=>x.reason!=='initial')) {
   const plan=a.plans.find(x=>x.signalDay===t.signalDay);
   assert.equal(t.day,plan.dueDay);assert.ok(t.signalDay<t.day);
   if(t.side==='buy')assert.equal(t.amount,plan.buyAmounts[t.leg]);
   else {assert.ok(t.units<=plan.sellUnits[t.leg]+1e-10);assert.ok(Math.abs(t.amount-t.units*price.get(t.day)[t.leg])<1e-8);}
  }
  traces.push({id:c.id,weights,delay,origin,account:a});
 }
 for(const cutoff of ['2020-03-20','2022-06-01']) {
  const origin=E.periods.later35[0],changed=JSON.parse(JSON.stringify(E.input));
  for(const [day,ps] of changed.daily)if(day>cutoff){ps[0]*=1.9;ps[1]*=.42;}
  for(const proxy of Object.values(changed.proxies))for(const r of proxy.series)if(r[0]>cutoff)r[1]*=3;
  for(const r of changed.vix)if(r[0]>cutoff){r[1]*=4;r[2]*=.3;}
  const a=E.account(origin,[.3,.3],P.makeFactory(c,E.sleeveTargetOrders),{fee:.001,tax:.2,trace:true});
  const b=E.account(origin,[.3,.3],P.makeFactory(c,E.sleeveTargetOrders),{fee:.001,tax:.2,trace:true,env:E.environment(changed)});
  for(const k of ['trades','curve'])assert.deepEqual(a[k].filter(x=>x.day<=cutoff),b[k].filter(x=>x.day<=cutoff));
  assert.deepEqual(a.plans.filter(x=>x.signalDay<=cutoff),b.plans.filter(x=>x.signalDay<=cutoff));
  checks.push({id:c.id,check:'Future target/proxy/VIX prices cannot change prefix plans/trades/wealth/taxes',cutoff});
 }
}
fs.writeFileSync('traces.json',JSON.stringify({transitions,traces})+'\n');
const audit={passed:true,checks,traceAccounts:traces.length,totalPlans:traces.reduce((s,x)=>s+x.account.plans.length,0),totalTrades:traces.reduce((s,x)=>s+x.account.trades.length,0),conservation:'cash=originalCash+sum(cashByLeg), each leg>=0; never spend same-plan sale proceeds; sell units fixed and buy notional fixed at signal close',provenance:Object.fromEntries(['audit.cjs','policies.cjs','protocol.json','selection.json','../engine.cjs','../inputs.json'].map(f=>[f,sha(f)]))};
fs.writeFileSync('audit.json',JSON.stringify(audit,null,2)+'\n');console.log(JSON.stringify(audit,null,2));
