"use strict";
const assert=require('node:assert/strict'),{makePolicy}=require('./study.cjs');
const dates=Array.from({length:270},(_,i)=>String(i));
const input={daily:dates.map((day,i)=>[day,[i<240?50:100,50]])};
input.daily[246][1][0]=98;input.daily[251][1][0]=95;input.daily[252][1][0]=90;input.daily[253][1][0]=70;input.daily[254][1][0]=99;
const c={lookback:63,growth:.5,sellFraction:.1,maxWait:21};
const events=[],policy=makePolicy(c,events)({input,dates,fee:.001});
function ctx(i,overrides={}){return {index:i,day:dates[i],prices:input.daily[i][1],units:[10,10],marks:[10*input.daily[i][1][0],500],basis:[100,500],cash:40,initialCash:40,cashByLeg:[0,0],latestFills:[],...overrides};}
const sale=policy.step(ctx(251));assert.deepEqual(sale.sellFractions,[.1,0]);assert.deepEqual(sale.buyAmounts,[0,0]);
assert.equal(policy.step(ctx(252,{latestFills:[{reason:'policy',leg:0,side:'sell',units:1,netCash:80,fee:.09,tax:9.91,signalDay:'251'}],units:[9,10],cash:120,cashByLeg:[80,0]})),null);
const buy=policy.step(ctx(253,{units:[9,10],cash:120,cashByLeg:[80,0]}));assert.equal(buy.buyAmounts[0],80/1.001);assert.equal(buy.sellFractions[0],0);
// Next-day rebound must not change the precommitted buy budget: the policy stays pending.
assert.equal(policy.step(ctx(254,{units:[9,10],cash:120,cashByLeg:[80,0]})),null);
assert.equal(policy.step(ctx(254,{units:[9+buy.buyAmounts[0]/99,10],cash:40,cashByLeg:[0,0],latestFills:[{reason:'policy',leg:0,side:'buy',units:buy.buyAmounts[0]/99,netCash:-80,signalDay:'253'}]})),null);
assert(events.some(e=>e.event==='recovered'&&e.boughtUnits<e.formerlySoldUnits),'gap-up must expose re-purchase risk, not claim guaranteed same units');
console.log(JSON.stringify({passed:true,checks:['sale trigger and fixed fraction conversion input','no same-plan use of future proceeds','known settled per-leg cash only','pending budget is unchanged by rebound','signal affordability does not promise execution units']}));
