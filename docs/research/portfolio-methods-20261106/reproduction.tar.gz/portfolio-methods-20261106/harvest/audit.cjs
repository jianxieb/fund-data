"use strict";
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const E=require('../engine.cjs'),S=require('./study.cjs'),DIR=__dirname;
const j=n=>JSON.parse(fs.readFileSync(path.join(DIR,n))),sha=p=>E.hash(fs.readFileSync(p));
const evaluation=j('evaluation.json'),selection=j('selection.json'),stats={accounts:0,tradeChecks:0,planChecks:0,dailyChecks:0,inventoryCaps:0,maxValueError:0,maxMddError:0,maxCashError:0,saleSignalDays:new Set(),buySignalDays:new Set(),roundTrips:0,restorationTriggers:0,timeoutTriggers:0,actualFewerUnits:0};
const EPS=1e-8,near=(a,b,tol=EPS)=>assert(Math.abs(a-b)<=tol,`${a} != ${b}`),prices=E.input.daily,indices=new Map(prices.map((r,i)=>[r[0],i]));
function audit(origin,w,opts,recorded){
 const events=[],r=E.account(origin,w,S.makePolicy(selection.candidate,events),{...opts,trace:true});
 for(const key of ['value','annualReturn','mdd','fees','capitalTax','paidDividendTax','reserve','finalCash'])near(r[key],recorded[key]);
 let cash=100,q=[0,0],basis=[0,0],paidCapital=0,divTax=0,fees=0,peak=100,mdd=0,value=100,initialCash=null;
 const trades=new Map(),plans=new Map(r.plans.map(p=>[p.signalDay,p]));
 for(const t of r.trades){if(!trades.has(t.day))trades.set(t.day,[]);trades.get(t.day).push(t);}
 const first=indices.get(origin.start),last=indices.get(origin.end),fee=opts.fee,tax=opts.tax;
 for(let i=first;i<=last;i++){
  const [day,p]=prices[i];
  if(i>first)for(let k=0;k<2;k++){const div=q[k]*p[k]*(E.taxInput[['us:USD','us:TQQQ'][k]].dividendEvidence.fractions[day]||0);q[k]-=div*tax/p[k];basis[k]+=div*(1-tax);divTax+=div*tax;}
  for(const t of trades.get(day)||[]){
   const k=t.leg;near(t.amount,t.units*p[k]);near(t.fee,t.amount*fee);
   if(t.reason==='initial'){near(t.amount,100*w[k]/(1+fee*E.sum(w)));assert.equal(i,first);}
   else{const plan=plans.get(t.signalDay);assert(plan);assert.equal(i,indices.get(t.signalDay)+1+opts.delay);assert(day>t.signalDay);
    if(t.side==='sell'){near(t.units,Math.min(q[k],plan.sellUnits[k]));assert(plan.sellUnits[k]>=0);stats.inventoryCaps+=t.inventoryCapped?1:0;}
    else near(t.amount,plan.buyAmounts[k]);
   }
   if(t.side==='sell'){
    const cost=basis[k]*t.units/q[k],tx=Math.max(0,t.amount-t.fee-cost)*tax;
    near(tx,t.tax);near(t.netCash,t.amount-t.fee-tx);cash+=t.netCash;q[k]-=t.units;basis[k]-=cost;paidCapital+=tx;
   }else{assert.equal(t.tax,0);near(t.netCash,-t.amount-t.fee);cash-=t.amount+t.fee;q[k]+=t.units;basis[k]+=t.amount+t.fee;}
   fees+=t.fee;stats.tradeChecks++;
  }
  if(i===first)initialCash=cash;
  const marks=q.map((v,k)=>v*p[k]),gross=cash+E.sum(marks),reserve=E.sum(marks.map((m,k)=>Math.max(0,m*(1-fee)-basis[k])*tax));value=gross-reserve;
  peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));
  const curve=r.curve[i-first];near(curve.value,value);near(curve.cash,cash);q.forEach((v,k)=>near(v,curve.units[k]));basis.forEach((v,k)=>near(v,curve.basis[k]));
  assert(cash>=initialCash-1e-7,'Original idle cash was consumed');
  const plan=plans.get(day);if(plan){
   near(plan.knownCash,cash);assert(E.sum(plan.buyAmounts)*(1+fee)<=cash-initialCash+1e-7);
   for(let k=0;k<2;k++)near(plan.sellUnits[k],plan.sellFractions[k]*q[k]);
   stats.planChecks++;
  }
  stats.dailyChecks++;
 }
 const annual=100*((value/100)**(365.2425/((Date.parse(origin.end)-Date.parse(origin.start))/864e5))-1);
 near(value,r.value);near(cash,r.finalCash);near(annual,r.annualReturn);near(mdd,r.mdd);near(fees,r.fees);near(paidCapital,r.capitalTax);near(divTax,r.paidDividendTax);
 stats.maxValueError=Math.max(stats.maxValueError,Math.abs(value-r.value));stats.maxCashError=Math.max(stats.maxCashError,Math.abs(cash-r.finalCash));stats.maxMddError=Math.max(stats.maxMddError,Math.abs(mdd-r.mdd));
 for(const e of events){
  if(e.event==='sell-plan'){
   const i=indices.get(e.day),p=prices[i][1][e.leg],candidate=selection.candidate;
   assert(i>=251);near(e.growth,p/prices[i-candidate.lookback][1][e.leg]-1);near(e.high,Math.max(...prices.slice(i-251,i+1).map(row=>row[1][e.leg])));
   assert(e.growth>=candidate.growth&&p>=.9*e.high&&p<prices[i-5][1][e.leg]);stats.saleSignalDays.add(`${e.day}:${e.leg}`);
  }else if(e.event==='buy-plan'){assert(e.afterSaleCloses>=0);assert(e.canRestore||e.timedOut);near(e.amount*(1+fee),e.knownPool);stats.buySignalDays.add(`${e.day}:${e.leg}`);stats.restorationTriggers+=e.canRestore?1:0;stats.timeoutTriggers+=e.timedOut?1:0;
  }else if(e.event==='recovered'){stats.roundTrips++;stats.actualFewerUnits+=e.boughtUnits<e.formerlySoldUnits-EPS?1:0;}
 }
 stats.accounts++;
}
for(const result of evaluation.results){
 const opts={fee:result.fee,tax:result.tax,dividendTax:result.dividendTax,delay:result.delay};
 for(const stage of ['all10','all15'])for(const recorded of result[stage].rows)audit(recorded,result.weights,opts,recorded);
}
const out={status:'pass',kind:'Full selected-grid independent ledger reconstruction from raw inputs and actual plans, plus source-based signal checks; same JS runtime, separate arithmetic replay, not an external auditor',protocolSHA256:sha(path.join(DIR,'protocol.json')),studySHA256:sha(path.join(DIR,'study.cjs')),engineSHA256:sha(path.join(DIR,'../engine.cjs')),evaluationSHA256:sha(path.join(DIR,'evaluation.json')),auditSHA256:sha(__filename),...stats,saleSignalDays:[...stats.saleSignalDays].sort(),buySignalDays:[...stats.buySignalDays].sort(),caveat:'Event counts across origins overlap and are not independent market events. Repurchase affordability at signal time does not ensure equal units at actual next close; all such shortfalls are retained.'};
fs.writeFileSync(path.join(DIR,'audit.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({...out,saleSignalDays:out.saleSignalDays.length,buySignalDays:out.buySignalDays.length}));
