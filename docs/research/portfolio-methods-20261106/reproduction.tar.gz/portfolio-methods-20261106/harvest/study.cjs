"use strict";
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const engine=require('../engine.cjs');
const DIR=__dirname,protocolPath=path.join(DIR,'protocol.json'),protocol=JSON.parse(fs.readFileSync(protocolPath));
const shaFile=p=>engine.hash(fs.readFileSync(p));
const save=(n,v)=>fs.writeFileSync(path.join(DIR,n),JSON.stringify(v,null,2)+'\n');
const EPS=1e-9, featureCache=new WeakMap();
function features(input){
 if(featureCache.has(input))return featureCache.get(input);
 const prices=input.daily.map(r=>r[1]);
 const high=prices.map((row,i)=>row.map((p,k)=>i>=251?Math.max(...prices.slice(i-251,i+1).map(r=>r[k])):null));
 const out={prices,high};featureCache.set(input,out);return out;
}
function makePolicy(candidate,events=null){
 return function factory({input,dates,fee}){
  const f=features(input),state=[0,1].map(()=>({mode:'armed',harvestHigh:null,soldUnits:0,saleIndex:null}));
  const record=e=>{if(events)events.push(e);};
  return {step(ctx){
   for(const fill of ctx.latestFills){
    if(fill.reason==='initial')continue;
    const k=fill.leg,s=state[k];
    if(fill.side==='sell'){
     assert.equal(s.mode,'sell-pending');assert(fill.units>0&&fill.netCash>0);
     s.mode='waiting';s.soldUnits=fill.units;s.saleIndex=ctx.index;
     record({event:'sold',day:ctx.day,leg:k,signalDay:fill.signalDay,soldUnits:fill.units,netCash:fill.netCash,fee:fill.fee,tax:fill.tax});
    }else{
     assert.equal(s.mode,'buy-pending');s.mode='disarmed';s.recoveredIndex=ctx.index;
     record({event:'recovered',day:ctx.day,leg:k,signalDay:fill.signalDay,boughtUnits:fill.units,formerlySoldUnits:s.soldUnits,paid:-fill.netCash});
    }
   }
   const sellFractions=[0,0],buyAmounts=[0,0],reasons=[];
   for(let k=0;k<2;k++){
    const s=state[k],p=ctx.prices[k];
    if(s.mode==='waiting'){
     const pool=Math.max(0,ctx.cashByLeg[k]),canRestore=pool+EPS>=s.soldUnits*p*(1+fee),timedOut=ctx.index-s.saleIndex>=candidate.maxWait;
     if(canRestore||timedOut){
      assert(ctx.index>=s.saleIndex); // decision is after the sale has actually settled
      const nominal=pool/(1+fee);
      if(nominal>EPS){buyAmounts[k]=nominal;s.mode='buy-pending';reasons.push(`recover:${k}:${canRestore?'net-repurchase':'timeout'}`);
       record({event:'buy-plan',day:ctx.day,leg:k,amount:nominal,knownPool:pool,knownCash:ctx.cash,afterSaleCloses:ctx.index-s.saleIndex,canRestore,timedOut});}
     }
     continue;
    }
    if(s.mode==='disarmed'){
     if(ctx.index>s.recoveredIndex&&p>s.harvestHigh){s.mode='armed';record({event:'rearmed',day:ctx.day,leg:k,price:p,priorHarvestHigh:s.harvestHigh});}
     continue;
    }
    if(s.mode!=='armed'||ctx.index<251||ctx.index<candidate.lookback||ctx.units[k]<=EPS)continue;
    const growth=p/f.prices[ctx.index-candidate.lookback][k]-1,high=f.high[ctx.index][k];
    if(growth>=candidate.growth&&p>=0.9*high&&p<f.prices[ctx.index-5][k]&&ctx.marks[k]>ctx.basis[k]){
     sellFractions[k]=candidate.sellFraction;s.mode='sell-pending';s.harvestHigh=high;
     reasons.push(`harvest:${k}`);record({event:'sell-plan',day:ctx.day,leg:k,knownUnits:ctx.units[k],sellUnits:ctx.units[k]*candidate.sellFraction,price:p,high,growth});
    }
   }
   assert(engine.sum(buyAmounts)*(1+fee)<=Math.max(0,ctx.cash-ctx.initialCash)+1e-7,'original cash would be spent');
   if(engine.sum(buyAmounts)>EPS||engine.sum(sellFractions)>EPS)return {sellFractions,buyAmounts,reason:reasons.join('|')};
   return null;
  }};
 };
}
function verifyLock(){
 const lock=JSON.parse(fs.readFileSync(path.join(DIR,'implementation-lock.json')));
 assert.equal(shaFile(protocolPath),lock.protocolSHA256);
 assert.equal(shaFile(path.join(DIR,'study.cjs')),lock.studySHA256);
 assert.equal(shaFile(path.join(DIR,'../engine.cjs')),lock.engineSHA256);
 for(const [n,sha] of Object.entries(protocol.inputs))assert.equal(shaFile(path.join(DIR,'..',n)),sha);
 return lock;
}
function options(fee=.001,delay=0,trace=false){return {fee,tax:.2,dividendTax:.2,delay,trace};}
function run(candidate,origins,weights=[.3,.3],opts=options()){
 return engine.evaluate(origins,weights,makePolicy(candidate),opts);
}
function stageStats(rows,baselines){
 const keep=(r,which)=>which==='development28'?r.years===10&&r.start>='2011-09-01'&&r.start<'2014':which==='later35'?r.years===10&&r.start>='2014'&&r.start<'2017':true;
 return Object.fromEntries(['development28','later35'].map(which=>[which,engine.compare(rows.filter(r=>keep(r,which)),baselines.filter(r=>keep(r,which)))]));
}
function main(){
 const mode=process.argv[2];
 if(mode==='lock'){
  const out={protocolSHA256:shaFile(protocolPath),studySHA256:shaFile(__filename),engineSHA256:shaFile(path.join(DIR,'../engine.cjs')),inputs:protocol.inputs,lockedAtUTC:new Date().toISOString(),note:'No account returns evaluated before locking this implementation. Features use only each close and its prior observations.'};
  save('implementation-lock.json',out);console.log(JSON.stringify(out));return;
 }
 const lock=verifyLock();
 if(mode==='develop'){
  const results=protocol.candidates.map(candidate=>({candidate,...run(candidate,engine.periods.development28)}));
  results.sort((a,b)=>b.summary.yearEqualCAGRpp-a.summary.yearEqualCAGRpp||a.candidate.id.localeCompare(b.candidate.id));
  save('development.json',{lock,results});
  const selection={lock,developmentSHA256:shaFile(path.join(DIR,'development.json')),candidate:results[0].candidate,development:results[0].summary,selection:'best of frozen 16 by development28 year-equal CAGR pp; one mechanism only; selection locked before later evaluation'};
  save('selection.json',selection);console.log(JSON.stringify(results.map(r=>({candidate:r.candidate,summary:r.summary})),null,2));
 }else if(mode==='evaluate'){
  const selection=JSON.parse(fs.readFileSync(path.join(DIR,'selection.json')));
  assert.equal(selection.developmentSHA256,shaFile(path.join(DIR,'development.json')));
  const selected=selection.candidate;
  const results=[];
  for(const weights of protocol.evaluation.weightChecks)for(const fee of protocol.evaluation.feeChecks)for(const delay of protocol.evaluation.extraDelayChecks){
   const all10=run(selected,engine.periods.all10_81,weights,options(fee,delay));
   const all15=run(selected,engine.periods.all15_21,weights,options(fee,delay));
   results.push({weights,fee,tax:.2,dividendTax:.2,delay,all10,all15,stages:stageStats(all10.rows,all10.baseline)});
  }
  save('evaluation.json',{lock,selectionSHA256:shaFile(path.join(DIR,'selection.json')),candidate:selected,results});
  console.log(JSON.stringify(results.map(r=>({weights:r.weights,fee:r.fee,delay:r.delay,all10:r.all10.summary,all15:r.all15.summary,stages:r.stages})),null,2));
 }else if(mode==='trace'){
  const selection=JSON.parse(fs.readFileSync(path.join(DIR,'selection.json'))),candidate=selection.candidate;
  const origin=engine.periods.development28[0],events=[];
  const result=engine.account(origin,[.3,.3],makePolicy(candidate,events),options(.001,0,true));
  save('trace.json',{lock,candidate,origin,events,result});console.log(JSON.stringify({origin,candidate,events:events.length,trades:result.tradeCount,value:result.value}));
 }else throw Error('mode lock / develop / evaluate / trace');
}
if(require.main===module)main();
module.exports={makePolicy,features,run,verifyLock,options,stageStats};
