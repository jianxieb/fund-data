"use strict";
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const E=require('../engine.cjs'),V=require('../volatility/policies.cjs'),H=require('./study.cjs'),R=require('../rotation/ensemble/policy.cjs');
const root='/Users/ajin/Projects/fund-data',S=require(root+'/assets/portfolio-systematic.js');
const sha=p=>E.hash(fs.readFileSync(p)),rawHistories={'us:QQQ':E.input.proxies['us:QQQ'].series};
for(const code of ['USD','TQQQ']){
 const directory=root+'/data/portfolio/us',files=fs.readdirSync(directory).filter(p=>p.startsWith(code+'-')).map(p=>JSON.parse(fs.readFileSync(path.join(directory,p))));
 const data=files.sort((a,b)=>b.asOf.localeCompare(a.asOf))[0];rawHistories['us:'+code]=data.series;
}
const context=JSON.parse(fs.readFileSync(root+'/data/portfolio/entry-context.json'));
context.series=E.input.vix;context.first=context.series[0][0];context.asOf=context.series.at(-1)[0];
const vixCandidate=JSON.parse(fs.readFileSync(__dirname+'/../volatility/selection.json')).selected.find(r=>r.c.family==='fear_reversal').c;
const methods=[['vix_panic_reentry',V.makeFactory(vixCandidate,E.sleeveTargetOrders)],['dual_risk_guard',H.factory('hybrid')],['relative_strength_rotation',R.ensembleFactory(E.stockMixOrders,0)]];
const counters={accounts:0,plans:0,trades:0,maxValueError:0,maxMddError:0,maxOrderError:0},failures=[];
function near(a,b,label,tol=1e-8){const e=Math.abs(a-b);assert(e<=tol,`${label}: ${a} != ${b}`);return e;}
const origins=E.periods.all10_81.concat(E.periods.all15_21),groups=[];
for(const [method,referenceFactory]of methods)for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const fee of [.001,.005])for(const delay of [0,1]){
 const factory=()=>S.create({method,weights,rawHistories,vixContext:context});
 let maxValueError=0;
 for(const origin of origins){
  const options={fee,tax:.2,dividendTax:.2,delay,trace:true},expected=E.account(origin,weights,referenceFactory,options),actual=E.account(origin,weights,factory,options);
  counters.maxValueError=Math.max(counters.maxValueError,near(actual.value,expected.value,method+' value'));maxValueError=Math.max(maxValueError,Math.abs(actual.value-expected.value));
  counters.maxMddError=Math.max(counters.maxMddError,near(actual.mdd,expected.mdd,method+' mdd'));
  for(const k of ['annualReturn','fees','capitalTax','paidDividendTax','reserve','finalCash'])near(actual[k],expected[k],method+' '+k);
  assert.equal(actual.plans.length,expected.plans.length,method+' plans '+origin.start);assert.equal(actual.trades.length,expected.trades.length,method+' trades');
  for(let i=0;i<actual.plans.length;i++){
   const a=actual.plans[i],b=expected.plans[i];assert.equal(a.signalDay,b.signalDay,method+' signal');assert.equal(a.dueDay,b.dueDay);
   for(const k of ['sellUnits','buyAmounts'])for(let leg=0;leg<2;leg++)counters.maxOrderError=Math.max(counters.maxOrderError,near(a[k][leg],b[k][leg],method+' '+k));
  }
  for(let i=0;i<actual.trades.length;i++){
   const a=actual.trades[i],b=expected.trades[i];for(const k of ['day','signalDay','side','leg'])assert.equal(a[k],b[k]);for(const k of ['amount','units','fee','tax'])near(a[k],b[k],method+' fill '+k);
  }
  counters.accounts++;counters.plans+=actual.plans.length;counters.trades+=actual.trades.length;
 }
 groups.push({method,weights,fee,delay,accounts:origins.length,maxValueError});
}
const out={status:'pass',productionModuleSHA256:sha(root+'/assets/portfolio-systematic.js'),productionTestsSHA256:sha(root+'/tests/portfolio-systematic.test.cjs'),engineSHA256:sha(__dirname+'/../engine.cjs'),researchSources:{vix:sha(__dirname+'/../volatility/policies.cjs'),hybrid:sha(__dirname+'/study.cjs'),rotation:sha(__dirname+'/../rotation/ensemble/policy.cjs')},scope:'Production pure controllers vs frozen research controllers, every account and fixed order, native USD ETF histories (relative currency cancels), actual QQQ USD and frozen paired Cboe observations. Common engine identical; separate Python already audits the research ledger.',counters,groups};
fs.writeFileSync(__dirname+'/production-golden.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({...out,groups:groups.length}));
