"use strict";
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const E=require('../engine.cjs'),V=require('../volatility/policies.cjs'),DIR=__dirname;
const read=n=>JSON.parse(fs.readFileSync(path.join(DIR,n))),save=(n,x)=>fs.writeFileSync(path.join(DIR,n),JSON.stringify(x,null,2)+'\n'),sha=p=>E.hash(fs.readFileSync(p));
const protocol=read('protocol.json'),candidate=protocol.candidates[0],qqqCache=new WeakMap();
function qqqStates(input){
 if(qqqCache.has(input))return qqqCache.get(input);
 const rows=input.proxies['us:QQQ'].series;let on=true,exitRun=0,entryRun=0;
 const states=rows.map(([day,p],i)=>{
  if(i)assert((Date.parse(day)-Date.parse(rows[i-1][0]))/864e5<=7,'QQQ source gap');
  if(i<251)return {day,ready:false,on:true,target:1};
  const ma=E.mean(rows.slice(i-199,i+1).map(r=>r[1])),high=Math.max(...rows.slice(i-251,i+1).map(r=>r[1]));
  if(on){exitRun=p<ma&&p/high<=.8?exitRun+1:0;if(exitRun>=20){on=false;exitRun=0;entryRun=0;}}
  else{entryRun=p>ma?entryRun+1:0;if(entryRun>=3){on=true;exitRun=0;entryRun=0;}}
  return {day,ready:true,price:p,ma,high,drawdown:p/high-1,on,target:on?1:0,exitRun,entryRun};
 });qqqCache.set(input,states);return states;
}
function factory(mode='hybrid',events=null){
 return ({input})=>{
  const vix=V.targets(input,candidate.vix).vix,qqq=qqqStates(input);let vixOn=true,qqqOn=true,requested=true;
  return {step(ctx){
   const v=V.latest(vix,ctx.day,true),q=V.latest(qqq,ctx.day);
   if(v&&(Date.parse(ctx.day)-Date.parse(v.day))/864e5<=7)vixOn=v.target===1;
   if(q&&q.ready&&(Date.parse(ctx.day)-Date.parse(q.day))/864e5<=7)qqqOn=q.on;
   const on=mode==='vix'?vixOn:mode==='qqq'?qqqOn:vixOn&&qqqOn;
   if(on===requested)return null;
   const previous=requested;requested=on;
   const order=E.sleeveTargetOrders(ctx,[1,on?1:0]);order.sellFractions[0]=0;order.buyAmounts[0]=0;
   const event={day:ctx.day,mode,previous,on,vixOn,qqqOn,vixDay:v?.day??null,qqqDay:q?.day??null,sellUnits:ctx.units[1]*order.sellFractions[1],buyAmount:order.buyAmounts[1],knownLegCash:ctx.cashByLeg[1]};
   if(events)events.push(event);
   return {...order,reason:mode+'_risk_gate'};
  }};
 };
}
function lock(){const out={protocolSHA256:sha(path.join(DIR,'protocol.json')),studySHA256:sha(__filename),files:protocol.inputs,lockedAtUTC:new Date().toISOString(),note:'Only A fixed combination is implemented. No new parameter optimization. Parents have previously been examined on these periods.'};save('implementation-lock.json',out);return out;}
function verifyLock(){const l=read('implementation-lock.json');assert.equal(l.protocolSHA256,sha(path.join(DIR,'protocol.json')));assert.equal(l.studySHA256,sha(__filename));for(const [f,h] of Object.entries(l.files))assert.equal(sha(path.join(DIR,'..',f)),h);return l;}
function opts(fee=.001,delay=0,trace=false){return {fee,tax:.2,dividendTax:.2,delay,trace};}
function evaluate(origins,w,options){
 const baseline=origins.map(o=>E.account(o,w,null,{...options,delay:0}));
 const vix=origins.map(o=>E.account(o,w,V.makeFactory(candidate.vix,E.sleeveTargetOrders),options));
 const qqq=origins.map(o=>E.account(o,w,factory('qqq'),options));
 const hybrid=origins.map(o=>E.account(o,w,factory('hybrid'),options));
 return {baseline,vix,qqq,hybrid,summary:{hybridVsLump:E.compare(hybrid,baseline),vixVsLump:E.compare(vix,baseline),qqqVsLump:E.compare(qqq,baseline),hybridVsVix:E.compare(hybrid,vix),hybridVsQqq:E.compare(hybrid,qqq)}};
}
function subset(result,match){
 const r=Object.fromEntries(['baseline','vix','qqq','hybrid'].map(k=>[k,result[k].filter(match)]));
 return {n:r.baseline.length,hybridVsLump:E.compare(r.hybrid,r.baseline),vixVsLump:E.compare(r.vix,r.baseline),qqqVsLump:E.compare(r.qqq,r.baseline),hybridVsVix:E.compare(r.hybrid,r.vix),hybridVsQqq:E.compare(r.hybrid,r.qqq)};
}
function transitions(){
 const extract=rows=>{let previous=true;return rows.filter(r=>{if(r.ready===false)return false;const on=r.target===1;if(on!==previous){previous=on;return true;}return false;});};
 return {vix:extract(V.targets(E.input,candidate.vix).vix),qqq:extract(qqqStates(E.input))};
}
function main(){const mode=process.argv[2];if(mode==='lock'){console.log(JSON.stringify(lock()));return;}const l=verifyLock();
 if(mode==='develop'){
  const result=evaluate(E.periods.development28,[.3,.3],opts());
  save('development.json',{lock:l,candidate,result});save('selection.json',{candidate,developmentSHA256:sha(path.join(DIR,'development.json')),development:result.summary,selected:'Single pre-frozen combination A; no adjustable parameter and no replacement based on outcomes',lockedAtUTC:new Date().toISOString()});
  console.log(JSON.stringify(result.summary,null,2));
 }else if(mode==='evaluate'){
  const selection=read('selection.json');assert.equal(selection.developmentSHA256,sha(path.join(DIR,'development.json')));const results=[];
  for(const weights of protocol.account.weightsToEvaluate)for(const fee of protocol.account.fees)for(const delay of protocol.account.delays){
   const all10=evaluate(E.periods.all10_81,weights,opts(fee,delay)),all15=evaluate(E.periods.all15_21,weights,opts(fee,delay));
   results.push({weights,fee,tax:.2,dividendTax:.2,delay,all10,all15,development28:subset(all10,r=>r.start>='2011-09-01'&&r.start<'2014'),later35:subset(all10,r=>r.start>='2014'&&r.start<'2017')});
  }
  save('evaluation.json',{lock:l,selectionSHA256:sha(path.join(DIR,'selection.json')),candidate,results});save('signal-transitions.json',{lock:l,...transitions()});console.log(JSON.stringify(results.map(r=>({weights:r.weights,fee:r.fee,delay:r.delay,all10:r.all10.summary,all15:r.all15.summary,later35:r.later35})),null,2));
 }else if(mode==='trace'){
  const origin=E.periods.all15_21[0],events=[],result=E.account(origin,[.3,.3],factory('hybrid',events),opts(.001,0,true));save('trace.json',{candidate,events,result});console.log(JSON.stringify({start:origin.start,end:origin.end,value:result.value,events}));
 }else throw Error('lock | develop | evaluate | trace');
}
if(require.main===module)main();
module.exports={factory,qqqStates,evaluate,opts,verifyLock,candidate,transitions};
