import json,hashlib,pathlib,datetime,bisect,math,time
P=pathlib.Path(__file__).parent; B=P.parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(pathlib.Path(p).read_text())
protocol=read(P/'protocol.json'); x=read(B/'inputs.json'); taxdata=read(B/'tax-inputs.json'); expected=read(P/'evaluation.json')
for f,h in protocol['inputs'].items(): assert sha(B/f)==h,(f,'changed')
daily=x['daily']; dates=[r[0] for r in daily]; dateix={d:i for i,d in enumerate(dates)}; ps=[r[1] for r in daily]
daynum=lambda d:datetime.date.fromisoformat(d).toordinal()
ordinals=[daynum(d) for d in dates]
divs=[[taxdata[k]['dividendEvidence']['fractions'].get(d,0.0) for k in ['us:USD','us:TQQQ']] for d in dates]
# Independent state machines, without executing/importing any JS signal code.
qqq=x['proxies']['us:QQQ']['series']; qp=[r[1] for r in qqq]; qdays=[r[0] for r in qqq]
qstate=[]; on=True; below=above=0; qtrans=[]
for i,(day,price) in enumerate(qqq):
 before=on
 if i>=251:
  ma=sum(qp[i-199:i+1])/200; high=max(qp[i-251:i+1])
  if on:
   below=below+1 if price<ma and price/high<=.8 else 0
   if below>=20:on=False;below=above=0
  else:
   above=above+1 if price>ma else 0
   if above>=3:on=True;above=below=0
 if on!=before:qtrans.append([day,on])
 qstate.append(on if i>=251 else None)
c=protocol['candidates'][0]['vix']; vr=[r for r in x['vix'] if r[1]>0 and r[2]>0]; vdays=[r[0] for r in vr]
vstate=[];on=armed=True;exitrun=calm=held=0;peak=0;vtrans=[]
for day,v,v3 in vr:
 before=on;ratio=v/v3;calm=calm+1 if ratio<c['normalRatio'] else 0
 if on:
  if not armed and calm>=c['normalConfirm']:armed=True
  exitrun=exitrun+1 if armed and ratio>c['ratio'] else 0
  if exitrun>=c['confirm']:on=False;exitrun=calm=held=0;peak=v
 else:
  held+=1;peak=max(peak,v)
  if (held>=c['minHold'] and v<=peak*(1-c['peakDrop'])) or calm>=c['normalConfirm']:
   on=True;armed=False;exitrun=calm=held=0
 if before!=on:vtrans.append([day,on])
 vstate.append(on)
qknown=[];vknown=[]
for day in dates:
 qi=bisect.bisect_right(qdays,day)-1;vi=bisect.bisect_left(vdays,day)-1
 qknown.append(qstate[qi] if qi>=0 and daynum(day)-daynum(qdays[qi])<=7 else None)
 vknown.append(vstate[vi] if vi>=0 and daynum(day)-daynum(vdays[vi])<=7 else None)
maxerr={k:0.0 for k in ['value','grossValue','annualReturn','mdd','fees','capitalTax','paidDividendTax','reserve','finalCash']}
stats={'accounts':0,'dailyValuations':0,'trades':0,'plans':0}; t0=time.time()
def account(row,w,fee,delay,mode):
 first,last=dateix[row['start']],dateix[row['end']]; W=sum(w); n0,n1=(100*w[0]/(1+fee*W),100*w[1]/(1+fee*W));
 q0=q1=b0=b1=0.0;cash=100.;pool=0.;fees=paid=divpaid=0.;peak=100.;mdd=0.;pending=None;requested=True;vOn=qOn=True;trades=plans=0
 for i in range(first,last+1):
  p0,p1=ps[i]
  if i>first:
   d0=q0*p0*divs[i][0]; d1=q1*p1*divs[i][1]
   q0-=d0*.2/p0;q1-=d1*.2/p1;b0+=d0*.8;b1+=d1*.8;divpaid+=(d0+d1)*.2
  else:
   q0=n0/p0;q1=n1/p1;b0=n0*(1+fee);b1=n1*(1+fee);cash-=b0+b1;fees=fee*(n0+n1);trades=2
  if pending and pending[0]==i:
   _,sell,buy=pending;pending=None
   assert buy*(1+fee)<=cash+1e-7
   if sell>1e-10:
    units=min(sell,q1);amount=units*p1;cost=b1*units/q1;f=amount*fee;tx=max(0.,amount-f-cost)*.2
    q1-=units;b1-=cost;net=amount-f-tx;cash+=net;pool+=net;fees+=f;paid+=tx;trades+=1
    if q1<1e-10:q1=b1=0.
   if buy>1e-10:
    units=buy/p1;f=buy*fee;q1+=units;b1+=buy+f;cash-=buy+f;pool-=buy+f;fees+=f;trades+=1
  assert cash>=-1e-7
  cash=max(0.,cash);m0=q0*p0;m1=q1*p1;gross=cash+m0+m1;reserve=(max(0.,m0*(1-fee)-b0)+max(0.,m1*(1-fee)-b1))*.2;value=gross-reserve
  peak=max(peak,value);mdd=min(mdd,100*(value/peak-1))
  if mode!='baseline' and pending is None:
   if qknown[i] is not None:qOn=qknown[i]
   if vknown[i] is not None:vOn=vknown[i]
   allowed=vOn if mode=='vix' else qOn if mode=='qqq' else vOn and qOn
   if allowed!=requested:
    requested=allowed;sell=q1 if not allowed else 0.;buy=max(0.,pool)/(1+fee) if allowed else 0.
    if sell>1e-10 or buy>1e-10:pending=(i+1+delay,sell,buy);plans+=1
 annual=100*((value/100)**(365.2425/(ordinals[last]-ordinals[first]))-1)
 stats['dailyValuations']+=last-first+1;stats['trades']+=trades;stats['plans']+=plans
 return dict(value=value,grossValue=gross,annualReturn=annual,mdd=mdd,fees=fees,capitalTax=paid,paidDividendTax=divpaid,reserve=reserve,finalCash=cash,tradeCount=trades,planCount=plans)
for group in expected['results']:
 w,fee,delay=group['weights'],group['fee'],group['delay']
 for stage in ['all10','all15']:
  for mode in ['hybrid','vix','qqq','baseline']:
   for row in group[stage][mode]:
    actual=account(row,w,fee,0 if mode=='baseline' else delay,mode)
    for k in maxerr:
     err=abs(actual[k]-row[k]);maxerr[k]=max(maxerr[k],err)
     assert err<1e-8,(mode,w,fee,delay,row['start'],k,actual[k],row[k])
    assert actual['tradeCount']==row['tradeCount'] and actual['planCount']==row['planCount']
    stats['accounts']+=1
out={'status':'pass','scope':'Independent Python rebuilt both QQQ/VIX states and every account from frozen original ETF/FX prices and tax fraction observations; did not import JS signals or orders. Comparisons include hybrid and both parents plus lump under all16 configurations.','hashes':{'protocol':sha(P/'protocol.json'),'evaluation':sha(P/'evaluation.json'),'python':sha(__file__),'engine':sha(B/'engine.cjs')},'counts':stats,'maxAbsError':maxerr,'sourceTransitions':{'vix':vtrans,'qqq':qtrans},'elapsedSeconds':time.time()-t0,'caveat':'Account counts include overlapping horizons and repeated stress configurations, not independent crises. This checks computation, not future efficacy.'}
(P/'independent-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
