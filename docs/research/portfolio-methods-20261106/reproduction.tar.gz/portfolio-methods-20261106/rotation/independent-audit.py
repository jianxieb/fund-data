"""Independent Python replay for frozen full-tilt champions. No JS policy import."""
import json, math, hashlib, datetime, bisect
from pathlib import Path
ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT.parent/'inputs.json').read_text())
tax_data=json.loads((ROOT.parent/'tax-inputs.json').read_text())
selection=json.loads((ROOT/'selection.json').read_text())
evaluation=json.loads((ROOT/'evaluation.json').read_text())
daily=data['daily']; dates=[r[0] for r in daily]; indices={d:i for i,d in enumerate(dates)}
fractions=[tax_data[k]['dividendEvidence']['fractions'] for k in ['us:USD','us:TQQQ']]
qqq=dict(data['proxies']['us:QQQ']['series'])
proxies=[(d,[p,qqq[d]]) for d,p in data['proxies']['us:SOXX']['series'] if d in qqq]
sources={'etf':daily,'proxy':proxies}; signals={}
for c in selection['selected']:
    rows=sources[c['source']]; ds=[r[0] for r in rows]; ratios=[]
    for d in dates:
        j=bisect.bisect_right(ds,d)-1;l=c['lookback']
        valid=j>=l and (datetime.date.fromisoformat(d)-datetime.date.fromisoformat(ds[j])).days<=7
        ratios.append((rows[j][1][0]/rows[j-l][1][0])/(rows[j][1][1]/rows[j-l][1][1]) if valid else None)
    signals[c['id']]=ratios

def account(origin,weights,c,fee=.001,tax=.2,delay=0):
    assert c is None or c['tilt']==1
    start,end=indices[origin['start']],indices[origin['end']]
    quantity=[0.,0.];basis=[0.,0.];cash=100.;initial_cash=None
    paid_cap=paid_div=fees=0.;peak=100.;mdd=0.;trades=plans=0
    pending=None;finish=False;leader=favored=None;previous_period=None
    smallest_cash=100.;path_hash=hashlib.sha256()
    def execute(asset,side,amount,price,units=None):
        nonlocal cash,paid_cap,fees,trades
        if amount<=1e-10:return
        f=amount*fee
        if side=='buy':
            quantity[asset]+=amount/price;basis[asset]+=amount+f;cash-=amount+f
        else:
            cost=basis[asset]*units/quantity[asset]
            tax_paid=max(0.,amount-f-cost)*tax
            quantity[asset]-=units;basis[asset]-=cost;cash+=amount-f-tax_paid;paid_cap+=tax_paid
            if quantity[asset]<1e-10:quantity[asset]=0.;basis[asset]=0.
        fees+=f;trades+=1
    for i in range(start,end+1):
        day,price=daily[i]
        if i>start:
            for k in range(2):
                dividend=quantity[k]*price[k]*fractions[k].get(day,0)
                charge=dividend*tax
                quantity[k]-=charge/price[k];basis[k]+=dividend-charge;paid_div+=charge
        if i==start:
            for k in range(2):execute(k,'buy',100*weights[k]/(1+fee*sum(weights)),price[k])
            initial_cash=cash
        if pending and pending['due']==i:
            order=pending;pending=None
            assert sum(order['buy'])*(1+fee)<=cash+1e-7
            for k in range(2):
                units=min(order['sell'][k],quantity[k])
                if units>0:execute(k,'sell',units*price[k],price[k],units)
            for k in range(2):execute(k,'buy',order['buy'][k],price[k])
        assert cash>=initial_cash-1e-7
        smallest_cash=min(smallest_cash,cash)
        mark=[quantity[k]*price[k] for k in range(2)]
        reserve=sum(max(0,m*(1-fee)-basis[k])*tax for k,m in enumerate(mark))
        gross=cash+sum(mark);value=gross-reserve
        peak=max(peak,value);mdd=min(mdd,100*(value/peak-1))
        if c and not pending:
            buy=[0.,0.];sell=[0.,0.];completion=False
            available=max(0.,cash-initial_cash)
            if finish:
                finish=False
                if available>1e-10 and favored is not None:
                    # Full tilt: after the losing asset's completed sale, every
                    # already-available active cash unit belongs to the winner.
                    buy[favored]=available/(1+fee);completion=True
            if not completion:
                period=(day[:4],(int(day[5:7])-1)//3) if c['cadence']=='quarter' else day[:7]
                if period!=previous_period:
                    previous_period=period;ratio=signals[c['id']][i]
                    if ratio is not None:
                        if ratio>1+c['band']:leader=0
                        elif ratio<1/(1+c['band']):leader=1
                        new_favored=(leader if c['direction']=='momentum' else 1-leader) if leader is not None else None
                        if new_favored!=favored:
                            favored=new_favored;finish=True
                            sell[1-favored]=quantity[1-favored]
                            buy[favored]=available/(1+fee)
            if sum(sell)>1e-10 or sum(buy)>1e-10:
                assert sum(buy)*(1+fee)<=cash-initial_cash+1e-7
                pending={'due':i+1+delay,'sell':sell,'buy':buy,'signalDay':day};plans+=1
                path_hash.update(json.dumps([day,sell,buy],separators=(',',':')).encode())
    years=(datetime.date.fromisoformat(origin['end'])-datetime.date.fromisoformat(origin['start'])).days/365.2425
    return {'value':value,'grossValue':gross,'annualReturn':100*((value/100)**(1/years)-1),'mdd':mdd,'fees':fees,'capitalTax':paid_cap,'paidDividendTax':paid_div,'paidTax':paid_cap+paid_div,'reserve':reserve,'finalCash':cash,'initialCash':initial_cash,'tradeCount':trades,'planCount':plans,'minimumCash':smallest_cash,'orderSHA256':path_hash.hexdigest()}

fields=['value','grossValue','annualReturn','mdd','fees','capitalTax','paidDividendTax','paidTax','reserve','finalCash','initialCash','tradeCount','planCount']
maximum={k:0 for k in fields};count=0;cases=[]
# Both champions, every four-weight 10/15-year account at default fees/tax/delay.
for group in evaluation['results']:
    if group['fee']!=.001 or group['tax']!=.2 or group['delay']!=0 or group['label']=='later35':continue
    for kind in ['rows','baseline']:
        for row in group[kind]:
            r=account(row,group['weights'],group['c'] if kind=='rows' else None)
            for field in fields:
                error=abs(r[field]-row[field]);maximum[field]=max(maximum[field],error)
                assert error<=max(1e-8,abs(row[field])*1e-10),(group['c']['id'],group['weights'],kind,row['start'],field,r[field],row[field])
            cases.append({'id':group['c']['id'],'weights':group['weights'],'kind':kind,'start':row['start'],'end':row['end'],'orderSHA256':r['orderSHA256'],'minimumCash':r['minimumCash']});count+=1
result={'passed':True,'accounts':count,'scope':'Two frozen full-tilt champions; four weights; all81 ten-year and21 fifteen-year; 0.1% fee and20% tax, normal next-close execution. Other fee/delay cells not independently replayed here. Independent implementation in Python by same research agent, not a separate unseen reviewer.','maximumAbsoluteErrors':maximum,'engineSHA256':selection['engineSHA256'],'evaluationSHA256':hashlib.sha256((ROOT/'evaluation.json').read_bytes()).hexdigest(),'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':cases}
(ROOT/'independent-audit.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
