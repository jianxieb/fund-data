'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const E=require('../engine.cjs'),{makeFeatures,leaderStep,targetShares}=require('./features.cjs');
const protocol=JSON.parse(fs.readFileSync(path.join(__dirname,'phase-protocol.json')));
const original=JSON.parse(fs.readFileSync(path.join(__dirname,'evaluation.json')));
function phaseFactory(c,phase,offset){return ({input,weights})=>{
 const features=makeFeatures(input),ordinals=new Map();let key=null,n=0;
 for(const [day] of input.daily){const k=day.slice(0,7);if(k!==key){key=k;n=0;}ordinals.set(day,n++);}
 let leader=null,favored=null,lastReviewed=null,finish=false,target=null;
 return {step(ctx){
  if(finish){finish=false;const available=Math.max(0,ctx.cash-ctx.initialCash),pool=E.sum(ctx.marks)+available;
   if(available>1e-10&&target){const gaps=target.map((v,k)=>Math.max(0,v*pool-ctx.marks[k]));if(E.sum(gaps)>0)return {sellFractions:[0,0],buyAmounts:gaps.map(v=>available/(1+ctx.fee)*v/E.sum(gaps)),reason:'rotation_cash_completion'};}
  }
  const month=ctx.day.slice(0,7),isInitial=ctx.index===ctx.first;
  if(month===lastReviewed)return null;
  if(!isInitial&&(((+ctx.day.slice(5,7)-1-phase+3)%3)!==0||ordinals.get(ctx.day)<offset))return null;
  lastReviewed=month;
  const observation=features.at(c.source,c.lookback,ctx.day);if(!observation.available)return null;
  leader=leaderStep(leader,observation.value,c.band);const next=leader===null?null:c.direction==='momentum'?leader:1-leader;
  if(next===favored)return null;favored=next;target=targetShares(weights,favored,c.tilt);finish=true;
  return {...E.stockMixOrders(ctx,target),reason:'relative_'+c.direction};
 }};
};}
const results=[];let equivalentAccounts=0;
for(const phase of protocol.phases)for(const offset of protocol.offsets)for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const label of ['later35','all10_81','all15_21']){
 const r=E.evaluate(E.periods[label],weights,phaseFactory(protocol.candidate,phase,offset),{fee:.001,tax:.2});
 if(phase===0&&offset===0){
  const prior=original.results.find(r=>r.c.id===protocol.candidate.id&&r.tax===.2&&r.fee===.001&&r.delay===0&&r.label===label&&JSON.stringify(r.weights)===JSON.stringify(weights));
  for(let i=0;i<r.rows.length;i++)for(const field of ['value','mdd','tradeCount','planCount','capitalTax','reserve','fees'])assert.equal(r.rows[i][field],prior.rows[i][field],label+'/'+weights+'/'+field);
  equivalentAccounts+=r.rows.length;
 }
 results.push({phase,offset,weights,label,...r});
}
const output={protocolSHA256:E.hash(fs.readFileSync(path.join(__dirname,'phase-protocol.json'))),codeSHA256:E.hash(fs.readFileSync(__filename)),engineSHA256:E.hash(fs.readFileSync(path.join(__dirname,'../engine.cjs'))),equivalentAccounts,results};
fs.writeFileSync(path.join(__dirname,'phase-results.json'),JSON.stringify(output)+'\n');
const compact=results.map(({rows,baseline,...r})=>r);fs.writeFileSync(path.join(__dirname,'phase-summary.json'),JSON.stringify(compact)+'\n');
console.log(JSON.stringify({groups:results.length,positive:results.filter(r=>r.summary.yearEqualCAGRpp>0).length,min:Math.min(...results.map(r=>r.summary.yearEqualCAGRpp)),max:Math.max(...results.map(r=>r.summary.yearEqualCAGRpp)),equivalentAccounts}));
