'use strict';
const {makeFeatures,calendarKey,leaderStep,targetShares}=require('./features.cjs');
// The common engine owns holdings, realised tax, dividends, fees and pending fills.
// This module can only request amounts from information available at ctx.day.
function rotationFactory(candidate,stockMixOrders){
 return ({input,weights})=>{
  const features=makeFeatures(input);
  let leader=null,favored=null,lastKey=null,finishPurchase=false,target=null;
  let sourceDay=null,stateChanges=0,missingObservations=0;
  return {step(ctx){
   // First close after completing the state-change order: sale receipts are now
   // real cash. A second order can buy with that cash, never with future receipts.
   if(finishPurchase){
    finishPurchase=false;
    const activeCash=Math.max(0,ctx.cash-ctx.initialCash),pool=ctx.marks[0]+ctx.marks[1]+activeCash;
    if(activeCash>1e-10&&target){
     const gaps=target.map((q,a)=>Math.max(0,q*pool-ctx.marks[a])),total=gaps[0]+gaps[1];
     if(total>0)return {sellFractions:[0,0],buyAmounts:gaps.map(g=>activeCash/(1+ctx.fee)*g/total),reason:'rotation_cash_completion',sourceDay,stateChanges};
    }
   }
   const key=calendarKey(ctx.day,candidate.cadence);
   if(key===lastKey)return null;
   lastKey=key;
   const obs=features.at(candidate.source,candidate.lookback,ctx.day);
   if(!obs.available){missingObservations++;return null;}
   const nextLeader=leaderStep(leader,obs.value,candidate.band);
   leader=nextLeader;
   const nextFavored=leader===null?null:candidate.direction==='momentum'?leader:1-leader;
   if(nextFavored===favored)return null;
   favored=nextFavored;sourceDay=obs.sourceDay;stateChanges++;
   target=targetShares(weights,favored,candidate.tilt);
   const orders=stockMixOrders(ctx,target);
   finishPurchase=true;
   return {...orders,reason:'relative_'+candidate.direction,sourceDay,relativeLogReturn:obs.value,targetShares:target.slice(),stateChanges};
  },diagnostics(){return {leader,favored,lastKey,stateChanges,missingObservations,targetShares:target};}};
 };
}
module.exports={rotationFactory};
