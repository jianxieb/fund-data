'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const {makeFeatures,calendarKey,leaderStep,targetShares}=require('./features.cjs');
const input=JSON.parse(fs.readFileSync(__dirname+'/../inputs.json'));
const full=makeFeatures(input),cut='2013-12-31';
const truncated={daily:input.daily.filter(([d])=>d<=cut),proxies:Object.fromEntries(Object.entries(input.proxies).map(([k,v])=>[k,{series:v.series.filter(([d])=>d<=cut)}]))};
const past=makeFeatures(truncated);
let checks=0;
for(const [day] of truncated.daily)for(const s of ['proxy','etf'])for(const l of [126,252,504]){assert.deepEqual(full.at(s,l,day),past.at(s,l,day));checks++;}
assert.equal(leaderStep(null,0,.1),null);assert.equal(leaderStep(0,0,.1),0);assert.equal(leaderStep(1,.11,.1),0);assert.equal(leaderStep(0,-.11,.1),1);
assert.deepEqual(targetShares([.2,.4],0,1),[1,0]);assert.deepEqual(targetShares([.4,.2],1,1),[0,1]);
assert.ok(Math.abs(targetShares([.2,.4],0,.5)[0]-2/3)<1e-14);
assert.equal(calendarKey('2020-03-31','quarter'),'2020Q1');assert.equal(calendarKey('2020-04-01','quarter'),'2020Q2');
assert.equal(full.at('etf',504,'2010-03-01').available,false);
assert.equal(full.at('proxy',126,'2026-12-01').available,false);
console.log(JSON.stringify({passed:true,prefixFeatureComparisons:checks,tests:['prefix equality','hysteresis boundaries','arbitrary initial weights','calendar cadence','missing warmup','stale source']}));
