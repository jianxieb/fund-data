'use strict';
const DAY=86400000;
const caches=new WeakMap();
function makeFeatures(input){
 if(caches.has(input))return caches.get(input);
 const soxx=input.proxies['us:SOXX'].series,qqq=new Map(input.proxies['us:QQQ'].series);
 const sources={proxy:soxx.filter(([d])=>qqq.has(d)).map(([d,p])=>[d,[p,qqq.get(d)]]),etf:input.daily};
 const features={};
 for(const [name,rows] of Object.entries(sources)){
  const values={};
  for(const lookback of [126,252,504])values[lookback]=rows.map(([day,p],i)=>({day,value:i<lookback?null:Math.log(p[0]/rows[i-lookback][1][0])-Math.log(p[1]/rows[i-lookback][1][1])}));
  features[name]={rows,values};
 }
 function at(source,lookback,day){
  const a=features[source].values[lookback];let l=0,r=a.length;
  while(l<r){const m=(l+r)>>1;if(a[m].day<=day)l=m+1;else r=m;}
  if(!l)return {available:false,sourceDay:null,value:null,reason:'no prior actual paired closes'};
  const row=a[l-1];
  if(Date.parse(day)-Date.parse(row.day)>7*DAY)return {available:false,sourceDay:row.day,value:null,reason:'paired source more than seven days old'};
  return {available:row.value!==null,sourceDay:row.day,value:row.value,reason:row.value===null?'insufficient real lookback':null};
 }
 const result={at,features};caches.set(input,result);return result;
}
function calendarKey(day,cadence){const month=+day.slice(5,7);return cadence==='quarter'?day.slice(0,4)+'Q'+Math.ceil(month/3):day.slice(0,7);}
function leaderStep(previous,value,band){return value>Math.log1p(band)?0:value< -Math.log1p(band)?1:previous;}
function targetShares(weights,favored,tilt){const W=weights[0]+weights[1],q=weights.map(x=>x/W);if(favored===null)return q;return q.map((v,a)=>a===favored?v+tilt*(1-v):(1-tilt)*v);}
module.exports={makeFeatures,calendarKey,leaderStep,targetShares};
