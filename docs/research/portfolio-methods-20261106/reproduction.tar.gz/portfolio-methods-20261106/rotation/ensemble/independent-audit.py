"""Independent Python signal/account replay; shared actual inputs, no JS import."""
import json,math,datetime,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent;COMMON=ROOT.parent.parent
data=json.loads((COMMON/'inputs.json').read_text());taxdata=json.loads((COMMON/'tax-inputs.json').read_text())
evaluation=json.loads((ROOT/'evaluation.json').read_text());dates=[d for d,p in data['daily']];prices=[p for d,p in data['daily']];ix={d:i for i,d in enumerate(dates)}
fractions=[[taxdata[k]['dividendEvidence']['fractions'].get(d,0.) for d in dates] for k in ['us:USD','us:TQQQ']]
ratios=[None if i<504 else (p[0]/prices[i-504][0])/(p[1]/prices[i-504][1]) for i,p in enumerate(prices)]
month_keys=[d[:7] for d in dates];phases=[(int(d[5:7])-1)%3 for d in dates]
ordinals=[];previous=None;n=0
for key in month_keys:
    if key!=previous:previous=key;n=0
    ordinals.append(n);n+=1
EPS=1e-10
def replay(row,weights,fee,tax,delay,policy=True,offset=0):
    first,last=ix[row['start']],ix[row['end']];q=[0.,0.];basis=[0.,0.];cash=100.;initial_cash=0.
    paid_cap=paid_div=fees=0.;trade_count=plan_count=0;peak=100.;mdd=0.;pending=None
    original=[w/sum(weights) for w in weights];target=original[:];leaders=[None]*3;last_review=None;completion=False
    max_stock=max_leverage=total_stock=0.;minimum_cash=100.
    def trade(a,side,amount,price,qty=0.):
        nonlocal cash,paid_cap,fees,trade_count
        if amount<=EPS:return
        charge=fee*amount
        if side=='B':q[a]+=amount/price;basis[a]+=amount+charge;cash-=amount+charge
        else:
            removed=basis[a]*qty/q[a];paid=max(0.,amount-charge-removed)*tax
            q[a]-=qty;basis[a]-=removed;cash+=amount-charge-paid;paid_cap+=paid
            if q[a]<EPS:q[a]=0.;basis[a]=0.
        fees+=charge;trade_count+=1
    def observe(p):
        nonlocal max_stock,max_leverage
        marks=[q[k]*p[k] for k in range(2)];gross=cash+sum(marks)
        if gross>0:max_stock=max(max_stock,sum(marks)/gross);max_leverage=max(max_leverage,(2*marks[0]+3*marks[1])/gross)
    for i in range(first,last+1):
        p=prices[i]
        if i>first:
            for k in range(2):
                dividend=q[k]*p[k]*fractions[k][i];charge=dividend*tax
                q[k]-=charge/p[k];basis[k]+=dividend-charge;paid_div+=charge
        observe(p)
        if i==first:
            for k in range(2):trade(k,'B',100*weights[k]/(1+fee*sum(weights)),p[k])
            initial_cash=cash
        if pending and pending[0]==i:
            _,sell,buy=pending;pending=None
            assert sum(buy)*(1+fee)<=cash+1e-7
            for k in range(2):
                qty=min(sell[k],q[k])
                if qty>EPS:trade(k,'S',qty*p[k],p[k],qty)
            for k in range(2):trade(k,'B',buy[k],p[k])
        assert cash>=initial_cash-1e-7
        minimum_cash=min(minimum_cash,cash);observe(p)
        marks=[q[k]*p[k] for k in range(2)];gross=cash+sum(marks);reserve=sum(max(0.,m*(1-fee)-basis[k])*tax for k,m in enumerate(marks));value=gross-reserve
        peak=max(peak,value);mdd=min(mdd,100*(value/peak-1));total_stock+=sum(marks)/gross
        if policy and pending is None:
            available=max(0.,cash-initial_cash);active=sum(marks)+available;sell=[0.,0.];buy=[0.,0.];did_complete=False
            if completion:
                completion=False
                if available>EPS:
                    gaps=[max(0.,target[k]*active-marks[k]) for k in range(2)];gap_total=sum(gaps)
                    if gap_total>0:
                        buy=[available/(1+fee)*gap/gap_total for gap in gaps];did_complete=True
            if not did_complete and month_keys[i]!=last_review and ordinals[i]>=offset:
                last_review=month_keys[i];ratio=ratios[i]
                if ratio is not None:
                    a=phases[i]
                    if ratio>1.25:leaders[a]=0
                    elif ratio<.8:leaders[a]=1
                    desired=[sum(original[k] if leader is None else float(leader==k) for leader in leaders)/3 for k in range(2)]
                    if any(abs(desired[k]-target[k])>=1e-12 for k in range(2)):
                        target=desired;completion=True
                        target_value=[w*active for w in target];gaps=[max(0.,target_value[k]-marks[k]) for k in range(2)]
                        sell=[q[k]*(marks[k]-target_value[k])/marks[k] if marks[k]>target_value[k]+EPS else 0. for k in range(2)]
                        gap_total=sum(gaps);budget=min(available/(1+fee),gap_total/(1+fee))
                        if gap_total>EPS:buy=[budget*g/gap_total for g in gaps]
            if sum(sell)>EPS or sum(buy)>EPS:
                assert sum(buy)*(1+fee)<=cash-initial_cash+1e-7
                pending=(i+1+delay,sell,buy);plan_count+=1
    years=(datetime.date.fromisoformat(row['end'])-datetime.date.fromisoformat(row['start'])).days/365.2425
    return {'value':value,'grossValue':gross,'annualReturn':100*((value/100)**(1/years)-1),'mdd':mdd,'fees':fees,'capitalTax':paid_cap,'paidDividendTax':paid_div,'paidTax':paid_cap+paid_div,'reserve':reserve,'initialCash':initial_cash,'finalCash':cash,'tradeCount':trade_count,'planCount':plan_count,'maxStockFraction':max_stock,'meanStockFraction':total_stock/(last-first+1),'maxDailyLeverageExposure':max_leverage,'minimumCash':minimum_cash}

fields=['value','grossValue','annualReturn','mdd','fees','capitalTax','paidDividendTax','paidTax','reserve','initialCash','finalCash','tradeCount','planCount','maxStockFraction','meanStockFraction','maxDailyLeverageExposure']
errors={k:0. for k in fields};cache={};comparisons=0;failures=[]
for group in evaluation['results']:
    if group['label']=='later35':continue
    for kind in ['rows','baseline']:
        for row in group[kind]:
            key=(tuple(group['weights']),group['fee'],group['tax'],group['delay'] if kind=='rows' else 0,kind,row['start'],row['end'])
            if key not in cache:cache[key]=replay(row,group['weights'],group['fee'],group['tax'],group['delay'] if kind=='rows' else 0,kind=='rows')
            result=cache[key]
            for field in fields:
                error=abs(result[field]-row[field]);errors[field]=max(errors[field],error)
                assert error<=max(1e-8,abs(row[field])*1e-10),(key,field,result[field],row[field])
            comparisons+=1
result={'passed':True,'uniqueAccountReplays':len(cache),'accountComparisons':comparisons,'scope':'All four weights, both fees, both taxes, both next-close delays and all81 ten-year/all21 fifteen-year accounts. One actual account/basis per asset. Same-agent independent Python implementation, not separate reviewer or unseen data.','maxAbsoluteError':errors,'engineSHA256':evaluation['engineSHA256'],'evaluationSHA256':hashlib.sha256((ROOT/'evaluation.json').read_bytes()).hexdigest(),'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'allPermanentCashChecksPassed':True}
(ROOT/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
