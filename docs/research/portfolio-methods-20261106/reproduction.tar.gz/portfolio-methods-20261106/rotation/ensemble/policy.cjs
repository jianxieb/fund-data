'use strict';
const {makeFeatures,leaderStep}=require('../features.cjs');
function ensembleFactory(stockMixOrders,offset=0){return ({input,weights})=>{
 const features=makeFeatures(input),W=weights[0]+weights[1],original=weights.map(w=>w/W),leaders=[null,null,null],ordinals=new Map();
 let month=null,ordinal=0;for(const [day] of input.daily){if(day.slice(0,7)!==month){month=day.slice(0,7);ordinal=0;}ordinals.set(day,ordinal++);}
 let target=original.slice(),lastReview=null,finish=false,changes=0;
 return {step(ctx){
  if(finish){finish=false;const available=Math.max(0,ctx.cash-ctx.initialCash),pool=ctx.marks[0]+ctx.marks[1]+available;
   if(available>1e-10){const gaps=target.map((v,k)=>Math.max(0,v*pool-ctx.marks[k])),total=gaps[0]+gaps[1];
    if(total>0)return {sellFractions:[0,0],buyAmounts:gaps.map(v=>available/(1+ctx.fee)*v/total),reason:'three_phase_cash_completion'};
   }
  }
  const currentMonth=ctx.day.slice(0,7);if(currentMonth===lastReview||ordinals.get(ctx.day)<offset)return null;
  lastReview=currentMonth;const observation=features.at('etf',504,ctx.day);if(!observation.available)return null;
  const phase=(+ctx.day.slice(5,7)-1)%3;
  leaders[phase]=leaderStep(leaders[phase],observation.value,.25);
  const next=[0,1].map(asset=>leaders.reduce((total,leader)=>total+(leader===null?original[asset]:leader===asset?1:0),0)/3);
  if(next.every((v,k)=>Math.abs(v-target[k])<1e-12))return null;
  target=next;finish=true;changes++;
  return {...stockMixOrders(ctx,target),reason:'three_phase_target_change',targetShares:target.slice(),leaders:leaders.slice(),phase,sourceDay:observation.sourceDay};
 },diagnostics(){return {leaders:leaders.slice(),target:target.slice(),changes};}};
};}
module.exports={ensembleFactory};
