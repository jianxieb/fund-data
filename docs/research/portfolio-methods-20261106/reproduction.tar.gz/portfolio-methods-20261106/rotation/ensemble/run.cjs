'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const E=require('../../engine.cjs'),{ensembleFactory}=require('./policy.cjs'),{rotationFactory}=require('../policy.cjs');
const root=__dirname,read=n=>JSON.parse(fs.readFileSync(path.join(root,n))),save=(n,x)=>fs.writeFileSync(path.join(root,n),JSON.stringify(x)+'\n'),hash=n=>E.hash(fs.readFileSync(path.join(root,n)));
const protocol=read('protocol.json'),parent=read('../selection.json').selected.find(c=>c.direction==='momentum');
function binding(){return {protocolSHA256:hash('protocol.json'),engineSHA256:hash('../../engine.cjs'),policySHA256:hash('policy.cjs'),featureSHA256:hash('../features.cjs'),runnerSHA256:hash('run.cjs')};}
function run(origins,weights,opts,offset=0){
 const r=E.evaluate(origins,weights,ensembleFactory(E.stockMixOrders,offset),opts);
 r.summary.maxStockFraction=Math.max(...r.rows.map(r=>r.maxStockFraction));r.summary.maxDailyLeverageExposure=Math.max(...r.rows.map(r=>r.maxDailyLeverageExposure));
 const parentRows=origins.map(o=>E.account(o,weights,rotationFactory(parent,E.stockMixOrders),opts));
 return {...r,vsParent:E.compare(r.rows,parentRows),parentRows};
}
const mode=process.argv[2];
if(mode==='development'){
 if(fs.existsSync(path.join(root,'development.json')))throw Error('Refusing overwrite');
 save('run-freeze.json',{utc:new Date().toISOString(),...binding()});
 const pretax=run(E.periods.development28,[.3,.3],{fee:.001,tax:0}),taxed=run(E.periods.development28,[.3,.3],{fee:.001,tax:.2});
 save('development.json',{...binding(),pretax,taxed});
 save('selection.json',{utc:new Date().toISOString(),...binding(),developmentSHA256:hash('development.json'),candidate:protocol.candidate,score:Math.min(pretax.summary.yearEqualCAGRpp,taxed.summary.yearEqualCAGRpp),pretax:pretax.summary,taxed:taxed.summary,vsParentPretax:pretax.vsParent,vsParentTaxed:taxed.vsParent,selection:protocol.selection});
 console.log(JSON.stringify(read('selection.json'),null,2));
}else if(mode==='evaluate'){
 if(fs.existsSync(path.join(root,'evaluation.json')))throw Error('Refusing overwrite');
 const selected=read('selection.json');assert.equal(selected.developmentSHA256,hash('development.json'));for(const [k,v] of Object.entries(binding()))assert.equal(selected[k],v,k);
 const results=[];
 for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const tax of [0,.2])for(const fee of [.001,.005])for(const delay of [0,1])for(const label of ['later35','all10_81','all15_21'])results.push({weights,tax,fee,delay,label,...run(E.periods[label],weights,{tax,fee,delay})});
 save('evaluation.json',{...binding(),selectionSHA256:hash('selection.json'),results});save('evaluation-summary.json',results.map(({rows,baseline,parentRows,...r})=>r));
 const diagnostics=[];let equivalent=0;
 for(const offset of [0,1,5])for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const label of ['later35','all10_81','all15_21']){
  const r=run(E.periods[label],weights,{fee:.001,tax:.2},offset);
  if(offset===0){const main=results.find(r=>r.label===label&&r.tax===.2&&r.fee===.001&&r.delay===0&&JSON.stringify(r.weights)===JSON.stringify(weights));assert.deepEqual(r.rows,main.rows);equivalent+=r.rows.length;}
  diagnostics.push({offset,weights,label,...r});
 }
 save('timing-diagnostics.json',{...binding(),equivalentAccounts:equivalent,results:diagnostics});save('timing-summary.json',diagnostics.map(({rows,baseline,parentRows,...r})=>r));
 console.log(JSON.stringify({groups:results.length,positive:results.filter(r=>r.summary.yearEqualCAGRpp>0).length,min:Math.min(...results.map(r=>r.summary.yearEqualCAGRpp)),timingGroups:diagnostics.length,timingPositive:diagnostics.filter(r=>r.summary.yearEqualCAGRpp>0).length,timingMin:Math.min(...diagnostics.map(r=>r.summary.yearEqualCAGRpp)),equivalent}));
}else throw Error('development or evaluate');
