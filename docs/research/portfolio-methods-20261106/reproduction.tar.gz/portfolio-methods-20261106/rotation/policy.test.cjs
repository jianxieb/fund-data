'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs');
const E=require('../engine.cjs'),{rotationFactory}=require('./policy.cjs');
const protocol=JSON.parse(fs.readFileSync(__dirname+'/protocol.json'));
const c=protocol.grid.find(c=>c.source==='proxy'&&c.direction==='momentum'&&c.lookback===126&&c.tilt===1&&c.cadence==='month');
const origin={start:'2011-09-01',end:'2013-12-31',years:2},options={fee:.001,tax:.2,trace:true};
const r=E.account(origin,[.3,.3],rotationFactory(c,E.stockMixOrders),options);
assert(r.plans.length>0);
for(const p of r.plans){assert(p.signalDay<p.dueDay);assert(E.sum(p.buyAmounts)*(1+options.fee)<=p.knownCash-r.initialCash+1e-7);}
for(const p of r.curve)assert(p.cash>=r.initialCash-1e-7,'Permanent cash was spent');
const modified=structuredClone(E.input);for(const row of modified.daily)if(row[0]>'2013-12-31'){row[1][0]*=7;row[1][1]*=.3;}
for(const proxy of Object.values(modified.proxies))for(const row of proxy.series)if(row[0]>'2013-12-31')row[1]*=9;
const r2=E.account(origin,[.3,.3],rotationFactory(c,E.stockMixOrders),{...options,env:E.environment(modified)});
assert.deepEqual(r,r2);
const d=E.account(origin,[.5,.5],rotationFactory(c,E.stockMixOrders),{...options,delay:1});
assert(d.initialCash<1e-10);for(const p of d.plans)assert.equal(p.dueIndex-p.signalIndex,2);
console.log(JSON.stringify({passed:true,plans:r.plans.length,checks:['permanent cash preserved','only known active cash spent','strict subsequent common execution','future price perturbation equality','50/50 and second-close delay']}));
