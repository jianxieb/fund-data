'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const E=require('../engine.cjs'),{rotationFactory}=require('./policy.cjs');
const root=__dirname,read=n=>JSON.parse(fs.readFileSync(path.join(root,n))),save=(n,x)=>fs.writeFileSync(path.join(root,n),JSON.stringify(x)+'\n');
const hash=n=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,n))).digest('hex');
const protocol=read('protocol.json');
function evaluate(origins,weights,candidate,options){
 const r=E.evaluate(origins,weights,candidate?rotationFactory(candidate,E.stockMixOrders):null,options);
 r.summary.maxStockFraction=Math.max(...r.rows.map(x=>x.maxStockFraction));
 r.summary.baselineMaxStockFraction=Math.max(...r.baseline.map(x=>x.maxStockFraction));
 r.summary.maxDailyLeverageExposure=Math.max(...r.rows.map(x=>x.maxDailyLeverageExposure));
 r.summary.baselineMaxDailyLeverageExposure=Math.max(...r.baseline.map(x=>x.maxDailyLeverageExposure));
 r.summary.medianPaidCapitalTax=E.median(r.rows.map(x=>x.capitalTax));
 r.summary.medianPaidDividendTax=E.median(r.rows.map(x=>x.paidDividendTax));
 r.summary.medianReservedTax=E.median(r.rows.map(x=>x.reserve));
 return r;
}
function provenance(){return {protocolSHA256:hash('protocol.json'),engineSHA256:hash('../engine.cjs'),runnerSHA256:hash('run.cjs'),policySHA256:hash('policy.cjs'),featuresSHA256:hash('features.cjs'),inputsSHA256:hash('../inputs.json'),taxInputsSHA256:hash('../tax-inputs.json')};}
const command=process.argv[2];
if(command==='development'){
 if(fs.existsSync(path.join(root,'development.json')))throw Error('Refusing overwrite frozen development');
 save('run-freeze.json',{utc:new Date().toISOString(),...provenance()});
 const results=[];
 for(const [i,c] of protocol.grid.entries()){
  const pretax=evaluate(E.periods.development28,[.3,.3],c,{fee:.001,tax:0}),taxed=evaluate(E.periods.development28,[.3,.3],c,{fee:.001,tax:.2});
  const score=Math.min(pretax.summary.yearEqualCAGRpp,taxed.summary.yearEqualCAGRpp);
  results.push({c,score,pretax,taxed});
  if((i+1)%12===0)console.log(JSON.stringify({complete:i+1,total:protocol.grid.length,current:c.id,score}));
 }
 save('development.json',{...provenance(),results});
 const champions=['momentum','reversal'].map(direction=>results.filter(r=>r.c.direction===direction).sort((a,b)=>b.score-a.score||a.taxed.summary.medianTradeCount-b.taxed.summary.medianTradeCount||a.c.id.localeCompare(b.c.id))[0]);
 const selection={utc:new Date().toISOString(),...provenance(),developmentSHA256:hash('development.json'),champions:champions.map(r=>({c:r.c,score:r.score,pretax:r.pretax.summary,taxed:r.taxed.summary})),selected:champions.filter(r=>r.score>0).map(r=>r.c),reason:protocol.selection};
 save('selection.json',selection);console.log(JSON.stringify(selection,null,2));
}else if(command==='evaluate'){
 if(fs.existsSync(path.join(root,'evaluation.json')))throw Error('Refusing overwrite frozen evaluation');
 const selection=read('selection.json');if(selection.developmentSHA256!==hash('development.json'))throw Error('development hash changed');
 for(const [key,value] of Object.entries(provenance()))if(selection[key]!==value)throw Error(key+' changed after selection');
 const results=[];
 for(const c of selection.selected)for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const tax of [0,.2])for(const fee of [.001,.005])for(const delay of [0,1]){
  for(const label of ['later35','all10_81','all15_21']){
   results.push({c,weights,tax,fee,delay,label,...evaluate(E.periods[label],weights,c,{fee,tax,delay})});
  }
  console.log(JSON.stringify({complete:results.length,c:c.id,weights,tax,fee,delay}));
 }
 save('evaluation.json',{...provenance(),selectionSHA256:hash('selection.json'),results});
 const compact=results.map(({rows,baseline,...r})=>r);save('evaluation-summary.json',compact);
 const controls=[];
 for(const c of selection.selected)for(const weights of [[.3,.3],[.2,.4],[.4,.2],[.5,.5]])for(const label of ['later35','all10_81','all15_21']){
  const rotation=evaluate(E.periods[label],weights,c,{fee:.001,tax:.2});
  for(const favored of [0,1]){
   const W=E.sum(weights),q=weights.map(w=>w/W),sw=q.map((w,a)=>W*(a===favored?w+c.tilt*(1-w):(1-c.tilt)*w));
   const baseline=E.periods[label].map(o=>E.account(o,sw,null,{fee:.001,tax:.2}));
   controls.push({c,weights,staticWeights:sw,favored,label,summary:E.compare(rotation.rows,baseline),rotation:rotation.rows,staticBaseline:baseline});
  }
 }
 save('static-controls.json',{...provenance(),results:controls});
 console.log(JSON.stringify({selected:selection.selected.length,evaluationGroups:results.length,positiveGroups:results.filter(r=>r.summary.yearEqualCAGRpp>0).length,zeroGroups:results.filter(r=>Math.abs(r.summary.yearEqualCAGRpp)<1e-9).length,negativeGroups:results.filter(r=>r.summary.yearEqualCAGRpp<0).length,staticControlGroups:controls.length}));
}else throw Error('Use development or evaluate');
module.exports={evaluate};
