from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E
import json,hashlib
ROOT=Path(__file__).parent.parent; OUT=Path(__file__).parent
REF=Path('/Users/ajin/Documents/长衡研究报告/2026-11-05/USD与TQQQ长期投入方法对照报告.docx')
load=lambda p:json.loads((ROOT/p).read_text())
S=load('delivery/summary.json'); G=S['groups'];V=load('delivery/volatility-handoff.json');H=load('hybrid/summary.json')
NS='http://schemas.openxmlformats.org/wordprocessingml/2006/main';ns={'w':NS};q=lambda t:'{'+NS+'}'+t
fields=[];table_records=[];plain=[]
def cell(method,label='all10_81',weights=[.3,.3],fee=.001,delay=0,tax=.2):
 return next(g for g in G if g['method']==method and g['label']==label and g['weights']==weights and g['fee']==fee and g['delay']==delay and g['tax']==tax)
def num(value,places=2,signed=False,unit='',source=''):
 text=(('+' if signed and value>0 else '')+f'{value:.{places}f}'+unit)
 fields.append(dict(value=value,rendered=text,source=source));return text
def f(g,k='yearEqualCAGRpp',places=2,signed=False,unit=''):
 return num(g['summary'][k],places,signed,unit,f"{g['source']} {g['method']} {g['weights']} fee{g['fee']} tax{g['tax']} delay{g['delay']} {g['label']} {k}")
def pp(g):return f(g,signed=True)
def wtl(g):
 s=g['summary'];return f"{s['wins']} / {s['ties']} / {s['losses']}"
with ZipFile(REF) as z:parts={n:z.read(n) for n in z.namelist()}
doc=E.fromstring(parts['word/document.xml']);body=doc.find('w:body',ns);sect=deepcopy(body.find('w:sectPr',ns));body.clear()
def el(tag,attrs=None,parent=None):
 x=E.Element(q(tag))
 for k,v in (attrs or {}).items():x.set(q(k),str(v))
 if parent is not None:parent.append(x)
 return x
def para(text='',style=None,kind=None,parent=None):
 p=el('p',parent=parent if parent is not None else body);pr=el('pPr',parent=p)
 if style:el('pStyle',{'val':style},pr)
 if kind=='meta':el('spacing',{'after':120},pr)
 if kind=='note':el('spacing',{'after':140,'line':300,'lineRule':'exact'},pr)
 r=el('r',parent=p);rp=el('rPr',parent=r);el('rFonts',{'ascii':'Arial','hAnsi':'Arial','eastAsia':'Arial Unicode MS'},rp)
 if kind in ('meta','note'):
  el('sz',{'val':18 if kind=='meta' else 19},rp);el('color',{'val':'44505B'},rp)
  if kind=='meta':el('b',parent=rp)
 t=el('t',parent=r);t.text=text;t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');plain.append(text)
 return p
def h(text):para(text,'Heading2')
def p(text):para(text)
def note(text):para(text,kind='note')
def page(meta,title,first=False):
 if not first:
  x=el('p',parent=body);pr=el('pPr',parent=x);el('spacing',{'after':0,'before':0,'line':20,'lineRule':'exact'},pr);r=el('r',parent=x);el('br',{'type':'page'},r)
 para('长衡研究  /  2026.11.06  /  '+meta,kind='meta');para(title,'Title' if first else 'Heading1')
def table(headers,rows,widths=None):
 widths=widths or [9524//len(headers)]*len(headers);widths[-1]=9524-sum(widths[:-1])
 tbl=el('tbl',parent=body);tp=el('tblPr',parent=tbl);el('tblW',{'w':9524,'type':'dxa'},tp);el('tblLayout',{'type':'fixed'},tp)
 borders=el('tblBorders',parent=tp)
 for edge in ['top','left','bottom','right','insideH','insideV']:el(edge,{'val':'single','sz':5,'color':'D9D9D9'},borders)
 margin=el('tblCellMar',parent=tp)
 for edge,v in [('top',90),('bottom',90),('left',110),('right',110)]:el(edge,{'w':v,'type':'dxa'},margin)
 grid=el('tblGrid',parent=tbl)
 for width in widths:el('gridCol',{'w':width},grid)
 for rowid,row in enumerate([headers]+rows):
  tr=el('tr',parent=tbl);trpr=el('trPr',parent=tr);el('cantSplit',parent=trpr)
  if rowid==0:el('tblHeader',parent=trpr)
  for i,text in enumerate(row):
   tc=el('tc',parent=tr);tcp=el('tcPr',parent=tc);el('tcW',{'w':widths[i],'type':'dxa'},tcp);el('vAlign',{'val':'center'},tcp)
   el('shd',{'fill':'304F63' if rowid==0 else ('F4F6F7' if rowid%2==0 else 'FFFFFF')},tcp)
   pp=el('p',parent=tc);pr=el('pPr',parent=pp);el('spacing',{'before':0,'after':0,'line':280,'lineRule':'exact'},pr);el('jc',{'val':'left' if i==0 or rowid==0 else 'right'},pr)
   rr=el('r',parent=pp);rp=el('rPr',parent=rr);el('rFonts',{'ascii':'Arial','hAnsi':'Arial','eastAsia':'Arial Unicode MS'},rp);el('sz',{'val':20},rp)
   if rowid==0:el('b',parent=rp);el('color',{'val':'FFFFFF'},rp)
   tt=el('t',parent=rr);tt.text=str(text);plain.append(str(text))
 table_records.append({'headers':headers,'rows':rows})
 para('',kind='note')
# 1
page('研究结论','USD 与 TQQQ 长期调仓方法对照报告',True)
p('本轮找到三种在默认组合的真实 ETF 十年、十五年历史中跑赢一次性投入的方法。它们持续改变持仓，不是一次性的买点评分，也不是把固定定投日期换一下。比较使用同一笔本金、相同初始权重和完整税费。')
note('人民币口径；默认 USD 30% / TQQQ 30% / 现金 40%；每侧交易费 0.10%；资本利得及股息税各 20%。下表为相对一次性投入的年化收益差，单位为百分点；胜 / 平 / 负按配对起点计数。')
rows=[]
for m,n in [('vix','VIX恐慌恢复调仓'),('rotation','三批相对强弱轮动'),('hybrid','双重风险门调仓')]:
 for lab,yr in [('all10_81','十年'),('all15_21','十五年')]:
  g=cell(m,lab);rows.append([n,yr,pp(g),wtl(g),f(g,'medianWealthRelativePct',signed=True,unit='%')])
table(['方法','持有期','年化差','胜 / 平 / 负','终值差中位数'],rows,[2550,1000,1400,2074,2500])
h('三种方法的收益来源不同')
p('VIX 方法在恐慌持续后退出 TQQQ，恐慌降温后买回；三批轮动把股票资金转向长期相对更强的 ETF；双风险方法合并 VIX 恐慌和 QQQ 深熊退出，减少两个不同下跌阶段的暴露。')
h('优先比较双风险  同时保留风险差异')
p('默认组合中，双风险方法的十年收益增量最大，回撤也较小。轮动的十五年收益增量最大，但回撤更深，且 40% USD / 20% TQQQ 的后段样本失败。三种方法均不能据此承诺未来优于一次性投入。')
note('81 个十年窗口、21 个十五年窗口高度重叠。VIX 中心规则只有 2020 年一个完整退出回归事件；双风险再加入 2022 年深熊。有效市场事件远少于窗口数量。')
#2
page('方法一','VIX 恐慌恢复调仓')
p('保持 USD 和原始现金不动，只调整 TQQQ。VIX / VIX3M 大于 1.10，连续 10 个有配对数据的交易日后退出。退出至少 5 个配对观测后，VIX 较退出以来最高值回落 30%，或期限比低于 1 连续 5 次，即买回。回归后须再次正常化，才重新接受退出信号。')
note('VIX 与 VIX3M 分别反映标普 500 期权的约 30 天和 3 个月隐含波动，不是 QQQ 估值，也不是 VIX 期货价差。[1] 使用严格早于决策日、不超过 7 天的同日配对值。')
table(['样本','年化差','胜 / 平 / 负','回撤中位数'],[[n,pp(cell('vix',l)),wtl(cell('vix',l)),f(cell('vix',l),'medianMDD',unit='%')] for n,l in [('后段十年 35 窗','later35'),('全部十年 81 窗','all10_81'),('全部十五年 21 窗','all15_21')]], [3100,1600,2400,2424])
h('实际交易集中于 2020 年')
table(['动作','来源收盘','决策收盘','成交收盘'],[['退出 TQQQ','2020-03-06','2020-03-09','2020-03-10'],['买回 TQQQ','2020-03-30','2020-03-31','2020-04-01']],[2370,2380,2380,2394])
p('这条规则没有在 2022 年触发中心 VIX 退出。它保留了大部分长期上涨，却避开了 2020 年恐慌过程的一段下跌；“十年 80 胜”主要反复包含同一事件，并不是经历了 80 次独立危机。')
h('交易压力通过  参数压力并不全面通过')
p('四种起始权重、两档费用、两档成交延迟的 48 个税后样本格平均增量均为正。但 27 个相邻参数中，十五年只有 13 个为正；把确认期从 10 日改为 15 日也可能转负。中心值有历史依据，参数稳定性仍有限。')
#3
page('方法二','三批相对强弱轮动')
p('把原有股票资金分成三份信号目标，每份每季度检查一次，三份分别在不同月份更新；只使用一个实际账户。每月第一个共同收盘，比较两只实际 ETF 过去 504 个共同交易日的增长倍数。USD 相对 TQQQ 高出 25% 时，该份目标转向 USD；反向超过同一门槛时转向 TQQQ；中间区域保留原方向。')
p('三份目标取平均，目标改变才调仓。没有形成有效方向的份额沿用用户初始股票比例。原始未投入现金保留，股票卖出净回款只在股票资金内轮换；不能用尚未到账的卖出款预先买入。')
table(['样本','年化差','胜 / 平 / 负','回撤中位数'],[[n,pp(cell('rotation',l)),wtl(cell('rotation',l)),f(cell('rotation',l),'medianMDD',unit='%')] for n,l in [('后段十年 35 窗','later35'),('全部十年 81 窗','all10_81'),('全部十五年 21 窗','all15_21')]], [3100,1600,2400,2424])
h('明确的失败条件')
g=cell('rotation','later35',[.4,.2]);p('当初始权重为 USD 40% / TQQQ 20% / 现金 40% 时，后段 35 个十年起点的税后年化差为 '+pp(g)+' 个百分点。这个权重下，手续费提高或延迟增加的同一后段比较仍为负。不能把默认组合结果推广为任意权重都赢。')
h('分批降低了日历依赖  也牺牲了部分收益')
p('原单一季度锚点方案在默认组合中的历史收益更高，但移到另一季度月份会翻负。三批规则是在看到这一失败后提出的修复探索，不能再把后段称为未见过的独立验证。默认组合把月初检查偏移 0、1、5 个共同交易日，三个期限样本的平均增量仍为正。')
note('信号来自 USD 与 TQQQ 的实际复权价格；原候选网格也检验过 SOXX / QQQ 底层代理。SOXX 是行业 ETF，不能替代标普、纳斯达克或道琼斯指数的身份。')
#4
page('方法三','双重风险门调仓')
p('只在 VIX 状态允许持有、且 QQQ 深熊状态也允许持有时保留 TQQQ。任一条件要求退出，就转为该资产专属现金；两个条件都恢复后买回。USD 和原始现金保持原有路径，不借款、不追加本金。')
p('QQQ 规则固定为：实际 QQQ 复权收盘低于 200 日均线，且距 252 日最高收盘回撤至少 20%，两个条件同时连续满足 20 日才退出；高于同一均线连续 3 日才回归。未使用 TQQQ 自身价格替代底层 QQQ。')
table(['样本','相对一次性','相对 VIX','相对 QQQ'],[[n,num(H['default'][k]['hybridVsLump']['yearEqualCAGRpp'],signed=True),num(H['default'][k]['hybridVsVix']['yearEqualCAGRpp'],signed=True),num(H['default'][k]['hybridVsQqq']['yearEqualCAGRpp'],signed=True)] for n,k in [('后段十年 35 窗','later35'),('全部十年 81 窗','all10'),('全部十五年 21 窗','all15')]], [3300,2070,2070,2084])
h('两个实际事件共同贡献')
table(['风险事件','退出成交','买回成交','触发来源'],[['2020 恐慌','2020-03-10','2020-04-01','VIX / VIX3M'],['2022 深熊','2022-06-03','2023-02-03','实际 QQQ']],[2200,2400,2400,2524])
p('默认十年回撤中位数为 '+f(cell('hybrid'),'medianMDD',unit='%')+'，同起点一次性投入为 '+f(cell('hybrid'),'baselineMedianMDD',unit='%')+'。这说明新增收益并非只靠提高整体股票暴露，但仍然经历了严重回撤。')
note('16 个税后权重／费用／延迟配置，在十年和十五年平均结果上均超过一次性及两个父规则。逐起点比较并非全胜：默认十年对 VIX 为 52 胜、28 平、1 负，最差年化差约 -0.41 个百分点。本轮双风险只运行 20% 税情景。')
#5
page('权重与交易压力','满仓和不同持仓比例的结果')
note('表中均为资本利得及股息各 20% 税后年化差，单位为百分点。标准：每侧费 0.10%，下一共同收盘成交。压力：每侧费 0.50%，再延迟一个共同交易日。权重顺序为 USD / TQQQ，剩余为现金。')
rows=[]
for m,n in [('vix','VIX'),('rotation','三批轮动'),('hybrid','双风险')]:
 for w in [[.3,.3],[.2,.4],[.4,.2],[.5,.5]]:
  rows.append([n,f'{int(w[0]*100)} / {int(w[1]*100)}',pp(cell(m,'all10_81',w)),pp(cell(m,'all15_21',w)),pp(cell(m,'all10_81',w,.005,1)),pp(cell(m,'all15_21',w,.005,1))])
table(['方法','股票权重','标准十年','标准十五年','压力十年','压力十五年'],rows,[1650,1500,1500,1710,1500,1664])
h('50 / 50 满仓仍有历史增量')
p('三个方法在没有初始闲置现金的 50 / 50 组合中仍跑赢对应一次性投入，说明收益并非来自悄悄动用额外现金。轮动会改变两只 ETF 的比例；两种退出方法通过卖出形成待回归资金。')
h('汇总范围必须一起看')
p('这张表展示全部起点的十年和十五年结果。三批轮动的 40 / 20 后段 35 窗失败仍然存在，不能因为全样本为正就略去。VIX 和轮动另有零税比较；双风险未扩展到零税，报告不补造未运行的格子。')
#6
page('稳健性边界','参数和日历位置能改变结论')
h('VIX 邻域')
nh=load('volatility/neighborhood-summary.json')['overview']; nr=[]
for label,title in [('later35','后段十年'),('all10_81','全部十年'),('all15_21','全部十五年')]:
 z=next(x for x in nh if x['weights']==[.3,.3] and x['label']==label);nr.append([title,f"{z['positive']} / {z['negative']}",num(z['min'],signed=True,source='volatility/neighborhood-summary.json '+label+' min'),num(z['median'],signed=True,source='volatility/neighborhood-summary.json '+label+' median')])
table(['样本','27 格正 / 负','最低年化差','中位年化差'],nr,[3000,2200,2160,2164])
p('27 格邻域全部保留，不按后段挑选新中心；其中 3 组与初始网格重复，24 组为新增参数诊断。将邻域平均形成的新规则也已检验，但在费用、延迟或权重压力下失败，没有作为第四个成功方法发布。')
h('轮动日期')
tm=load('rotation/ensemble/timing-summary.json');tr=[]
for off,title in [(0,'三批 月初'),(1,'三批 偏移 1 日'),(5,'三批 偏移 5 日')]:
 tr.append([title]+[num(next(z for z in tm if z['weights']==[.3,.3] and z['offset']==off and z['label']==label)['summary']['yearEqualCAGRpp'],signed=True,source=f'rotation/ensemble/timing-summary.json offset{off} {label}') for label in ['later35','all10_81','all15_21']])
table(['检查方案','后段十年','全部十年','全部十五年'],tr,[3300,2070,2070,2084])
p('原单批方案的 9 组季度相位／日期诊断，四权重合计 108 格中有 16 格负值；三批方案的 3 个固定偏移，四权重合计 36 格仍有 2 格为负，均为 40 / 20 后段十年。分批改善默认日历敏感性，没有消除所有权重依赖。')
h('研究选择的事实')
p('先用 28 个开发起点选规则，再查看后段 35 个起点及全部长期窗口。随后三批轮动、VIX 平均和双风险都是已看到部分结果后提出的机制探索。结果可复算，但不是无污染样本外检验，也不提供未来成功概率。')
note('各时间窗口共享大量交易日、相同危机和同一行情路径。不能把 81 个十年窗口当成 81 条互不相关的市场历史，也不能用这些窗口数量替代置信度。')
#7
page('绝对收益量级','年化收益与税后终值')
p('相对收益差需要结合绝对结果阅读。下表按各起点先计算策略和一次性账户，再分别取中位数。终值以初始本金 100 为单位，已扣交易费、已付税和未实现资本利得税准备金；不是每年新增 100。')
rows=[]
for m,n in [('vix','VIX'),('rotation','三批轮动'),('hybrid','双重风险门调仓')]:
 for lab,y in [('all10_81','十年'),('all15_21','十五年')]:
  g=cell(m,lab);rows.append([n+' '+y,f(g,'medianAnnualReturn',unit='%'),f(g,'baselineMedianAnnualReturn',unit='%'),f(g,'medianTerminalValue',places=1),f(g,'baselineMedianTerminalValue',places=1)])
table(['方法和持有期','年化中位数','一次性年化','税后终值','一次性终值'],rows,[2600,1800,1750,1670,1704])
h('两种统计口径的区别')
p('报告主要评价量是每个起点的策略年化减去对应一次性年化，先在入场年份内平均，再对入场年份等权。上表则分别取各账户的中位数。两列中位数之差通常不会等于主要评价量，不应混用。')
h('历史量级包含极强的资产上涨')
p('这些较高绝对收益来自所选 ETF 在这段历史中的长期表现，包含行业与科技集中以及每日杠杆。它们不能作为未来收益预测。对照也获得了很高的长期回报，因此新增方法必须以扣除成本后的配对增量衡量。')
note('默认 USD 30% / TQQQ 30% / 现金 40%；税率各 20%；每侧费 0.10%；下一共同收盘成交。十年 81 窗和十五年 21 窗分别统计，不能合并成独立样本。')
#8
page('收益的代价' ,'税后回撤和资金占用')
rows=[]
for m,n in [('vix','VIX'),('rotation','三批轮动'),('hybrid','双风险')]:
 for lab,y in [('all10_81','十年'),('all15_21','十五年')]:
  g=cell(m,lab);rows.append([n+' '+y,f(g,'medianMDD',unit='%'),f(g,'baselineMedianMDD',unit='%'),f(g,'worstMDD',unit='%'),f(g,'medianTradeCount',places=1)])
table(['方法和持有期','回撤中位数','一次性中位数','最差回撤','交易笔数中位'],rows,[2600,1800,1850,1570,1704])
p('三批轮动的回撤比一次性投入更深。股票池转向 TQQQ 时，名义每日杠杆暴露也会上升；没有额外借款，不等于风险水平始终相同。USD 和 TQQQ 的目标分别是底层指数每日约 2 倍和 3 倍，不能把它们理解为长期收益的固定倍数。[2][3]')
h('一次性对照与静态偏置')
p('所有对照从同一日按同一权重买入，扣同样初始交易费。原单批轮动与“股票全配 USD”相比，后段十年平均还落后约 1.38 个百分点；其较好全样本不能被解释成任何阶段都优于简单持有更强资产。最终三批策略相对单批父规则的默认收益也更低。')
h('税与订单的实际顺序')
p('已实现正资本利得和股息各按 20% 扣税，不计亏损抵扣；每天及期末对未实现收益预留同率税款。前一收盘固定卖出份额和买入金额，下一共同收盘成交。买单只能使用计划时已有现金；先卖后买的轮换须等净回款到账，再形成后续买单。')
note('没有额外入金、现金利息或期末强制清仓。成交价变化可能改变买后比例，研究未声称固定风险上限。终值、收益、回撤均基于税款准备金扣除后的账户价值。')
#8
page('完整搜索记录','187 个主阶段候选与失败结果')
table(['研究阶段','候选数','保留内容'],[['波动率与 VIX 家族','72','RV 膨胀 半方差 VIX 恐慌'],['双资产相对强弱','96','ETF 与底层代理 动量与反转'],['获利了结再回归','16','全部开发和后续失败'],['VIX 邻域平均','1','压力失败 不上线'],['三批季度轮动','1','日期失败后的机制修复'],['双重风险门','1','固定父规则组合']],[3300,1300,4924])
note('合计 187 个主阶段候选。27 格 VIX 邻域、9 格单批日期、3 格三批偏移另列为诊断；旧引擎机械修正重跑不增加候选数。')
fail=[]
for family,n in [('vol_expansion','实际波动膨胀'),('downside_stress','下行半方差')]:
 vals=[g for g in load('volatility/evaluation.json')['results'] if g['c']['family']==family and g['weights']==[.3,.3] and g['tax']==.2 and g['fee']==.001 and g['delay']==0]
 if vals:
  a={g['label']:g['summary']['yearEqualCAGRpp'] for g in vals};fail.append([n,num(a['later35'],signed=True),num(a['all10_81'],signed=True),num(a['all15_21'],signed=True)])
hr=load('harvest/summary.json');fail.append(['获利了结再回归']+[num(hr[k]['yearEqualCAGRpp'],signed=True) for k in ['later35','all10','all15']])
rr=load('rotation/evaluation.json')['results']
# Locate reversal by frozen candidate, never selecting based on results.
x=[g for g in rr if g['c']['direction']=='reversal' and g['weights']==[.3,.3] and g['tax']==.2 and g['fee']==.001 and g['delay']==0]
a={g['label']:g['summary']['yearEqualCAGRpp'] for g in x};fail.append(['代理相对反转']+[num(a[k],signed=True) for k in ['later35','all10_81','all15_21']])
table(['未采用的家族冠军','后段十年','全部十年','全部十五年'],fail,[3300,2070,2070,2084])
p('报告与归档保留负结果。开发期盈利不等于长期有效，回撤下降也不等于符合“长期收益超过一次性投入”的目标。失败候选没有进入生产方法列表。')
#9
page('证据与复算','数据范围和核验边界')
p('研究使用 USD、TQQQ 实际复权价格及其税务输入，行情截至 2026-11-02；不拼接上市前的合成 ETF。全部十年为 81 个起点，十五年为 21 个起点。本轮没有目标 ETF 的二十年真实持有证据，不能借用其他基金历史冒充。')
h('可复核的交付')
p('summary.json 列出三方法的 240 个评价格；results.csv 提供 10,960 条配对账户记录，含终值、年化、回撤、费用、资本利得税、股息税、期末税款准备金和敞口。后段 35 窗是全部 81 窗的子集，CSV 明确标注，不能重复累计成新样本。')
p('development-summary.json 逐条列出 187 个主阶段候选。reproduction.tar.gz 保存冻结参数、输入、原始脚本、选择记录、正负结果及独立账本核验。另在干净目录重算三种最终方法和诊断等 13 份输出，与冻结结果逐字节相同。独立账本指另行实现的计算路径，不意味着独立市场样本或第三方背书。')
h('可以知道什么')
p('这些方法确实在指定历史、权重和税费条件下产生了超过一次性投入的账户终值；未来能否延续取决于市场路径。重叠窗口、少数危机事件、参数和日历敏感性，以及机制在研究过程中调整，都限制结论的外推。')
h('来源')
note('[1] Cboe VIX Term Structure：VIX 与 VIX3M 的期限与标普 500 期权定义。https://www.cboe.com/tradable_products/vix/term_structure')
note('[2] ProShares UltraPro QQQ：TQQQ 每日目标和长期偏离说明。https://www.proshares.com/our-etfs/leveraged-and-inverse/tqqq')
note('[3] ProShares Ultra Semiconductors：USD 每日目标和底层指数身份。https://www.proshares.com/our-etfs/leveraged-and-inverse/usd')
note('来源端点、读取日期、原始内容与文件 SHA256 见归档 references.json、source-provenance.json 和 manifest.json。研究保留的是已获取的历史数据，未声称拥有逐日发布版本档案。')
body.append(sect)
parts['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
parts['word/footer1.xml']=parts['word/footer1.xml'].replace(b'2026.11.05',b'2026.11.06')
core=E.fromstring(parts['docProps/core.xml']);dc={'dc':'http://purl.org/dc/elements/1.1/','dcterms':'http://purl.org/dc/terms/'}
for tag in ['title','subject']:
 x=core.find('dc:'+tag,dc)
 if x is not None:x.text='USD 与 TQQQ 长期调仓方法对照报告'
for tag in ['created','modified']:
 x=core.find('dcterms:'+tag,dc)
 if x is not None:x.text='2026-11-06T00:00:00Z'
parts['docProps/core.xml']=E.tostring(core,xml_declaration=True,encoding='UTF-8',standalone=True)
app=E.fromstring(parts['docProps/app.xml']);apns={'a':'http://schemas.openxmlformats.org/officeDocument/2006/extended-properties'}
x=app.find('a:Pages',apns)
if x is not None:x.text='10'
parts['docProps/app.xml']=E.tostring(app,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(OUT/'report.docx','w',ZIP_DEFLATED)as z:
 for n,b in parts.items():z.writestr(n,b)
(OUT/'report-fields.json').write_text(json.dumps(fields,ensure_ascii=False,indent=2)+'\n')
(OUT/'report-tables.json').write_text(json.dumps(table_records,ensure_ascii=False,indent=2)+'\n')
(OUT/'report-content.txt').write_text('\n'.join(plain)+'\n')
with ZipFile(REF)as z:
 changed=[n for n in z.namelist() if z.read(n)!=parts[n]]
assert set(changed)=={'word/document.xml','word/footer1.xml','docProps/core.xml','docProps/app.xml'},changed
print(json.dumps({'docx':str(OUT/'report.docx'),'tables':len(table_records),'boundFields':len(fields),'changedParts':changed}))
