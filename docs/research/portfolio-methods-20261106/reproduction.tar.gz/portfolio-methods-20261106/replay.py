#!/usr/bin/env python3
"""Verify the frozen inputs and replay final evaluations in a new directory.

Uses Python 3 and Node.js 18+ only. No network or Python third-party packages.
The original dated research files are never overwritten.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path, help='New or empty output directory outside the archive')
    parser.add_argument('--diagnostics', action='store_true', help='Also replay VIX parameter/ensemble and original rotation calendar checks')
    parser.add_argument('--production', action='store_true', help='Also audit the bundled actual production core across all 4,080 researched configurations')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    target = args.output.resolve()
    if root == target or root in target.parents or target in root.parents:
        parser.error('Output must be outside the frozen archive and cannot contain it')
    if target.exists() and any(target.iterdir()):
        parser.error('Refusing to overwrite a non-empty output directory')
    frozen = json.loads((root / 'frozen-files.json').read_text())
    extras_file = root / 'delivery-files.json'
    extras = json.loads(extras_file.read_text()) if extras_file.exists() else {}
    files = {**frozen, **extras}
    for name, info in files.items():
        path = root / name
        if digest(path) != info['sha256'] or path.stat().st_size != info['bytes']:
            raise RuntimeError('Frozen file mismatch: ' + name)
    target.mkdir(parents=True, exist_ok=True)
    for name in files:
        out = target / name
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / name, out)

    stages = [
        ('volatility', ['study.cjs', 'evaluate'], ['evaluation.json']),
        ('rotation/ensemble', ['run.cjs', 'evaluate'], ['evaluation.json', 'evaluation-summary.json', 'timing-diagnostics.json', 'timing-summary.json']),
        ('hybrid', ['study.cjs', 'evaluate'], ['evaluation.json', 'signal-transitions.json']),
    ]
    if args.diagnostics:
        stages += [
            ('volatility', ['neighborhood.cjs'], ['neighborhood.json', 'neighborhood-summary.json']),
            ('volatility', ['ensemble.cjs', 'evaluate'], ['ensemble-evaluation.json', 'ensemble-summary.json']),
            ('rotation', ['phase.cjs'], ['phase-results.json', 'phase-summary.json']),
        ]
    results = []
    for folder, command, outputs in stages:
        for name in outputs:
            (target / folder / name).unlink(missing_ok=True)
        print('Replaying ' + folder + ': ' + ' '.join(command), flush=True)
        log = target / folder / ('replay-' + command[0] + '.log')
        with log.open('w') as stream:
            subprocess.run(['node', *command], cwd=target / folder, stdout=stream, stderr=subprocess.STDOUT, check=True)
        for name in outputs:
            relative = folder + '/' + name
            actual, expected = target / relative, root / relative
            # Numerical and metadata equality permits irrelevant JSON whitespace.
            if json.loads(actual.read_text()) != json.loads(expected.read_text()):
                raise RuntimeError('Recomputed result differs: ' + relative)
            results.append({'file': relative, 'equalJSON': True, 'byteIdentical': digest(actual) == digest(expected), 'sha256': digest(actual)})
    if args.production:
        print('Auditing bundled production core (4,080 accounts)', flush=True)
        with (target / 'production-replay.log').open('w') as stream:
            subprocess.run(['node', str(target / 'production-core-audit.cjs'), str(target / 'production')],
                           cwd=target, stdout=stream, stderr=subprocess.STDOUT, check=True)
        actual = json.loads((target / 'production-core-audit.json').read_text())
        expected = json.loads((root / 'production-core-audit.json').read_text())
        if actual['sources'] != expected['sources'] or actual['results'] != expected['results']:
            raise RuntimeError('Production source binding or account results differ')
        results.append({'file': 'production-core-audit.json', 'accounts': actual['counters']['accounts'], 'equalSourcesAndAccounts': True})
    proof = {'frozenFilesVerified': len(frozen), 'additionalFilesVerified': len(extras), 'networkUsed': False, 'outputs': results}
    (target / 'replay-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps(proof, indent=2), flush=True)


if __name__ == '__main__':
    main()
