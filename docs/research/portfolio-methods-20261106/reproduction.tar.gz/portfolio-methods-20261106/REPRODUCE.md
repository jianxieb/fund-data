# 2026-11-06 投入方法冻结研究复算

本归档保留实际执行过的研究输入、方案、候选、选择记录、逐账户结果、失败版本、诊断及独立核验。187是主阶段候选条目数，不是独立市场样本数。27项VIX邻域诊断另列，其中3项与初始网格重复；账本修正重跑不增加候选。

## 一条命令复算最终结果

需要Python 3与Node.js 18或更高版本，无网络及第三方Python依赖。解压到任意目录，在其中执行：

```sh
python3 replay.py ../new-replay-output --diagnostics
```

输出目录必须不存在或为空，并在归档目录之外。脚本先核对 `frozen-files.json` 中每个文件的SHA-256，再复制输入到新目录。保留已冻结的开发和选择记录，重新计算三个最终方法的完整评估，以及VIX邻域、未选均值版本、原轮动日期诊断。结果逐JSON比较，并记录是否逐字节相同；不会覆盖原研究。`clean-replay-proof.json` 是交付前实际执行这一流程的证明。

脚本同时重算VIX研究的失败代表和三批轮动的父规则。`later35` 是 `all10_81` 的子集；不能将这些重复行合成更多独立窗口。

## 目录与原始研究入口

| 目录 | 研究内容 | 原始入口（在该目录运行） |
| --- | --- | --- |
| `volatility` | 72个波动/期限结构候选及3个代表 | `node study.cjs develop` / `evaluate` |
| `volatility` | 27个参数邻域、失败均值版本 | `node neighborhood.cjs`；`node ensemble.cjs develop` / `evaluate` |
| `rotation` | 96个相对强弱与均值回归候选、静态对照 | `node run.cjs development` / `evaluate` |
| `rotation/ensemble` | 单一三批机制及执行日期敏感性 | `node run.cjs development` / `evaluate` |
| `harvest` | 16个盈利回收候选与失败代表 | `node study.cjs develop` / `evaluate` |
| `hybrid` | 固定VIX与QQQ双风险门、父规则对照 | `node study.cjs develop` / `evaluate` |

直接运行原始开发脚本必须在另一个工作副本中移走其已生成的开发/选择文件，脚本有拒绝覆盖保护。开发步骤会产生新的运行时间和来源绑定，因此不能将这类新元数据伪装成原冻结时间。本交付的统一入口保留原冻结选择，仅重算完整评估，避免这种混淆。

`engine.cjs` 是固定信号日卖出份额、已知现金买入金额的正式研究账本。`engine-v1.cjs` 和子目录草稿保留早期按成交日持仓比例卖出的版本，不是当前结果，不能作为新增候选。所有推荐结论引用当前引擎。

`inputs.json` 含冻结的真实目标ETF人民币价格、QQQ等代理信号、VIX配对记录及窗口；`tax-inputs.json` 保留实际分红证据。`source-provenance.json` 与 `references.json` 记录原始来源及哈希。原ETF与QQQ价格身份、官方VIX源身份在生产核验中另行验证。

各族的 `independent-*.py` 和 `audit.cjs` 保留独立账本检查；结果在对应审计JSON中。生产集成核验入口、原币/汇率快照、实际源码及运行证明在最终包的 `production` 子目录。报告汇总脚本与统一逐账户输出在 `delivery` 子目录。

十年与十五年窗口高度重叠，历史已经被反复研究；计算可复现不意味着未来可靠。目标ETF没有完整二十年真实历史，本轮不使用其他基金冒充。
