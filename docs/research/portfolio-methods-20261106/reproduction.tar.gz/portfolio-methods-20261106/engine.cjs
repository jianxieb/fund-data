'use strict';
// Fixed pre-close decisions; next-close fills never resize a promised order using future prices.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const ROOT=__dirname,input=JSON.parse(fs.readFileSync(path.join(ROOT,'inputs.json'))),taxInput=JSON.parse(fs.readFileSync(path.join(ROOT,'tax-inputs.json')));
const sum=a=>a.reduce((a,b)=>a+b,0),mean=a=>a.length?sum(a)/a.length:null;
const median=a=>{const b=a.slice().sort((a,b)=>a-b);return b.length?(b[(b.length-1)>>1]+b[b.length>>1])/2:null;};
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),EPS=1e-10;
function environment(data=input){const daily=data.daily,dates=daily.map(r=>r[0]);return{data,daily,dates,indices:new Map(dates.map((d,i)=>[d,i]))};}
const ENV=environment();
const periods={development28:input.origins.filter(o=>o.years===10&&o.start>='2011-09-01'&&o.start<'2014'),later35:input.origins.filter(o=>o.years===10&&o.start>='2014'&&o.start<'2017'),all10_81:input.origins.filter(o=>o.years===10),all15_21:input.origins.filter(o=>o.years===15)};
assert.deepEqual(Object.values(periods).map(a=>a.length),[28,35,81,21]);
function account(origin,weights,factory=null,options={}){
 const {fee=.001,tax=.2,dividendTax=tax,delay=0,trace=false,initial=100}=options,env=options.env||ENV;
 assert([0,1].includes(delay));assert(weights.length===2&&weights.every(w=>w>=0)&&sum(weights)<=1+EPS);
 const {daily,dates,indices}=env,first=indices.get(origin.start),last=indices.get(origin.end);assert(first!=null&&last>=first);
 const fractions=options.dividends||['us:USD','us:TQQQ'].map(id=>taxInput[id].dividendEvidence.fractions);
 const units=[0,0],basis=[0,0],cashByLeg=[0,0];let cash=initial,fees=0,capitalTax=0,paidDividendTax=0,peak=initial,mdd=0,pending=null;
 let totalStock=0,maxStock=0,maxLeverage=0,priorValue=null,value=initial,grossValue=initial,reserve=0,initialCash=null;
 const trades=[],plans=[],curve=[],returns=[];let tradeCount=0,planCount=0,inventoryCapCount=0;
 const policy=factory?.({input:env.data,dates,fee,tax,dividendTax,weights:weights.slice(),initial,first,last,delay});
 const initialNotionals=weights.map(w=>initial*w/(1+fee*sum(weights)));
 function fill(leg,side,amount,p,day,signalDay,reason,legUnits){
  if(amount<=EPS)return null;const charge=amount*fee;let paid=0,netCash;
  if(side==='sell'){
   const cost=units[leg]>0?basis[leg]*legUnits/units[leg]:0;paid=Math.max(0,amount-charge-cost)*tax;
   units[leg]-=legUnits;basis[leg]-=cost;netCash=amount-charge-paid;cash+=netCash;cashByLeg[leg]+=netCash;
   if(units[leg]<EPS){units[leg]=0;basis[leg]=0;}
  }else{
   legUnits=amount/p;netCash=-(amount+charge);units[leg]+=legUnits;basis[leg]+=amount+charge;cash+=netCash;
   if(reason!=='initial')cashByLeg[leg]+=netCash;
  }
  fees+=charge;capitalTax+=paid;tradeCount++;
  const record={day,signalDay,reason,leg,side,amount,units:legUnits,fee:charge,tax:paid,netCash};if(trace)trades.push(record);return record;
 }
 function exposure(prices){const marks=units.map((u,k)=>u*prices[k]),wealth=cash+sum(marks);if(wealth>0){maxStock=Math.max(maxStock,sum(marks)/wealth);maxLeverage=Math.max(maxLeverage,(2*marks[0]+3*marks[1])/wealth);}}
 for(let index=first;index<=last;index++){
  const [day,prices]=daily[index],latestFills=[];
  if(index>first)for(let k=0;k<2;k++){
   const dividend=units[k]*prices[k]*(fractions[k][day]||0),charge=dividend*dividendTax;
   units[k]-=charge/prices[k];basis[k]+=dividend-charge;paidDividendTax+=charge;
  }
  exposure(prices);
  if(index===first){for(let k=0;k<2;k++){const f=fill(k,'buy',initialNotionals[k],prices[k],day,null,'initial');if(f)latestFills.push(f);}initialCash=cash;}
  if(pending&&index===pending.dueIndex){
   const order=pending;pending=null;
   // The buy budget was reserved at signal time. Sales on this fill cannot enlarge it.
   assert(sum(order.buyAmounts)*(1+fee)<=cash+1e-7,'Prior cash commitment no longer available');
   for(let k=0;k<2;k++)if(order.sellUnits[k]>EPS){const qty=Math.min(units[k],order.sellUnits[k]),capped=order.sellUnits[k]-qty>EPS;if(capped)inventoryCapCount++;const f=fill(k,'sell',qty*prices[k],prices[k],day,order.signalDay,'policy',qty);if(f){f.plannedUnits=order.sellUnits[k];f.inventoryCapped=capped;latestFills.push(f);}}
   for(let k=0;k<2;k++){const f=fill(k,'buy',order.buyAmounts[k],prices[k],day,order.signalDay,'policy');if(f)latestFills.push(f);}
  }
  assert(cash>=-1e-7&&units.every(u=>u>=-EPS)&&basis.every(b=>b>=-1e-7));if(cash<0)cash=0;
  exposure(prices);
  const marks=units.map((u,k)=>u*prices[k]);grossValue=cash+sum(marks);reserve=sum(marks.map((m,k)=>Math.max(0,m*(1-fee)-basis[k])*tax));value=grossValue-reserve;
  assert(value>0);peak=Math.max(peak,value);mdd=Math.min(mdd,100*(value/peak-1));totalStock+=sum(marks)/grossValue;
  if(priorValue!=null)returns.push(value/priorValue-1);priorValue=value;
  if(policy&&!pending){
   const ctx={index,day,prices:prices.slice(),units:units.slice(),basis:basis.slice(),marks,cash,cashByLeg:cashByLeg.slice(),wealth:grossValue,value,reserve,initialCash,weights:weights.slice(),fee,tax,dividendTax,latestFills,initial,first,last};
   const order=policy.step(ctx);
   if(order){
    const sellFractions=(order.sellFractions||[0,0]).slice(),buyAmounts=(order.buyAmounts||[0,0]).slice();
    assert(sellFractions.length===2&&buyAmounts.length===2&&sellFractions.every(x=>Number.isFinite(x)&&x>=0&&x<=1+EPS)&&buyAmounts.every(x=>Number.isFinite(x)&&x>=0));
    assert(sum(buyAmounts)*(1+fee)<=cash+1e-7,'Plan spends future sale proceeds or borrows');
    if(sum(sellFractions)>EPS||sum(buyAmounts)>EPS){pending={signalDay:day,signalIndex:index,dueIndex:index+1+delay,dueDay:dates[index+1+delay]||null,sellFractions:sellFractions.map(x=>Math.min(1,x)),sellUnits:sellFractions.map((x,k)=>units[k]*Math.min(1,x)),buyAmounts,reason:order.reason||null,knownCash:cash};planCount++;if(trace)plans.push({...pending});}
   }
  }
  if(trace)curve.push({day,value,grossValue,reserve,cash,units:units.slice(),basis:basis.slice(),cashByLeg:cashByLeg.slice()});
 }
 const years=(Date.parse(origin.end)-Date.parse(origin.start))/864e5/365.2425;
 const sorted=returns.slice().sort((a,b)=>a-b),nTail=Math.max(1,Math.ceil(sorted.length*.05));
 return{start:origin.start,end:origin.end,years:origin.years,weights:weights.slice(),value,grossValue,annualReturn:100*((value/initial)**(1/years)-1),mdd,fees,capitalTax,paidDividendTax,paidTax:capitalTax+paidDividendTax,reserve,finalCash:cash,initialCash,cashByLeg,tradeCount,planCount,inventoryCapCount,maxStockFraction:maxStock,meanStockFraction:totalStock/(last-first+1),maxDailyLeverageExposure:maxLeverage,cvar95:100*mean(sorted.slice(0,nTail)),pending,...trace?{trades,plans,curve}:{}};
}
// Targets are known exposure fractions within each leg's original capital plus retained sale proceeds.
function sleeveTargetOrders(ctx,targets){
 const sellFractions=[0,0],buyAmounts=[0,0];
 for(let k=0;k<2;k++){
  const a=targets[k];assert(a>=0&&a<=1);const pool=Math.max(0,ctx.cashByLeg[k]),mark=ctx.marks[k],wealth=pool+mark,desired=a*wealth;
  if(mark>desired+EPS)sellFractions[k]=(mark-desired)/mark;
  else if(desired>mark+EPS)buyAmounts[k]=Math.min(pool/(1+ctx.fee),(desired-mark)/(1+a*ctx.fee));
 }
 return{sellFractions,buyAmounts};
}
// Stock capital only: original unallocated cash remains untouched. Orders are fixed now; next prices may move weights away from target.
function stockMixOrders(ctx,shares){
 assert(shares.length===2&&shares.every(x=>x>=0)&&Math.abs(sum(shares)-1)<1e-8);
 const available=Math.max(0,ctx.cash-ctx.initialCash),active=sum(ctx.marks)+available,target=shares.map(w=>w*active),gaps=target.map((v,k)=>Math.max(0,v-ctx.marks[k]));
 const sellFractions=target.map((v,k)=>ctx.marks[k]>v+EPS?(ctx.marks[k]-v)/ctx.marks[k]:0);
 const budget=Math.min(available/(1+ctx.fee),sum(gaps)/(1+ctx.fee));
 const buyAmounts=sum(gaps)>EPS?gaps.map(d=>budget*d/sum(gaps)):[0,0];return{sellFractions,buyAmounts};
}
function compare(rows,baseline){
 assert(rows.length===baseline.length);const years={};const pairs=rows.map((r,i)=>{const b=baseline[i];assert(r.start===b.start&&r.end===b.end);const d=r.annualReturn-b.annualReturn;(years[r.start.slice(0,4)]??=[]).push(d);return{start:r.start,end:r.end,CAGRpp:d,wealthRelativePct:100*(r.value/b.value-1),mddDifferencePP:r.mdd-b.mdd};});
 return{n:rows.length,yearEqualCAGRpp:mean(Object.values(years).map(mean)),meanCAGRpp:mean(pairs.map(p=>p.CAGRpp)),wins:pairs.filter(p=>p.CAGRpp>1e-9).length,ties:pairs.filter(p=>Math.abs(p.CAGRpp)<=1e-9).length,losses:pairs.filter(p=>p.CAGRpp< -1e-9).length,medianWealthRelativePct:median(pairs.map(p=>p.wealthRelativePct)),medianMDD:median(rows.map(r=>r.mdd)),baselineMedianMDD:median(baseline.map(r=>r.mdd)),worstMDD:Math.min(...rows.map(r=>r.mdd)),medianPaidTax:median(rows.map(r=>r.paidTax)),medianFees:median(rows.map(r=>r.fees)),meanStockFraction:mean(rows.map(r=>r.meanStockFraction)),baselineMeanStockFraction:mean(baseline.map(r=>r.meanStockFraction)),medianTradeCount:median(rows.map(r=>r.tradeCount)),worstOrigin:pairs.slice().sort((a,b)=>a.CAGRpp-b.CAGRpp)[0],byEntryYear:Object.fromEntries(Object.entries(years).map(([y,a])=>[y,{n:a.length,meanCAGRpp:mean(a)}]))};
}
function evaluate(origins,weights,factory,options={}){const rows=origins.map(o=>account(o,weights,factory,options)),baseline=origins.map(o=>account(o,weights,null,{...options,delay:0}));return{summary:compare(rows,baseline),rows,baseline};}
module.exports={input,taxInput,ENV,environment,periods,account,evaluate,compare,sleeveTargetOrders,stockMixOrders,sum,mean,median,hash};
