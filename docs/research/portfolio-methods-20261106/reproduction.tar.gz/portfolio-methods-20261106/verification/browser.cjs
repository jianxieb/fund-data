const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const {chromium}=require('/Users/ajin/.npm/_npx/e41f203b7505f1fb/node_modules/playwright');
const root=__dirname;
const config={positions:[{id:'us:USD',weight:30},{id:'us:TQQQ',weight:30}],currency:'CNY',initial:100000,monthly:0,initialMethod:'vix_panic_reentry',contributionMethod:'dca_month',rebalance:'none',transactionFee:.1,years:'custom',start:'2014-01-02',end:'2024-01-02',benchmarkId:'',tax:{usCapitalGains:20,usDividend:20,cnStockCapitalGains:0,cnStockDividend:0,cnFundCapitalGains:0,cnFundDividend:0,liquidate:false,overrides:{}}};
(async()=>{
 const browser=await chromium.launch({headless:true});
 const context=await browser.newContext({viewport:{width:1920,height:1080},deviceScaleFactor:2});
 await context.addInitScript(value=>localStorage.setItem('changheng.portfolio.v1',JSON.stringify(value)),config);
 const page=await context.newPage(),requests=[],pageErrors=[],loadedSources={},sourceLoads=[];
 page.on('pageerror',e=>pageErrors.push(e.message));page.on('request',r=>requests.push({url:r.url(),headers:r.headers()}));
 page.on('response',response=>{const file=new URL(response.url()).pathname.slice(1);if(['assets/portfolio.js','assets/portfolio-model.js','assets/portfolio-systematic.js'].includes(file))sourceLoads.push(response.body().then(body=>{loadedSources[file]=require('crypto').createHash('sha256').update(body).digest('hex');}));});
 await page.goto('http://127.0.0.1:8765/#portfolio',{waitUntil:'networkidle'});
 await page.waitForSelector('[data-action="portfolio-run"]');
 await page.evaluate(()=>{const P=window.ChanghengPortfolioModel,original=P.simulate;window.__uiAudit=[];P.simulate=function(input){const r=original(input);window.__uiAudit.push({method:input.config.initialMethod,weights:input.config.positions.map(p=>p.weight),value:r.value,annualReturn:r.annualReturn,mdd:r.mdd,error:r.error,systematic:r.systematic,end:r.end});return r;};});
 const results=[];
 async function method(name){await page.locator('#portfolio-initialMethod').click();await page.locator('[data-action="portfolio-select"][data-field="initialMethod"][data-value="'+name+'"]').click();}
 async function weights(a,b){await page.locator('[data-portfolio-weight="us:USD"]').fill(String(a));await page.locator('[data-portfolio-weight="us:TQQQ"]').fill(String(b));}
 async function run(){await page.locator('[data-action="portfolio-run"]').click();await page.waitForFunction(()=>!document.querySelector('[data-action="portfolio-run"]').disabled,{},{timeout:30000});}
 for(const name of ['vix_panic_reentry','relative_strength_rotation','dual_risk_guard']) {
  await method(name);
  for(const pair of [[30,30],[50,50],[20,40]]){
   console.log('CASE',name,pair);
   await weights(...pair);const requestStart=requests.length,before=await page.evaluate(()=>window.__uiAudit.length);
   await run();
   const alert=await page.locator('[role="alert"]').allTextContents();
   if(alert.length){fs.writeFileSync(path.join(root,'browser-failure.json'),JSON.stringify({method:name,weights:pair,alert,observed:await page.evaluate(from=>window.__uiAudit.slice(from),before),completed:results},null,2)+'\n');await browser.close();}
   assert.deepEqual(alert,[],alert.join(';'));
   const observed=await page.evaluate(from=>window.__uiAudit.slice(from),before);
   const actual=observed.find(r=>r.method===name),baseline=observed.find(r=>r.method==='lump_sum');
   assert.ok(actual&&!actual.error&&baseline&&!baseline.error);assert.deepEqual(actual.weights,pair);assert.ok(Number.isFinite(actual.value));assert.equal(actual.systematic.method,name);
   const newRequests=requests.slice(requestStart);const vixRequests=newRequests.filter(r=>r.url.endsWith('/entry-context.json'));
   assert.equal(vixRequests.length,name==='relative_strength_rotation'?0:1);
   const planText=await page.locator('.portfolio-next-plan').innerText();
   assert.match(planText,/下一共同交易日/);assert.doesNotMatch(planText,/NaN|Infinity|undefined/);
   results.push({method:name,weights:pair,actual,baseline,planText,requests:newRequests.map(r=>r.url)});
   if(pair[0]===30){await page.locator('.portfolio-method-comparison').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(root,name+'-desktop.png')});}
  }
 }
 const prior=await page.locator('.portfolio-result-summary').innerText(),count=await page.evaluate(()=>window.__uiAudit.length);
 await page.route('**/data/portfolio/entry-context.json',route=>route.fulfill({status:503,body:'fixture: source unavailable'}));
 await run();assert.equal(await page.evaluate(()=>window.__uiAudit.length),count);
 assert.equal(await page.locator('.portfolio-result-summary').innerText(),prior);
 const failure=await page.locator('[role="alert"]').innerText();assert.match(failure,/最新VIX\/VIX3M配对数据请求失败（503）.*仍显示上次成功模拟结果/);
 await page.locator('[role="alert"]').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(root,'missing-vix-retains-account.png')});
 await method('relative_strength_rotation');const n=requests.length;await run();assert.deepEqual(await page.locator('[role="alert"]').allTextContents(),[]);assert.equal(requests.slice(n).filter(r=>r.url.endsWith('/entry-context.json')).length,0);
 await page.unroute('**/data/portfolio/entry-context.json');await method('dual_risk_guard');await run();assert.deepEqual(await page.locator('[role="alert"]').allTextContents(),[]);
 assert.deepEqual(pageErrors,[]);
 await Promise.all(sourceLoads);
 const out={passed:true,isolatedBrowserContext:true,userBrowserStorageTouched:false,viewport:{width:1920,height:1080,deviceScaleFactor:2},results,missingVix:{error:failure,priorAccountRetained:true,simulationNotRecomputed:true,rotationStillWorks:true,recoveryWorks:true},pageErrors,loadedSources,sourceFiles:Object.fromEntries(['assets/portfolio.js','assets/portfolio-model.js','assets/portfolio-systematic.js'].map(f=>[f,require('crypto').createHash('sha256').update(fs.readFileSync('/Users/ajin/Projects/fund-data/'+f)).digest('hex')]))};
 assert.deepEqual(out.loadedSources,out.sourceFiles,'browser must have loaded the exact final source files');
 fs.writeFileSync(path.join(root,'browser-results.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({passed:true,cases:results.length,missingVix:out.missingVix,sourceFiles:out.sourceFiles},null,2));
 await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1;});
